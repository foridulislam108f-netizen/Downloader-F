package com.foridul.mediadl

import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * GitHub Releases থেকে অ্যাপ-আপডেট: অ্যাপ খুললে সর্বশেষ রিলিজ দেখে, নতুন হলে ডায়ালগ দেখায়,
 * "আপডেট" চাপলে APK ডাউনলোড করে ইনস্টলার খোলে।
 * রিলিজ ট্যাগ হবে "build-<নম্বর>" (GitHub Actions নিজে বানায়), versionCode = 100 + নম্বর।
 */
class Updater(private val act: Activity) {
    private var dlId = -1L
    private var receiver: BroadcastReceiver? = null
    private var pendingApk: File? = null
    private var shown = false

    fun checkAsync() {
        val repo = BuildConfig.GITHUB_REPO
        if (repo.isEmpty() || shown) return
        Thread {
            try {
                val c = URL("https://api.github.com/repos/$repo/releases/latest").openConnection() as HttpURLConnection
                c.connectTimeout = 10000; c.readTimeout = 10000
                c.setRequestProperty("Accept", "application/vnd.github+json")
                c.setRequestProperty("User-Agent", "MediaDL-Pro")
                if (c.responseCode != 200) return@Thread
                val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
                val tag = j.optString("tag_name")
                val num = Regex("(\\d+)$").find(tag)?.value?.toIntOrNull() ?: return@Thread
                val code = 100 + num
                if (code <= BuildConfig.VERSION_CODE) return@Thread
                val assets = j.optJSONArray("assets") ?: return@Thread
                var found = ""
                for (i in 0 until assets.length()) {
                    val a = assets.getJSONObject(i)
                    if (a.optString("name").endsWith(".apk", true)) { found = a.optString("browser_download_url"); break }
                }
                if (found.isEmpty()) return@Thread
                val apk: String = found
                val notes = j.optString("body").trim().take(600)
                val name = j.optString("name").ifEmpty { tag }
                act.runOnUiThread { if (!act.isFinishing && !shown) { shown = true; showDialog(name, notes, apk) } }
            } catch (_: Throwable) { }
        }.start()
    }

    private fun showDialog(name: String, notes: String, url: String) {
        val msg = name + (if (notes.isNotEmpty()) "\n\n$notes" else "")
        AlertDialog.Builder(act)
            .setTitle(L.t("updTitle"))
            .setMessage(msg)
            .setPositiveButton(L.t("updNow")) { _, _ -> download(url) }
            .setNegativeButton(L.t("updLater"), null)
            .show()
    }

    private fun download(url: String) {
        try {
            val dir = act.getExternalFilesDir("update") ?: act.filesDir
            dir.mkdirs()
            val f = File(dir, "MediaDownloaderPro.apk")
            if (f.exists()) f.delete()
            val dm = act.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            val req = DownloadManager.Request(Uri.parse(url))
                .setTitle("MediaDL Pro update")
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                .setDestinationUri(Uri.fromFile(f))
            dlId = dm.enqueue(req)
            Toast.makeText(act, L.t("updDownloading"), Toast.LENGTH_SHORT).show()
            val r = object : BroadcastReceiver() {
                override fun onReceive(c: Context, i: Intent) {
                    if (i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1) != dlId) return
                    val q = dm.query(DownloadManager.Query().setFilterById(dlId))
                    val ok = q != null && q.use { it.moveToFirst() &&
                        it.getInt(it.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL }
                    stop()
                    if (ok) install(f) else Toast.makeText(act, L.t("updFailed"), Toast.LENGTH_LONG).show()
                }
            }
            receiver = r
            ContextCompat.registerReceiver(act, r, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE), ContextCompat.RECEIVER_EXPORTED)
        } catch (_: Throwable) {
            Toast.makeText(act, L.t("updFailed"), Toast.LENGTH_LONG).show()
        }
    }

    private fun stop() { try { receiver?.let { act.unregisterReceiver(it) } } catch (_: Exception) { }; receiver = null }

    private fun install(f: File) {
        try {
            if (Build.VERSION.SDK_INT >= 26 && !act.packageManager.canRequestPackageInstalls()) {
                // প্রথমবার: "এই অ্যাপ থেকে ইনস্টল অনুমতি" চালু করতে হবে; ফিরে এলে নিজে থেকেই ইনস্টল শুরু হবে
                pendingApk = f
                Toast.makeText(act, L.t("updAllow"), Toast.LENGTH_LONG).show()
                act.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${act.packageName}")))
                return
            }
            pendingApk = null
            val uri = FileProvider.getUriForFile(act, "${act.packageName}.files", f)
            act.startActivity(Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (_: Throwable) {
            Toast.makeText(act, L.t("updFailed"), Toast.LENGTH_LONG).show()
        }
    }

    /** ইনস্টল-অনুমতি দিয়ে অ্যাপে ফিরলে বাকি কাজ চালিয়ে যায় */
    fun onResume() {
        val f = pendingApk ?: return
        if (Build.VERSION.SDK_INT < 26 || act.packageManager.canRequestPackageInstalls()) install(f)
    }

    fun onDestroy() = stop()
}
