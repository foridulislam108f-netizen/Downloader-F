package com.foridul.mediadl

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * GitHub Releases থেকে অ্যাপ-আপডেট।
 * - অ্যাপ খুললে নিঃশব্দে দেখে (checkAsync); সেটিংসের "আপডেট চেক করুন" চাপলে ফল দেখায় (checkManual)।
 * - "আপডেট" চাপলে APK-র লিংক অ্যাপের নিজের ব্রাউজারে খোলে; সেখান থেকে ডাউনলোড অ্যাপের ভিতরের ডাউনলোডারেই হয়
 *   (সিস্টেম ডাউনলোড ম্যানেজারে নয়)। ডাউনলোড শেষ হলে ইনস্টলার নিজে খোলে।
 * রিলিজ ট্যাগ হবে "build-<নম্বর>" (GitHub Actions নিজে বানায়), versionCode = 100 + নম্বর।
 */
class Updater(
    private val act: Activity,
    /** APK-র লিংক অ্যাপের ব্রাউজারে (নতুন ট্যাবে) খুলে দেয় */
    private val openInBrowser: (String) -> Unit
) {
    private var pendingUri: Uri? = null
    private var shown = false
    private var checking = false

    /** আপডেট-ডাউনলোডের জন্য অপেক্ষা: পরের .apk ডাউনলোডটাই আপডেট ধরা হবে */
    @Volatile var awaitingApk = false
    private var trackedJobId: String? = null

    private class Info(val name: String, val notes: String, val apkUrl: String)

    /** অ্যাপ চালুর সময়: নতুন আপডেট থাকলে তবেই ডায়ালগ; না থাকলে বা ভুল হলে কিছু দেখায় না */
    fun checkAsync() {
        if (BuildConfig.GITHUB_REPO.isEmpty() || shown) return
        Thread {
            val r = try { fetchLatest() } catch (_: Throwable) { null }
            if (r is Info) act.runOnUiThread { if (!act.isFinishing && !shown) { shown = true; showDialog(r) } }
        }.start()
    }

    /** সেটিংসের বাটন: প্রতিবার ফল জানায় (আপডেট আছে / নেই / চেক করা যায়নি) */
    fun checkManual() {
        if (BuildConfig.GITHUB_REPO.isEmpty()) {
            Toast.makeText(act, L.t("updNoRepo"), Toast.LENGTH_LONG).show()
            return
        }
        if (checking) return
        checking = true
        Toast.makeText(act, L.t("updChecking"), Toast.LENGTH_SHORT).show()
        Thread {
            val r = try { fetchLatest() } catch (_: Throwable) { false }
            checking = false
            act.runOnUiThread {
                if (act.isFinishing) return@runOnUiThread
                when (r) {
                    is Info -> { shown = true; showDialog(r) }
                    true -> Toast.makeText(act, L.t("updLatest") + " (v" + BuildConfig.VERSION_NAME + ")", Toast.LENGTH_LONG).show()
                    else -> Toast.makeText(act, L.t("updCheckFail"), Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    /** Info = নতুন আপডেট আছে, true = আপ-টু-ডেট, false = চেক করা যায়নি */
    private fun fetchLatest(): Any {
        val c = URL("https://api.github.com/repos/${BuildConfig.GITHUB_REPO}/releases/latest").openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 10000
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.setRequestProperty("User-Agent", "MediaDL-Pro")
        if (c.responseCode != 200) return false
        val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        val tag = j.optString("tag_name")
        val num = Regex("(\\d+)$").find(tag)?.value?.toIntOrNull() ?: return false
        if (100 + num <= BuildConfig.VERSION_CODE) return true
        val assets = j.optJSONArray("assets") ?: return false
        var found = ""
        for (i in 0 until assets.length()) {
            val a = assets.getJSONObject(i)
            if (a.optString("name").endsWith(".apk", true)) { found = a.optString("browser_download_url"); break }
        }
        if (found.isEmpty()) return false
        return Info(j.optString("name").ifEmpty { tag }, j.optString("body").trim().take(600), found)
    }

    private fun showDialog(i: Info) {
        val msg = i.name + (if (i.notes.isNotEmpty()) "\n\n${i.notes}" else "")
        AlertDialog.Builder(act)
            .setTitle(L.t("updTitle"))
            .setMessage(msg)
            .setPositiveButton(L.t("updNow")) { _, _ ->
                awaitingApk = true
                Toast.makeText(act, L.t("updDownloading"), Toast.LENGTH_SHORT).show()
                openInBrowser(i.apkUrl)
            }
            .setNegativeButton(L.t("updLater"), null)
            .show()
    }

    /** ডাউনলোডার নতুন কাজ বানালে ডাকা হয়; আপডেট-APK হলে সেটার শেষ হওয়া অনুসরণ করে */
    fun onNewDownload(jobId: String, fileName: String): Boolean {
        if (!awaitingApk || !fileName.endsWith(".apk", true)) return false
        awaitingApk = false
        trackedJobId = jobId
        return true
    }

    /** ডাউনলোড-তালিকা বদলালেই ডাকা হয় */
    fun onJobsChanged() {
        val id = trackedJobId ?: return
        val job = Engine.jobs.firstOrNull { it.id == id }
        if (job == null) { trackedJobId = null; return }
        when (job.status) {
            Engine.Status.DONE -> {
                trackedJobId = null
                val uri = job.saved?.let { History.locate(act, it) }
                if (uri != null) install(uri) else Toast.makeText(act, L.t("updFailed"), Toast.LENGTH_LONG).show()
            }
            Engine.Status.FAILED -> { trackedJobId = null; Toast.makeText(act, L.t("updFailed"), Toast.LENGTH_LONG).show() }
            Engine.Status.CANCELED -> if (!job.paused) trackedJobId = null
            else -> {}
        }
    }

    private fun install(uri: Uri) {
        try {
            if (Build.VERSION.SDK_INT >= 26 && !act.packageManager.canRequestPackageInstalls()) {
                // প্রথমবার: "এই অ্যাপ থেকে ইনস্টল অনুমতি" চালু করতে হবে; ফিরে এলে নিজে থেকেই ইনস্টল শুরু হবে
                pendingUri = uri
                Toast.makeText(act, L.t("updAllow"), Toast.LENGTH_LONG).show()
                act.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${act.packageName}")))
                return
            }
            pendingUri = null
            val u = if (uri.scheme == "file")
                FileProvider.getUriForFile(act, "${act.packageName}.files", File(uri.path ?: ""))
            else uri
            act.startActivity(Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(u, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (_: Throwable) {
            Toast.makeText(act, L.t("updFailed"), Toast.LENGTH_LONG).show()
        }
    }

    /** ইনস্টল-অনুমতি দিয়ে অ্যাপে ফিরলে বাকি কাজ চালিয়ে যায় */
    fun onResume() {
        val u = pendingUri ?: return
        if (Build.VERSION.SDK_INT < 26 || act.packageManager.canRequestPackageInstalls()) install(u)
    }

    fun onDestroy() {}
}
