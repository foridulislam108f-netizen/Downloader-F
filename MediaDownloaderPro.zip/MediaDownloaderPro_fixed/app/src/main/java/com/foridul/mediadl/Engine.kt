package com.foridul.mediadl

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import android.widget.Toast
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.youtubedl_android.mapper.VideoFormat
import java.io.File
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * yt-dlp ইঞ্জিনের চারপাশের সব কাজ: বিশ্লেষণ, ডাউনলোড-কিউ, প্রগ্রেস, Downloads-এ সেভ, আপডেট।
 */
object Engine {

    enum class Status { QUEUED, RUNNING, DONE, FAILED, CANCELED }

    class Arg(val key: String, val value: String? = null)

    /** kind: "video" | "audio" | "playlist"; sub: সাইজ/ফরম্যাট-বিবরণ (প্যানেলে ছোট লেখায় দেখায়) */
    class Choice(val label: String, val args: List<Arg>, val kind: String = "video", val sub: String = "", val analysisId: String? = null)

    class Analysis(val title: String, val video: List<Choice>, val audio: List<Choice>)

    class Job(
        val id: String,
        val url: String,
        val title: String,
        val args: List<Arg>,
        val cookies: String?,
        val ua: String?,
        val label: String = "",
        val referer: String? = null,
        val analysisId: String? = null
    ) {
        /** ব্রাউজার এই লিংকটা চালানোর সময় যে Referer/Origin/Authorization/X-* হেডার পাঠিয়েছিল, ডাউনলোডেও একই যাবে */
        @Volatile var headers: Map<String, String>? = null
        @Volatile var status = Status.QUEUED
        @Volatile var progress = 0f
        @Volatile var eta = 0L
        @Volatile var speed = 0L        // বাইট/সেকেন্ড
        @Volatile var totalBytes = 0L
        @Volatile var paused = false    // ব্যবহারকারী থামিয়েছে: আংশিক ফাইল রাখা হয়, ▶ চাপলে সেখান থেকে চলে
        @Volatile var netFail = false   // নেটের কারণে থেমেছে: নেট ফিরলে নিজে থেকে আবার চলবে
        @Volatile var autoTries = 0     // নিজে-নিজে আবার চালুর ঘড়ি-চেষ্টা (নেট ঘটনায় গোনা হয় না)
        @Volatile var message = ""
        @Volatile var saved: String? = null
        @Volatile var cancelRequested = false
        @Volatile var lastNotifyMs = 0L
        @Volatile var kick = false      // নেট বদলানোয় আমরাই সংযোগ কেটেছি: নতুন নেটে সাথে সাথে আবার জুড়বে
        @Volatile var attemptGen = 0    // এই চেষ্টা শুরুর সময়ের নেট-সংস্করণ (IP বদলালে 403 আসতে পারে)
        @Volatile var conn: java.net.HttpURLConnection? = null
    }

    private val RX_SUBEXT = Regex("""\.(vtt|srt|ass|ttml|srv\d|json3)\s*$""", RegexOption.IGNORE_CASE)
    private val SUB_EXT = setOf("srt", "vtt", "ass", "ttml", "srv1", "srv2", "srv3", "json3")
    private val RX_SIZE = Regex("""of\s+~?\s*([\d.]+)\s*([KMGT]?i?B)""")
    private val RX_SPEED = Regex("""at\s+([\d.]+)\s*([KMGT]?i?B)/s""")
    private fun toBytes(n: String, u: String): Long {
        val v = n.toDoubleOrNull() ?: return 0L
        val m = when (u.first().uppercaseChar()) {
            'K' -> 1024.0; 'M' -> 1048576.0; 'G' -> 1073741824.0; 'T' -> 1099511627776.0; else -> 1.0
        }
        return (v * m).toLong()
    }

    val jobs = CopyOnWriteArrayList<Job>()
    val listeners = CopyOnWriteArrayList<() -> Unit>()

    private val analysisCache = AnalysisCache()
    private lateinit var app: Context
    private val ready = CountDownLatch(1)
    @Volatile private var initError: String? = null
    private val pool = java.util.concurrent.ThreadPoolExecutor(
        3, 3, 30L, TimeUnit.SECONDS, java.util.concurrent.LinkedBlockingQueue<Runnable>()
    ).apply { allowCoreThreadTimeOut(true) }

    /** একসাথে সর্বোচ্চ কতটি ডাউনলোড চলবে; বাকিগুলো "অপেক্ষায়" থাকে, একটা শেষ হলে পরেরটা শুরু হয় */
    fun setMaxParallel(n: Int) {
        val v = n.coerceIn(1, 10)
        if (v >= pool.maximumPoolSize) {
            pool.maximumPoolSize = v
            pool.corePoolSize = v
        } else {
            pool.corePoolSize = v
            pool.maximumPoolSize = v
        }
    }
    private val main = Handler(Looper.getMainLooper())
    private val counter = AtomicInteger(0)

    // ---------- চালু করা ----------

    fun init(context: Context) {
        app = context.applicationContext
        History.init(app)
        L.init(app)
        setMaxParallel(L.maxJobs())
        restoreJobs()
        watchNetwork()
        Thread {
            try {
                YoutubeDL.getInstance().init(app)
                FFmpeg.getInstance().init(app)
            } catch (e: Exception) {
                initError = shortError(e)
            } finally {
                ready.countDown()
            }
            // yt-dlp/পাইথন আগেভাগে গরম করি, যাতে প্রথম বিশ্লেষণে ঠান্ডা-শুরুর দেরি না হয়
            if (initError == null) try {
                YoutubeDL.getInstance().execute(YoutubeDLRequest(emptyList<String>()).apply { addOption("--version") }, null, null)
            } catch (e: Exception) { }
            cleanOldPartials()
            // আপডেট ডাউনলোড যেন প্রথম বিশ্লেষণের সাথে নেটওয়ার্ক ভাগ না করে, তাই কিছুক্ষণ পরে
            if (initError == null) { try { Thread.sleep(90_000) } catch (e: InterruptedException) { }; autoUpdate() }
        }.start()
    }

    private fun waitReady() {
        if (!ready.await(90, TimeUnit.SECONDS)) {
            throw Exception(L.t("engBusy"))
        }
        val err = initError
        if (err != null) throw Exception(L.t("engFail") + err)
    }

    /** সাইটগুলো প্রায়ই বদলায়, তাই yt-dlp ৩ দিনে একবার নিজে আপডেট হয়। */
    private fun autoUpdate() {
        try {
            val p = app.getSharedPreferences("mdl", Context.MODE_PRIVATE)
            val last = p.getLong("lastUpdate", 0L)
            if (System.currentTimeMillis() - last < 3L * 24 * 3600 * 1000) return
            YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.STABLE)
            p.edit().putLong("lastUpdate", System.currentTimeMillis()).apply()
        } catch (e: Exception) {
            // নেটওয়ার্ক না থাকলে পরেরবার চেষ্টা হবে
        }
    }

    fun updateNow(): String {
        waitReady()
        val st = YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.STABLE)
        app.getSharedPreferences("mdl", Context.MODE_PRIVATE)
            .edit().putLong("lastUpdate", System.currentTimeMillis()).apply()
        val v = YoutubeDL.getInstance().versionName(app) ?: "?"
        return if (st == YoutubeDL.UpdateStatus.DONE) L.t("engUpdated") + v + ")"
        else L.t("engLatest") + v + ")"
    }

    // ---------- সাহায্যকারী ----------

    // ---------- ব্রাউজারের পাঠানো হেডার (ডাউনলোডেও একই হেডার যেন যায়) ----------

    private val seenHeaders = java.util.concurrent.ConcurrentHashMap<String, Map<String, String>>()

    /** WebView-এর রিকোয়েস্ট থেকে শুধু প্রয়োজনীয় হেডার রাখি (Cookie/User-Agent আলাদাভাবে যায়) */
    fun rememberHeaders(url: String, all: Map<String, String>?) {
        if (all.isNullOrEmpty()) return
        val keep = LinkedHashMap<String, String>()
        for ((k, v) in all) {
            if (v.isBlank()) continue
            val l = k.lowercase()
            val ok = l == "referer" || l == "origin" || l == "authorization" ||
                (l.startsWith("x-") && l != "x-requested-with")
            if (!ok) continue
            if (v.any { it == '\r' || it == '\n' }) continue
            keep[if (l == "referer") "Referer" else if (l == "origin") "Origin" else k] = v
        }
        if (keep.isEmpty()) return
        if (seenHeaders.size > 300) seenHeaders.clear()
        seenHeaders[url] = keep
    }

    fun headersFor(url: String): Map<String, String>? = seenHeaders[url]

    private fun originOf(u: String?): String? = try {
        val x = Uri.parse(u ?: "")
        if (x.scheme != null && x.host != null) x.scheme + "://" + x.authority else null
    } catch (_: Exception) { null }

    fun shortError(e: Throwable): String {
        val msg = e.message ?: e.toString()
        val lower = msg.lowercase()
        if (lower.contains("cloudflare") || lower.contains("anti-bot") ||
            lower.contains("cf-chl-") || lower.contains("challenge-platform")) {
            return if (L.lang == "en") {
                "The site blocked automated access (Cloudflare/anti-bot). Open it in the browser and use an official download/export option, or try a permitted direct media URL."
            } else {
                "সাইটটি automated access (Cloudflare/anti-bot) বন্ধ করেছে। ব্রাউজারে পেজটি খুলে সাইটের official download/export ব্যবহার করুন, অথবা অনুমোদিত direct media URL চেষ্টা করুন।"
            }
        }
        if (lower.contains("http error 403") || lower.contains("http error 429")) {
            return if (L.lang == "en") {
                "The site refused this automated request (HTTP ${if (lower.contains("429")) "429" else "403"}). This app does not bypass site access controls."
            } else {
                "সাইটটি automated request প্রত্যাখ্যান করেছে (HTTP ${if (lower.contains("429")) "429" else "403"})। এই অ্যাপ site access control bypass করে না।"
            }
        }
        val lines = msg.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val line = lines.lastOrNull { it.contains("ERROR", ignoreCase = true) } ?: lines.lastOrNull() ?: msg
        return line.removePrefix("ERROR:").trim().take(300)
    }

    private fun notifyChange() {
        main.post { for (l in listeners) l() }
    }

    private fun toast(msg: String) {
        main.post { Toast.makeText(app, msg, Toast.LENGTH_LONG).show() }
    }

    /** WebView-এর লগইন-কুকি yt-dlp-কে দেওয়ার জন্য (লগইন লাগে এমন সাইটে কাজে লাগে) */
    private fun cookieFile(url: String, raw: String?): File? {
        if (raw.isNullOrBlank()) return null
        val host = Uri.parse(url).host ?: return null
        val sb = StringBuilder("# Netscape HTTP Cookie File\n")
        for (part in raw.split(";")) {
            val kv = part.trim()
            val i = kv.indexOf('=')
            if (i <= 0) continue
            // CookieManager returns no domain metadata: scope conservatively to the requested host.
            if (kv.any { it == '\t' || it == '\r' || it == '\n' }) continue
            sb.append(host).append("\tFALSE\t/\tFALSE\t0\t")
                .append(kv.substring(0, i)).append('\t').append(kv.substring(i + 1)).append('\n')
        }
        val f = File(app.cacheDir, "ck_" + System.nanoTime() + ".txt")
        f.writeText(sb.toString())
        return f
    }

    private fun commonNet(req: YoutubeDLRequest, ck: File?, ua: String?, referer: String? = null,
                          headers: Map<String, String>? = null) {
        if (ck != null) req.addOption("--cookies", ck.absolutePath)
        if (!ua.isNullOrEmpty()) req.addOption("--user-agent", ua)
        // ব্রাউজার ভিডিওটা চালানোর সময় যে Referer পাঠিয়েছিল (iframe প্লেয়ারে সেটা মূল পেজের চেয়ে আলাদা হতে পারে) সেটাই আসল
        val ref = headers?.get("Referer") ?: referer
        if (!ref.isNullOrEmpty()) req.addOption("--referer", ref)
        if (headers != null) for ((k, v) in headers) {
            if (k.equals("Referer", true)) continue
            req.addOption("--add-header", "$k:$v")
        }
        // Let extractors keep their own Origin headers; synthesizing one for every site breaks some hosts.
        val cacheDir = File(app.cacheDir, "extractor-cache").apply { mkdirs() }
        req.addOption("--cache-dir", cacheDir.absolutePath)
        req.addOption("--ignore-config")
    }

    fun isPlaylistUrl(u: String): Boolean {
        val l = u.lowercase()
        if (l.contains("watch?v=") || l.contains("/video/") || l.contains("/shorts/") ||
            l.contains("/reel/") || l.contains("/status/") || l.contains("youtu.be/")
        ) return false
        return l.contains("/playlist") || l.contains("/channel/") || l.contains("/@") ||
            l.contains("/user/") || l.contains("/sets/")
    }

    private fun fmtSize(bytes: Long): String {
        val mb = bytes / 1048576.0
        return if (mb >= 1024) String.format("%.1f GB", mb / 1024) else String.format("%.0f MB", mb)
    }

    // ---------- বিশ্লেষণ: পেজে কী কী নামানো যায় ----------

    private val VIDEO_ARGS = listOf(
        Arg("-S", "res,ext:mp4:m4a"),
        Arg("--merge-output-format", "mp4/mkv")
    )

    private fun isYoutube(u: String): Boolean {
        val host = Uri.parse(u).host?.lowercase() ?: return false
        return listOf("youtube.com", "youtu.be", "youtube-nocookie.com").any {
            host == it || host.endsWith(".$it")
        }
    }

    /** ফেসবুক, ইনস্টাগ্রাম ও ইউটিউব: এই তিন সাইটের জন্য আলাদা "দ্রুত" সেটিং; বাকি সাইট আগের মতোই সাধারণ গতিতে */
    fun isFastSite(u: String): Boolean {
        val host = Uri.parse(u).host?.lowercase() ?: return false
        return listOf(
            "youtube.com", "youtu.be", "youtube-nocookie.com", "googlevideo.com",
            "facebook.com", "fb.watch", "fb.com", "fbcdn.net",
            "instagram.com", "cdninstagram.com"
        ).any { host == it || host.endsWith(".$it") }
    }

    /** YouTube প্রায়ই কিছু ক্লায়েন্টকে আটকে দেয়; একটা ব্যর্থ হলে পরেরটা চেষ্টা করা হয় */
    private fun youtubeFallbacks(): List<List<Arg>> = listOf(
        emptyList(),
        listOf(Arg("--extractor-args", "youtube:player_client=mweb")),
        listOf(Arg("--extractor-args", "youtube:player_client=android_vr")),
        listOf(Arg("--extractor-args", "youtube:player_client=tv_embedded"))
    )

    /** একই লিংক ৪ মিনিটের মধ্যে আবার বিশ্লেষণ করলে নতুন করে yt-dlp না চালিয়ে আগের ফল দেয় */
    private class Memo(val url: String, val at: Long, val result: Analysis, val cacheId: String?)
    private val memo = java.util.concurrent.ConcurrentHashMap<String, Memo>()
    private const val MEMO_TTL_MS = 4L * 60 * 1000

    fun analyze(url: String, rawCookies: String?, ua: String?, referer: String? = null): Analysis {
        try {
            return analyzeOnce(url, rawCookies, ua, referer)
        } catch (e: Exception) {
            val m = (e.message ?: "").lowercase()
            if (!m.contains("403")) throw e
            // ব্রাউজার CORS মিডিয়া রিকোয়েস্টে Referer-এর সাথে Origin-ও পাঠায়। ধরা হেডারে Origin না থাকলে
            // Referer থেকে ওটা বানিয়ে একবার আবার চেষ্টা (ব্রাউজার যা পাঠাত তাই; কোনো ছদ্মবেশ নয়)
            val seen = seenHeaders[url]
            val ref = seen?.get("Referer") ?: referer
            val origin = originOf(ref)
            if (seen?.containsKey("Origin") == true || origin == null) throw e
            val merged = LinkedHashMap<String, String>(seen ?: emptyMap())
            if (!ref.isNullOrEmpty()) merged["Referer"] = ref
            merged["Origin"] = origin
            seenHeaders[url] = merged
            return try { analyzeOnce(url, rawCookies, ua, referer) } catch (e2: Exception) { throw e }
        }
    }

    private fun analyzeOnce(url: String, rawCookies: String?, ua: String?, referer: String? = null): Analysis {
        memo[url]?.let { m ->
            val fresh = System.currentTimeMillis() - m.at < MEMO_TTL_MS
            if (fresh && (m.cacheId == null || analysisCache.get(m.cacheId, url) != null)) return m.result
            memo.remove(url)
        }
        waitReady()
        val ck = cookieFile(url, rawCookies)
        val ref = referer ?: url
        try {
            val prefs = app.getSharedPreferences("mdl", Context.MODE_PRIVATE)
            val isYt = isYoutube(url)
            val fast = isFastSite(url)
            val all = if (isYt) youtubeFallbacks() else listOf(emptyList())
            // গতবার যে ক্লায়েন্টে সফল হয়েছিল সেটা আগে চেষ্টা করি, ব্যর্থ চেষ্টায় সময় নষ্ট কমে
            val lastGood = if (isYt) prefs.getInt("ytClient", 0).coerceIn(0, all.size - 1) else 0
            val order = listOf(lastGood) + all.indices.filter { it != lastGood }
            val tries = order.map { all[it] }
            var lastErr: Exception? = null
            var info: com.yausername.youtubedl_android.mapper.VideoInfo? = null
            var extra: List<Arg> = emptyList()
            var metadata: String? = null
            var durationSeconds = 0.0
            for ((ti, t) in tries.withIndex()) {
                try {
                    val req = YoutubeDLRequest(url)
                    req.addOption("--no-playlist")
                    req.addOption("--no-warnings")
                    if (fast) {
                        // দ্রুত সাইট: সংযোগ আটকে থাকলে কম সময়ে ছেড়ে দেয়, অপেক্ষা কম
                        req.addOption("--socket-timeout", 7)
                        req.addOption("--extractor-retries", if (isYt) 1 else 0)
                        req.addOption("--retries", 1)
                    } else {
                        req.addOption("--socket-timeout", 10)
                        req.addOption("--extractor-retries", 1)
                        req.addOption("--retries", 2)
                    }
                    req.addOption("--no-check-formats")
                    req.addOption("--dump-single-json")
                    req.addOption("--skip-download")
                    for (a in t) req.addOption(a.key, a.value ?: "")
                    commonNet(req, ck, ua, ref, headersFor(url))
                    // getInfo() discards HTTP headers, fragments and the complete JSON after mapping.
                    val output = YoutubeDL.getInstance().execute(req, null, null).out
                    val data = JSONObject(output.trim())
                    // শুধু title আর formats লাগে; বিশাল সাবটাইটেল/থাম্বনেইল অংশ Jackson-এ পার্স না করে সময় বাঁচাই
                    val slim = JSONObject()
                    for (k in listOf("title", "fulltitle", "formats")) if (data.has(k)) slim.put(k, data.get(k))
                    val r = YoutubeDL.objectMapper.readValue(slim.toString(), com.yausername.youtubedl_android.mapper.VideoInfo::class.java)
                    if ((r.formats ?: emptyList<VideoFormat>()).isEmpty()) throw Exception(L.t("noFmt"))
                    info = r
                    extra = t
                    if (isYt) prefs.edit().putInt("ytClient", order[ti]).apply()
                    durationSeconds = data.optDouble("duration", 0.0).coerceAtLeast(0.0)
                    // Re-select the user's video/audio choice, not the format selected during analysis.
                    data.remove("requested_downloads")
                    data.remove("requested_formats")
                    data.remove("requested_subtitles")
                    // A live manifest must be fetched again; cached fragments may already be gone.
                    if (!data.optBoolean("is_live") && data.optString("live_status") !in listOf("is_live", "is_upcoming")) {
                        metadata = data.toString()
                    }
                    break
                } catch (e: Exception) {
                    lastErr = e
                }
            }
            if (info == null) throw (lastErr ?: Exception(L.t("anFail")))

            val fm: List<VideoFormat> = info.formats ?: emptyList()
            fun size(f: VideoFormat): Long = if (f.fileSize > 0) f.fileSize else f.fileSizeApproximate
            fun isVideo(f: VideoFormat) = f.vcodec != null && f.vcodec != "none" && f.height > 0
            fun isAudioOnly(f: VideoFormat) =
                f.acodec != null && f.acodec != "none" && (f.vcodec == null || f.vcodec == "none")

            val audioFmts = fm.filter { isAudioOnly(it) }
            // আসল ডাউনলোডে yt-dlp "-S res,ext:mp4:m4a" দিয়ে বাছে: mp4 ভিডিও + m4a অডিও আগে। তাই আন্দাজও একই নিয়মে করা হচ্ছে
            // (আগে সবচেয়ে বড় ফরম্যাটের সাইজ ধরা হতো, ফলে আন্দাজ ৫৭১ MB আর আসল ফাইল ৩৪৫ MB হতো)
            val m4aFmts = audioFmts.filter { it.ext == "m4a" }
            val reportedAudio = (if (m4aFmts.isNotEmpty()) m4aFmts else audioFmts).maxOfOrNull { size(it) } ?: 0L
            // Some sites omit filesize for segmented audio. Show a useful estimate instead of a blank label.
            val bestAudio = if (reportedAudio > 0L) reportedAudio
                else if (durationSeconds > 0.0) (durationSeconds * 16000.0).toLong()
                else 0L
            fun vRank(f: VideoFormat): Int {
                val c = (f.vcodec ?: "").lowercase()
                return when {
                    c.startsWith("av01") || c.startsWith("av1") -> 0
                    c.startsWith("vp9") || c.startsWith("vp09") -> 1
                    c.startsWith("hev") || c.startsWith("hvc") || c.startsWith("h265") -> 2
                    c.startsWith("avc") || c.startsWith("h264") -> 3
                    else -> 4
                }
            }
            fun pickVideo(list: List<VideoFormat>): VideoFormat? {
                val mp4 = list.filter { it.ext == "mp4" }
                val pool = if (mp4.isNotEmpty()) mp4 else list
                return pool.sortedWith(compareBy<VideoFormat> { vRank(it) }.thenByDescending { size(it) }).firstOrNull()
            }
            val heights = fm.filter { isVideo(it) }.map { it.height }.distinct().sortedDescending()

            // ---- ভিডিও: সব রেজোলিউশন ----
            val video = ArrayList<Choice>()
            if (fm.any { !isAudioOnly(it) }) {
                video.add(Choice("⭐ Best", listOf(Arg("-f", "bv*+ba/b")) + VIDEO_ARGS + extra, "video", "best"))
            }
            for (h in heights) {
                val sameH = fm.filter { isVideo(it) && it.height == h }
                val chosen = pickVideo(sameH)
                val v = if (chosen != null) size(chosen) else 0L
                val hasAudio = chosen?.acodec?.let { it != "none" } == true
                val total = if (v > 0) v + (if (hasAudio) 0L else bestAudio) else 0L
                val ext = sameH.firstOrNull { it.ext == "mp4" }?.ext ?: sameH.firstOrNull()?.ext ?: "mp4"
                val sub = ext.uppercase() + (if (total > 0) " • ~" + fmtSize(total) else "")
                video.add(
                    Choice(
                        "${h}p",
                        listOf(Arg("-f", "bv*[height<=$h]+ba/b[height<=$h]/b")) + VIDEO_ARGS + extra,
                        "video", sub
                    )
                )
            }

            // যে সাইটে yt-dlp রেজোলিউশন (height) জানায় না, সেখানেও যেন বাছাইয়ের তালিকা থাকে: প্রতিটি ফরম্যাট আলাদা অপশন
            if (heights.isEmpty()) {
                val others = fm.filter { !isAudioOnly(it) && !it.formatId.isNullOrEmpty() }
                    .sortedByDescending { if (it.width > 0) it.width else 0 }
                    .sortedByDescending { size(it) }
                for ((n, f) in others.withIndex()) {
                    val sz = size(f)
                    val dim = if (f.width > 0 && f.height > 0) "${f.width}x${f.height} • " else ""
                    val sub = dim + (f.ext ?: "").uppercase() + (if (sz > 0) " • ~" + fmtSize(sz) else "")
                    video.add(
                        Choice(
                            "Video ${n + 1} (${f.formatId})",
                            listOf(Arg("-f", f.formatId ?: "b")) + VIDEO_ARGS + extra,
                            "video", sub
                        )
                    )
                }
            }

            // ---- অডিও: MP3 (রূপান্তর) + মূল ফরম্যাটগুলো ----
            val audio = ArrayList<Choice>()
            fun mp3(q: String, label: String, sub: String) = Choice(
                label,
                listOf(Arg("-f", "ba/b"), Arg("-x"), Arg("--audio-format", "mp3"), Arg("--audio-quality", q)) + extra,
                "audio", sub
            )
            audio.add(mp3("0", "MP3 • Best", "MP3" + (if (bestAudio > 0) " • ~" + fmtSize(bestAudio) else "")))
            audio.add(mp3("192K", "MP3 • 192 kbps", "MP3"))
            audio.add(mp3("128K", "MP3 • 128 kbps", "MP3"))
            val byExt = audioFmts.groupBy { it.ext ?: "audio" }
            for ((ext, list) in byExt) {
                val best = list.maxByOrNull { size(it) } ?: continue
                val sz = size(best)
                audio.add(
                    Choice(
                        ext.uppercase() + " • Original",
                        listOf(Arg("-f", best.formatId ?: "ba/b"), Arg("-x")) + extra,
                        "audio",
                        ext.uppercase() + (if (sz > 0) " • ~" + fmtSize(sz) else "")
                    )
                )
            }
            if (byExt.isEmpty()) {
                audio.add(Choice("Original", listOf(Arg("-f", "ba/b"), Arg("-x")) + extra, "audio", ""))
            }

            val title = info.title ?: info.fulltitle ?: url
            val cacheId = metadata?.let { analysisCache.put(url, it) }
            fun cached(choices: List<Choice>) = choices.map {
                Choice(it.label, it.args, it.kind, it.sub, cacheId)
            }
            val result = Analysis(title, cached(video), cached(audio))
            memo[url] = Memo(url, System.currentTimeMillis(), result, cacheId)
            if (memo.size > 8) memo.keys.firstOrNull { it != url }?.let { memo.remove(it) }
            return result
        } finally {
            ck?.delete()
        }
    }

    fun playlistChoices(): List<Choice> {
        val base = listOf(Arg("--yes-playlist"), Arg("--ignore-errors"))
        return listOf(
            Choice("Playlist • Video (Best)", base + listOf(Arg("-f", "bv*+ba/b")) + VIDEO_ARGS, "playlist", ""),
            Choice("Playlist • Video (≤720p)", base + listOf(Arg("-f", "bv*[height<=720]+ba/b[height<=720]/b")) + VIDEO_ARGS, "playlist", ""),
            Choice(
                "Playlist • MP3",
                base + listOf(Arg("-f", "ba/b"), Arg("-x"), Arg("--audio-format", "mp3"), Arg("--audio-quality", "0")),
                "playlist", ""
            )
        )
    }


    // ---------- শক্তিশালী ডাউনলোড ম্যানেজার: নেট কাটলে অপেক্ষা, ফিরলে আবার, অ্যাপ বন্ধ হলেও মনে রাখে ----------

    private fun online(): Boolean {
        return try {
            val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val n = cm.activeNetwork ?: return false
            val c = cm.getNetworkCapabilities(n) ?: return false
            c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            true
        }
    }

    /** নেট সত্যিই কাজ করছে (ওয়াইফাই আছে কিন্তু ইন্টারনেট নেই — এমন নয়) */
    private fun validated(): Boolean {
        return try {
            val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val n = cm.activeNetwork ?: return false
            val c = cm.getNetworkCapabilities(n) ?: return false
            c.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                c.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (e: Exception) {
            true
        }
    }

    /** বাতিল হলে সাথে সাথে বের হয়; ms পর্যন্ত ঘুমায় */
    private fun sleepOrCancel(job: Job, ms: Long) {
        var left = ms
        while (left > 0 && !job.cancelRequested) {
            val step = if (left > 500) 500L else left
            Thread.sleep(step)
            left -= step
        }
    }

    /** নেট না থাকলে ফিরে আসা পর্যন্ত (সর্বোচ্চ maxMs) অপেক্ষা; এই সময় চেষ্টার গণনা বাড়ে না */
    private fun waitOnline(job: Job, maxMs: Long) {
        var waited = 0L
        // নেট আসা মাত্র নয়, সত্যিকারের ইন্টারনেট যাচাই হওয়া পর্যন্ত অপেক্ষা (৪৫ সেকেন্ড পরে যাচাই ছাড়াও ইন্টারনেট-সক্ষম নেট চলবে)
        while (!job.cancelRequested && waited < maxMs) {
            if (validated() || (waited >= 45_000L && online())) break
            sleepOrCancel(job, 2000L)
            waited += 2000L
        }
    }

    private fun partialSize(dir: File): Long {
        var t = 0L
        dir.listFiles()?.forEach { t += if (it.isFile) it.length() else 0L }
        return t
    }

    /** যে ভুলে আবার চেষ্টা করে লাভ নেই (লিংক নেই, প্রাইভেট, জায়গা নেই…) */
    private fun isPermanent(msg: String): Boolean {
        val m = msg.lowercase()
        return listOf(
            "unsupported url", "video unavailable", "private video", "sign in", "members-only", "members only",
            "copyright", "no space left", "drm", "requested format is not available", "http error 404",
            "not available in your country", "has been removed", "this video is not available"
        ).any { m.contains(it) }
    }

    private val netHandlerPending = java.util.concurrent.atomic.AtomicBoolean(false)
    /** ডিফল্ট নেট (ওয়াইফাই ↔ মোবাইল ডেটা) বদলালেই বাড়ে */
    private val netGen = AtomicInteger(0)
    @Volatile private var lastNet: Network? = null

    /**
     * নেট বদলালে/গেলে চলমান ডাউনলোডের পুরনো সংযোগ (যেটা মরা নেটে ঝুলে আছে) সাথে সাথে কেটে দিই,
     * যাতে টাইমআউটের অপেক্ষা না করে নতুন নেটে .part ফাইল থেকে আবার জুড়ে যায়।
     */
    private fun kickRunning() {
        netGen.incrementAndGet()
        for (j in jobs.toList()) {
            if (j.status != Status.RUNNING || j.cancelRequested) continue
            j.kick = true
            j.speed = 0L
            try { j.conn?.disconnect() } catch (_: Exception) { }
            try { YoutubeDL.getInstance().destroyProcessById(j.id) } catch (_: Exception) { }
        }
    }

    private fun scheduleResume() {
        if (netHandlerPending.compareAndSet(false, true)) {
            main.postDelayed({
                netHandlerPending.set(false)
                autoResume(true)
            }, 2500L)
        }
    }

    private fun watchNetwork() {
        try {
            val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            cm.registerDefaultNetworkCallback(object : ConnectivityManager.NetworkCallback() {
                // নতুন নেট যোগ হলে বা ডিফল্ট নেট বদলালে (ওয়াইফাই ↔ মোবাইল ডেটা)
                override fun onAvailable(network: Network) {
                    val before = lastNet
                    lastNet = network
                    // আগে নেট ছিল আর এখন অন্য নেট এল = সুইচ; আগে নেট না থাকলে (onLost-এ আগেই কাটা হয়েছে) আবার কাটার দরকার নেই
                    if (before != null && before != network) kickRunning()
                    scheduleResume()
                }
                override fun onLost(network: Network) {
                    if (lastNet == network) lastNet = null
                    kickRunning()
                }
                // নেট যাচাই হলে (ইন্টারনেট সত্যিই এলে) আবার চেষ্টা
                override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                    if (caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)) scheduleResume()
                }
            })
        } catch (e: Exception) {
        }
        // নেটের ঘটনা মিস হলেও: প্রতি ৬০ সেকেন্ডে নেটের কারণে থামা কাজ আবার চালু (সর্বোচ্চ ১৪৪০ বার ≈ ২৪ ঘণ্টা)
        main.postDelayed(object : Runnable {
            override fun run() {
                try { autoResume(false) } catch (e: Exception) { }
                main.postDelayed(this, 60_000L)
            }
        }, 60_000L)
    }

    /** নেটের কারণে থামা ডাউনলোডগুলো আংশিক ফাইল থেকে আবার চালু */
    fun autoResume(fromNetEvent: Boolean = true) {
        if (!online()) return
        var any = false
        for (j in jobs.toList()) {
            if (j.status == Status.FAILED && j.netFail && !j.cancelRequested) {
                if (!fromNetEvent) {
                    if (j.autoTries >= 1440) continue
                    j.autoTries++
                } else j.autoTries = 0
                retry(app, j)
                any = true
            }
        }
        if (any) notifyChange()
    }

    private fun persist() {
        try {
            val arr = JSONArray()
            for (j in jobs) {
                val keep = j.status == Status.QUEUED || j.status == Status.RUNNING ||
                    (j.status == Status.FAILED && j.netFail) || (j.status == Status.CANCELED && j.paused)
                if (!keep) continue
                val o = JSONObject()
                o.put("paused", j.paused)
                o.put("id", j.id); o.put("url", j.url); o.put("title", j.title); o.put("label", j.label)
                o.put("cookies", j.cookies ?: ""); o.put("ua", j.ua ?: "")
                o.put("referer", j.referer ?: "")
                j.headers?.let { h -> val ho = JSONObject(); for ((k, v) in h) ho.put(k, v); o.put("headers", ho) }
                val a = JSONArray()
                for (x in j.args) { val q = JSONObject(); q.put("k", x.key); q.put("v", x.value ?: JSONObject.NULL); a.put(q) }
                o.put("args", a)
                arr.put(o)
            }
            app.getSharedPreferences("mdl_jobs", Context.MODE_PRIVATE).edit().putString("jobs", arr.toString()).apply()
        } catch (e: Exception) {
        }
    }

    /** অ্যাপ/ফোন বন্ধ হয়ে গেলেও অসমাপ্ত ডাউনলোড ফিরে আসে এবং নেট থাকলে নিজে চালু হয় */
    private fun restoreJobs() {
        try {
            val str = app.getSharedPreferences("mdl_jobs", Context.MODE_PRIVATE).getString("jobs", null) ?: return
            val arr = JSONArray(str)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val args = ArrayList<Arg>()
                val a = o.getJSONArray("args")
                for (k in 0 until a.length()) {
                    val q = a.getJSONObject(k)
                    args.add(Arg(q.getString("k"), if (q.isNull("v")) null else q.getString("v")))
                }
                val job = Job(
                    o.getString("id"), o.getString("url"), o.getString("title"), args,
                    o.optString("cookies").ifEmpty { null }, o.optString("ua").ifEmpty { null }, o.optString("label"),
                    o.optString("referer").ifEmpty { null }
                )
                o.optJSONObject("headers")?.let { ho ->
                    val h = LinkedHashMap<String, String>()
                    for (k in ho.keys()) h[k] = ho.optString(k)
                    job.headers = h
                }
                if (o.optBoolean("paused")) {
                    job.status = Status.CANCELED
                    job.paused = true
                } else {
                    job.status = Status.FAILED
                    job.netFail = true
                    job.message = "interrupted"
                }
                jobs.add(job)
            }
            main.postDelayed({ autoResume() }, 4000L)
        } catch (e: Exception) {
        }
    }

    private fun startSvc(ctx: Context) {
        try {
            val i = Intent(ctx, DownloadService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        } catch (e: Exception) {
            // ব্যাকগ্রাউন্ড থেকে সার্ভিস চালু না হলেও ডাউনলোড থ্রেড চলতে থাকে
        }
    }

    // ---------- ডাউনলোড-কিউ ----------

    /** একবারই: ফোনের ব্যাটারি-সেভার যেন ব্যাকগ্রাউন্ড ডাউনলোড না কাটে, তার অনুমতি চায় */
    private fun askBatteryExemption(ctx: Context) {
        try {
            if (ctx !is android.app.Activity || Build.VERSION.SDK_INT < 23) return
            val prefs = app.getSharedPreferences("mdl_ui", Context.MODE_PRIVATE)
            if (prefs.getBoolean("bat_asked", false)) return
            prefs.edit().putBoolean("bat_asked", true).apply()
            val pm = app.getSystemService(Context.POWER_SERVICE) as android.os.PowerManager
            if (pm.isIgnoringBatteryOptimizations(app.packageName)) return
            @Suppress("BatteryLife")
            val i = Intent(android.provider.Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
                .setData(Uri.parse("package:" + app.packageName))
            ctx.startActivity(i)
        } catch (e: Exception) {
        }
    }

    fun enqueue(ctx: Context, url: String, title: String, choice: Choice, cookies: String?, ua: String?, referer: String? = null): Job {
        askBatteryExemption(ctx)
        val job = Job("j" + counter.incrementAndGet() + "_" + System.currentTimeMillis(), url, title, choice.args, cookies, ua, choice.label, referer, choice.analysisId)
        job.headers = headersFor(url)
        jobs.add(0, job)
        persist()
        pool.execute { run(job) }
        startSvc(ctx)
        notifyChange()
        return job
    }

    /** ব্যর্থ/বাতিল ডাউনলোড আবার শুরু; আংশিক ফাইল থাকলে সেখান থেকেই চলে */
    fun retry(ctx: Context, job: Job) {
        if (job.status != Status.FAILED && job.status != Status.CANCELED) return
        job.cancelRequested = false
        job.progress = 0f
        job.eta = 0L
        job.speed = 0L
        job.totalBytes = 0L
        job.message = ""
        job.netFail = false
        job.paused = false
        job.status = Status.QUEUED
        persist()
        pool.execute { run(job) }
        startSvc(ctx)
        notifyChange()
    }

    /** একই লিংক+ফরম্যাট হলে একই ফোল্ডার, যাতে .part ফাইল থেকে চালিয়ে যাওয়া যায় */
    private fun resumeDir(job: Job): File {
        // job.id যোগ: একই লিংক+ফরম্যাট দুবার দিলে আলাদা ফোল্ডার পায়; একই কাজের retry/resume একই ফোল্ডারে চলে
        val key = (job.id + "|" + job.url + "|" + job.args.joinToString(",") { it.key + "=" + (it.value ?: "") }).hashCode().toUInt().toString(16)
        return File(app.getExternalFilesDir(null) ?: app.filesDir, "dl/r_$key")
    }

    private fun isNetworkError(msg: String): Boolean {
        val m = msg.lowercase()
        return listOf(
            "timed out", "timeout", "connection", "reset", "unreachable", "network", "ssl", "eof",
            "incomplete", "http error 5", "temporary failure", "name resolution", "broken pipe", "read error",
            "no address associated", "unknown host", "unknownhost", "unable to resolve", "urlopen error", "errno",
            "remote end closed", "aborted", "handshake", "software caused", "failed to connect", "stream was reset",
            "http error 429", "http error 408", "socket closed", "stream closed", "end of stream", "unexpected end", "premature"
        ).any { m.contains(it) }
    }

    /** থামান: প্রসেস বন্ধ, কিন্তু আংশিক ফাইল থাকে; retry() দিলে সেখান থেকেই চলে */
    fun pause(job: Job) {
        if (job.status != Status.RUNNING && job.status != Status.QUEUED) return
        job.paused = true
        job.cancelRequested = true
        job.netFail = false
        if (job.status == Status.RUNNING) YoutubeDL.getInstance().destroyProcessById(job.id)
        else finish(job, Status.CANCELED, "")
    }

    /** তালিকা থেকে সরিয়ে আংশিক ফাইলও মুছে ফেলে */
    fun discard(job: Job) {
        job.cancelRequested = true
        job.netFail = false
        job.paused = false
        if (job.status == Status.RUNNING) YoutubeDL.getInstance().destroyProcessById(job.id)
        jobs.remove(job)
        try { resumeDir(job).deleteRecursively() } catch (e: Exception) {}
        persist()
        notifyChange()
    }

    /** এ পর্যন্ত নামা সবচেয়ে বড় আংশিক ফাইল (প্লেয়ারে দেখার জন্য) */
    fun partialFile(job: Job): File? =
        resumeDir(job).listFiles()?.filter { it.isFile && it.length() > 0 }?.maxByOrNull { it.length() }

    fun cancel(job: Job) {
        job.cancelRequested = true
        job.netFail = false
        if (job.status == Status.RUNNING) {
            YoutubeDL.getInstance().destroyProcessById(job.id)
        } else if (job.status == Status.QUEUED) {
            finish(job, Status.CANCELED, "")
        }
    }

    fun clearFinished() {
        jobs.removeAll(jobs.filter {
            it.status == Status.DONE ||
                ((it.status == Status.FAILED || it.status == Status.CANCELED) && !it.paused)
        })
        persist()   // না করলে মোছা ব্যর্থ কাজ সংরক্ষিত তালিকা থেকে অ্যাপ খুললে ফিরে আসে
        notifyChange()
    }

    private fun finish(job: Job, st: Status, msg: String) {
        job.status = st
        job.message = msg
        job.speed = 0L
        persist()
        notifyChange()
        when (st) {
            Status.DONE -> toast(L.t("dlDone") + job.title.take(40))
            Status.FAILED -> toast(L.t("dlFailed") + msg)
            else -> {}
        }
    }

    /** ছোট (১ MB-এর কম) m3u8/mpd প্লেলিস্ট ফাইল: নাম বা শুরুর লেখা দেখে চেনা যায় */
    private fun isPlaylistStub(f: File): Boolean {
        val ext = f.extension.lowercase()
        if (ext == "m3u8" || ext == "m3u" || ext == "mpd") return f.length() < 1024 * 1024
        if (f.length() > 1024 * 1024 || isTemp(f.name)) return false
        return try {
            f.inputStream().use { ins ->
                val b = ByteArray(7)
                val n = ins.read(b)
                n == 7 && String(b, Charsets.ISO_8859_1) == "#EXTM3U"
            }
        } catch (e: Exception) { false }
    }

    private fun isTemp(name: String): Boolean =
        name.contains(".part") || name.endsWith(".ytdl") || name.endsWith(".temp") || name.endsWith(".tmp")

    private fun run(job: Job) {
        if (job.status != Status.QUEUED) return   // পুরনো/দ্বিতীয় কাজ হলে বাদ
        if (job.cancelRequested) {
            finish(job, Status.CANCELED, "")
            return
        }
        job.status = Status.RUNNING
        job.message = "preparing"
        notifyChange()

        if (job.args.any { it.key == NATIVE_FILE }) { runNative(job); return }

        val tmp = resumeDir(job)
        tmp.mkdirs()
        val ck = cookieFile(job.url, job.cookies)
        val infoFile = File(app.cacheDir, "${job.id}.info.json")
        try {
            waitReady()
            val playlist = job.args.any { it.key == "--yes-playlist" }
            val tpl = if (playlist) "%(playlist_index)s - %(title).100B.%(ext)s" else "%(title).100B.%(ext)s"

            var useCached = !playlist && analysisCache.get(job.analysisId, job.url)?.let {
                infoFile.writeText(it)
                true
            } == true
            fun build(viaFfmpeg: Boolean = false): YoutubeDLRequest {
                // Never pass both the page URL and --load-info-json: that can download twice.
                val req = if (useCached) YoutubeDLRequest(emptyList<String>()) else YoutubeDLRequest(job.url)
                if (useCached) {
                    req.addOption("--load-info-json", infoFile.absolutePath)
                    req.addOption("--no-check-formats")
                }
                req.addOption("-o", File(tmp, tpl).absolutePath)
                req.addOption("--no-mtime")
                req.addOption("--no-warnings")
                req.addOption("--retries", 3)
                req.addOption("--fragment-retries", 5)
                req.addOption("--file-access-retries", 2)
                req.addOption("--extractor-retries", 1)
                req.addOption("--retry-sleep", "exp=1:5")
                // Re-extracting every time bandwidth falls below 100K delayed slow connections.
                val fastSite = isFastSite(job.url)
                // HLS/DASH স্পিড: বেশি সমান্তরাল ফ্র্যাগমেন্ট + বড় বাফার। ফাস্ট সাইটে ১৬, অন্যত্র ৮ (আগে ৪ ছিল)।
                // খুব বেশি কানেকশন কিছু হোস্ট রিজেক্ট করে, তাই ৮/১৬ সীমা রাখা হয়েছে।
                req.addOption("--concurrent-fragments", if (fastSite) 16 else 8)
                req.addOption("--buffer-size", if (fastSite) "1M" else "512K")
                // YouTube সার্ভার বড় ফাইলের স্পিড কমায়; ১০ এমবি করে টুকরো চাইলে পুরো স্পিড পাওয়া যায়
                val host = Uri.parse(job.url).host?.lowercase().orEmpty()
                if (isYoutube(job.url) || host == "googlevideo.com" || host.endsWith(".googlevideo.com")) {
                    req.addOption("--http-chunk-size", "10M")
                }
                // কিছু CDN-এ fragment timeout কমিয়ে দ্রুত রিট্রাই
                req.addOption("--socket-timeout", if (fastSite) 10 else 12)
                // Native HTTP/HLS/DASH first: no external process startup or 16-connection rejection.
                if (!playlist) req.addOption("--no-playlist")
                // প্লেলিস্ট (m3u8) ফাইল সরাসরি নেমে গেলে দ্বিতীয়বার ffmpeg দিয়ে পুরো ভিডিও জোড়া লাগিয়ে নামানো হয়
                if (viaFfmpeg) req.addOption("--downloader", "ffmpeg")
                commonNet(req, ck, job.ua, job.referer, job.headers)
                // সাবটাইটেল (সেটিংস থেকে): ভিডিওর পাশে .srt ফাইল নামে; না পেলে ভিডিও ডাউনলোড বন্ধ হয় না
                val subPref = L.subLang()
                if (subPref != "off" && job.args.none { it.key == "-x" }) {
                    req.addOption("--write-subs")
                    req.addOption("--write-auto-subs")
                    req.addOption("--sub-langs", when (subPref) {
                        "bn" -> "bn.*"
                        "en" -> "en.*"
                        else -> "bn.*,en.*"
                    })
                    req.addOption("--convert-subs", "srt")
                }
                for (a in job.args) {
                    val v = a.value
                    if (v == null) req.addOption(a.key) else req.addOption(a.key, v)
                }

                req.addOption("--continue")
                return req
            }
            var req = build()
            var fails = 0
            var lastSize = partialSize(tmp)
            while (true) {
                job.kick = false
                job.attemptGen = netGen.get()
                try {
                    if (job.cancelRequested) throw YoutubeDL.CanceledException()
                    if (useCached && analysisCache.get(job.analysisId, job.url) == null) {
                        useCached = false
                        req = build()
                    }
                    // ভিডিও+অডিও আলাদা স্ট্রিমে নামে (bv*+ba): দুই স্ট্রিম মিলিয়ে একটাই মোট সাইজ ও প্রোগ্রেস দেখানো হবে
                    val streams = if (job.args.any { it.key == "-f" && (it.value ?: "").contains("+") }) 2 else 1
                    var sIdx = 0
                    var doneBytes = 0L
                    var curBytes = 0L
                    YoutubeDL.getInstance().execute(req, job.id) { p, eta, line ->
                        val ln: String = line ?: ""
                        if (ln.startsWith("[download]") || RX_SPEED.containsMatchIn(ln)) job.message = ""
                        // সাবটাইটেল ফাইলের "Destination:" লাইন ভিডিও/অডিও স্ট্রিম হিসেবে গোনা হবে না
                        val isSubLine = ln.contains("Destination:") && RX_SUBEXT.containsMatchIn(ln)
                        if (!isSubLine && (ln.contains("Destination:") || ln.contains("has already been downloaded"))) {
                            if (sIdx > 0) { doneBytes += curBytes; curBytes = 0L }
                            if (sIdx < streams) sIdx++
                        }
                        val idx = if (sIdx < 1) 1 else sIdx
                        job.progress = if (streams > 1) (((idx - 1) * 100f + p) / streams).coerceIn(0f, 100f) else p
                        job.eta = eta
                        RX_SIZE.find(ln)?.let { curBytes = toBytes(it.groupValues[1], it.groupValues[2]); job.totalBytes = doneBytes + curBytes }
                        RX_SPEED.find(ln)?.let { job.speed = toBytes(it.groupValues[1], it.groupValues[2]) }
                        val now = System.currentTimeMillis()
                        if (now - job.lastNotifyMs > 500) {
                            job.lastNotifyMs = now
                            notifyChange()
                        }
                    }
                    break
                } catch (e: YoutubeDL.CanceledException) {
                    // ব্যবহারকারী বাতিল করেনি, আমরাই নেট বদলের কারণে প্রসেস কেটেছি: নতুন নেটে আবার চালাই
                    if (job.kick && !job.cancelRequested) {
                        job.message = "reconnecting"
                        job.speed = 0L
                        notifyChange()
                        waitOnline(job, 30L * 60 * 1000)
                        continue
                    }
                    throw e
                } catch (e: Exception) {
                    // কাটলে হাল ছাড়ে না: নেট ফিরলে .part ফাইল থেকেই আবার চলে। কিছুটা এগোলে চেষ্টার গণনা শূন্য হয়
                    if (job.cancelRequested) throw e
                    val em = e.message ?: ""
                    val el = em.lowercase()
                    // Signed URLs can expire before the TTL: re-extract the page exactly once.
                    if (useCached && listOf("403", "401", "410", "404", "forbidden", "expired", "requested format", "unable to download", "invalid").any { el.contains(it) }) {
                        analysisCache.remove(job.analysisId)
                        useCached = false
                        req = build()
                        job.message = "refreshing"
                        notifyChange()
                        continue
                    }
                    // নেট/আইপি বদলের পর সাইনড-লিংকে 403 আসতে পারে: লিংক নতুন করে বের করে আবার চেষ্টা (একবারই)
                    if (job.attemptGen != netGen.get() &&
                        listOf("403", "forbidden", "410", "expired").any { el.contains(it) }) {
                        job.message = "reconnecting"
                        job.speed = 0L
                        notifyChange()
                        waitOnline(job, 30L * 60 * 1000)
                        continue
                    }
                    if (isPermanent(em)) throw e
                    // Authentication, extractor and storage errors aren't connection failures.
                    if (!isNetworkError(em) && !job.kick) throw e
                    val size = partialSize(tmp)
                    if (size > lastSize + 64 * 1024) fails = 0
                    lastSize = size
                    // নেট না থাকা বা নেট বদলানোর কাটা চেষ্টার গণনায় ধরা হয় না
                    if (!job.kick && validated()) fails++
                    if (fails > 300) { job.netFail = true; throw e }
                    job.message = "reconnecting"
                    job.speed = 0L
                    notifyChange()
                    waitOnline(job, 30L * 60 * 1000)
                    sleepOrCancel(job, minOf(2000L * fails, 20000L))
                    if (job.cancelRequested) throw Exception("canceled")
                }
            }

            // কয়েক কিলোবাইটের m3u8/mpd প্লেলিস্ট ফাইল নেমে থাকলে সেটা ভিডিও নয়: মুছে ffmpeg দিয়ে আসল ভিডিও নামাই
            val stubs = tmp.listFiles()?.filter { it.isFile && isPlaylistStub(it) } ?: emptyList()
            if (stubs.isNotEmpty() && !job.cancelRequested) {
                stubs.forEach { it.delete() }
                job.message = ""
                job.progress = 0f
                notifyChange()
                YoutubeDL.getInstance().execute(build(true), job.id) { p, eta, line ->
                    val ln: String = line ?: ""
                    job.progress = p
                    job.eta = eta
                    RX_SIZE.find(ln)?.let { job.totalBytes = toBytes(it.groupValues[1], it.groupValues[2]) }
                    RX_SPEED.find(ln)?.let { job.speed = toBytes(it.groupValues[1], it.groupValues[2]) }
                    val now = System.currentTimeMillis()
                    if (now - job.lastNotifyMs > 500) { job.lastNotifyMs = now; notifyChange() }
                }
            }
            val all = tmp.listFiles()?.filter { it.isFile && !isTemp(it.name) && !isPlaylistStub(it) } ?: emptyList()
            val files = all.filter { it.extension.lowercase() !in SUB_EXT }
            val subs = all.filter { it.extension.lowercase() in SUB_EXT }
            if (files.isEmpty()) throw Exception(L.t("noFile"))
            var last = ""
            for (f in files) {
                last = publish(f)
                History.add(last, job.url, "yt", job.title, job.args, f.length(),
                    MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "")
            }
            // সাবটাইটেল ভিডিওর পাশের ফোল্ডারে যায়; তালিকায় আলাদা ফাইল হিসেবে দেখানো হয় না
            for (f in subs) { try { publish(f) } catch (e: Exception) { } }
            job.saved = last
            job.progress = 100f
            finish(job, Status.DONE, last)
        } catch (e: YoutubeDL.CanceledException) {
            if (job.kick && !job.cancelRequested) { job.netFail = true; finish(job, Status.FAILED, "network changed") }
            else finish(job, Status.CANCELED, "")
        } catch (e: Exception) {
            if (job.cancelRequested) {
                finish(job, Status.CANCELED, "")
            } else {
                // yt-dlp ৪০৩/ব্লক → ব্রাউজার সেশনের কুকি/হেডার দিয়ে নেটিভ HLS ফলব্যাক
                val em = (e.message ?: "").lowercase()
                val blocked = listOf("403", "forbidden", "401", "refused", "automated").any { em.contains(it) }
                if (blocked && looksLikeStream(job.url) && !job.cancelRequested) {
                    try {
                        job.message = "browser-session"
                        job.progress = 0f
                        notifyChange()
                        val out = nativeHlsDownload(job, tmp)
                        val path = publish(out)
                        History.add(path, job.url, "hls-native", job.title, job.args, out.length(),
                            MimeTypeMap.getSingleton().getMimeTypeFromExtension(out.extension.lowercase()) ?: "video/mp4")
                        job.saved = path
                        job.progress = 100f
                        finish(job, Status.DONE, path)
                        return
                    } catch (e2: Exception) {
                        if (job.cancelRequested) {
                            finish(job, Status.CANCELED, "")
                            return
                        }
                        // নেটিভও ব্যর্থ → আগের এরর দেখাই
                    }
                }
                if (isNetworkError(e.message ?: "") || job.kick) job.netFail = true
                finish(job, Status.FAILED, shortError(e))
            }
        } finally {
            ck?.delete()
            infoFile.delete()
            // সফল বা বাতিল হলে আংশিক ফাইল মুছে যায়; ব্যর্থ হলে থাকে, যাতে Re-download সেখান থেকে চলে
            if (job.status == Status.DONE || (job.status == Status.CANCELED && !job.paused)) tmp.deleteRecursively()
        }
    }

    private fun looksLikeStream(u: String): Boolean {
        val l = u.lowercase()
        return l.contains(".m3u8") || l.contains("m3u8?") || l.contains("/hls/") ||
            l.contains("format=m3u8") || l.contains(".mpd") || l.contains("mpegurl")
    }

    /**
     * ব্রাউজারের কুকি/Referer/UA দিয়ে m3u8 এনে সেগমেন্ট নামিয়ে জোড়া লাগায়।
     * yt-dlp যখন ৪০৩ পায় তখন এই পথ অনেক জাপানি/CDN সাইটে কাজ করে।
     */
    private fun nativeHlsDownload(job: Job, tmp: File): File {
        tmp.mkdirs()
        val ua = job.ua ?: "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
        val referer = job.referer ?: job.headers?.get("Referer") ?: job.url
        fun open(url: String): java.net.HttpURLConnection {
            val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
            job.conn = c
            c.instanceFollowRedirects = true
            c.connectTimeout = 20000
            c.readTimeout = 45000
            c.requestMethod = "GET"
            c.setRequestProperty("User-Agent", ua)
            c.setRequestProperty("Accept", "*/*")
            if (referer.isNotBlank()) {
                c.setRequestProperty("Referer", referer)
                try {
                    val o = Uri.parse(referer)
                    c.setRequestProperty("Origin", "${o.scheme}://${o.authority}")
                } catch (_: Exception) { }
            }
            job.cookies?.takeIf { it.isNotBlank() }?.let { c.setRequestProperty("Cookie", it) }
            job.headers?.forEach { (k, v) ->
                if (k.equals("User-Agent", true) || k.equals("Referer", true) ||
                    k.equals("Cookie", true) || k.equals("Origin", true)) return@forEach
                try { c.setRequestProperty(k, v) } catch (_: Exception) { }
            }
            return c
        }
        fun fetchText(url: String): Pair<String, String> {
            if (job.cancelRequested) throw Exception("canceled")
            val c = open(url)
            try {
                val code = c.responseCode
                if (code !in 200..299) throw Exception("HTTP $code")
                val finalUrl = c.url?.toString() ?: url
                val text = c.inputStream.bufferedReader().use { it.readText() }
                if (text.length > 3_000_000) throw Exception("playlist too large")
                return text to finalUrl
            } finally { c.disconnect() }
        }
        fun resolve(base: String, ref: String): String {
            if (ref.startsWith("http://") || ref.startsWith("https://")) return ref
            return try { java.net.URL(java.net.URL(base), ref).toString() } catch (_: Exception) { ref }
        }
        // মাস্টার হলে সর্বোচ্চ ব্যান্ডউইথ ভ্যারিয়েন্ট বেছে নাও
        var (text, base) = fetchText(job.url)
        if (!text.trimStart('\uFEFF', ' ', '\r', '\n', '\t').startsWith("#EXTM3U")) {
            throw Exception("not an HLS playlist")
        }
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.any { it.startsWith("#EXT-X-STREAM-INF", ignoreCase = true) }) {
            var bestBw = -1L
            var bestUrl: String? = null
            var i = 0
            while (i < lines.size) {
                val line = lines[i]
                if (line.startsWith("#EXT-X-STREAM-INF", ignoreCase = true)) {
                    val bw = Regex("BANDWIDTH=(\\d+)").find(line)?.groupValues?.get(1)?.toLongOrNull() ?: 0L
                    i++
                    while (i < lines.size && lines[i].startsWith("#")) i++
                    if (i < lines.size && !lines[i].startsWith("#")) {
                        if (bw >= bestBw) {
                            bestBw = bw
                            bestUrl = resolve(base, lines[i])
                        }
                    }
                }
                i++
            }
            val variant = bestUrl ?: throw Exception("no HLS variant")
            val fetched = fetchText(variant)
            text = fetched.first
            base = fetched.second
        }
        // মিডিয়া প্লেলিস্ট → সেগমেন্ট লিস্ট
        val segs = ArrayList<String>()
        var initUrl: String? = null
        for (line in text.lines().map { it.trim() }.filter { it.isNotEmpty() }) {
            if (line.startsWith("#EXT-X-MAP:", ignoreCase = true)) {
                val uri = Regex("URI=\"([^\"]+)\"").find(line)?.groupValues?.get(1)
                if (uri != null) initUrl = resolve(base, uri)
            } else if (!line.startsWith("#")) {
                segs.add(resolve(base, line))
            }
        }
        if (segs.isEmpty()) throw Exception("no segments")
        val raw = File(tmp, "native_" + System.currentTimeMillis() + ".ts")
        job.totalBytes = 0L
        var written = 0L
        java.io.FileOutputStream(raw).use { fos ->
            fun appendUrl(u: String) {
                if (job.cancelRequested) throw Exception("canceled")
                val c = open(u)
                try {
                    if (c.responseCode !in 200..299) throw Exception("segment HTTP ${c.responseCode}")
                    c.inputStream.use { ins ->
                        val buf = ByteArray(64 * 1024)
                        while (true) {
                            val n = ins.read(buf)
                            if (n < 0) break
                            fos.write(buf, 0, n)
                            written += n
                            job.totalBytes = written
                            val now = System.currentTimeMillis()
                            if (now - job.lastNotifyMs > 400) {
                                job.lastNotifyMs = now
                                notifyChange()
                            }
                        }
                    }
                } finally { c.disconnect() }
            }
            initUrl?.let { appendUrl(it) }
            val total = segs.size
            for ((idx, seg) in segs.withIndex()) {
                if (job.cancelRequested) throw Exception("canceled")
                appendUrl(seg)
                job.progress = ((idx + 1) * 100f / total).coerceIn(0f, 99f)
                job.message = ""
                notifyChange()
            }
        }
        if (raw.length() < 1024) throw Exception("empty download")
        // ffmpeg দিয়ে mp4-এ রিমাক্স; ব্যর্থ হলে .ts ফাইলই সেভ
        // রিফ্লেকশন দিয়ে ffmpeg রিমাক্স — কম্পাইল-টাইমে execute সিগনেচার ধরা হয় না
        val remuxed = File(tmp, "remux_" + System.currentTimeMillis() + ".mp4")
        try {
            val cmd = arrayOf(
                "-y", "-nostdin", "-loglevel", "error",
                "-i", raw.absolutePath,
                "-c", "copy", "-bsf:a", "aac_adtstoasc", "-movflags", "+faststart",
                remuxed.absolutePath
            )
            val ff = FFmpeg.getInstance()
            for (m in ff.javaClass.methods) {
                if (m.name != "execute") continue
                val params = m.parameterTypes
                if (params.isEmpty() || params[0] != Array<String>::class.java) continue
                try {
                    val args = arrayOfNulls<Any>(params.size)
                    args[0] = cmd
                    m.invoke(ff, *args)
                    break
                } catch (_: Throwable) { }
            }
            if (remuxed.exists() && remuxed.length() > 1024) {
                raw.delete()
                return remuxed
            }
        } catch (_: Exception) { }
        // remux না হলে .ts নামেই রাখি (অনেক প্লেয়ার চালায়)
        val tsOut = File(tmp, "video_" + System.currentTimeMillis() + ".ts")
        if (raw.renameTo(tsOut)) return tsOut
        return raw
    }

    /** চিহ্ন-আর্গ: এই কাজ yt-dlp নয়, অ্যাপের নিজস্ব HTTP ডাউনলোডারে (zip/apk/pdf ইত্যাদি সাধারণ ফাইল) চলবে */
    const val NATIVE_FILE = "--native-file"

    /** সাধারণ ফাইল-লিংক: অ্যাপের ভিতরেই নামে (সিস্টেম DownloadManager নয়); থামানো/আবার চালু/নেট কাটলে .part থেকে চলে */
    fun enqueueFile(ctx: Context, url: String, name: String, cookies: String?, ua: String?, referer: String?): Job {
        val choice = Choice(name, listOf(Arg(NATIVE_FILE)), "video", "file")
        return enqueue(ctx, url, name, choice, cookies, ua, referer)
    }

    private fun safeFileName(raw: String): String {
        var n = raw.replace(Regex("""[\\/:*?"<>|\u0000-\u001f]"""), "_").trim().trim('.')
        if (n.isEmpty()) n = "file"
        if (n.length > 150) {
            val ext = n.substringAfterLast('.', "")
            n = if (ext.length in 1..8) n.take(140) + "." + ext else n.take(150)
        }
        return n
    }

    private fun nameFromDisposition(cd: String?): String? {
        if (cd.isNullOrBlank()) return null
        Regex("""filename\*\s*=\s*(?:UTF-8|utf-8)''([^;]+)""").find(cd)?.let {
            return try { java.net.URLDecoder.decode(it.groupValues[1].trim().trim('"'), "UTF-8") } catch (e: Exception) { null }
        }
        Regex("""filename\s*=\s*"?([^";]+)"?""").find(cd)?.let { return it.groupValues[1].trim() }
        return null
    }

    private fun runNative(job: Job) {
        val tmp = resumeDir(job)
        tmp.mkdirs()
        val finalName = safeFileName(job.title)
        val part = File(tmp, "$finalName.part")
        try {
            var fails = 0
            var lastSize = part.length()
            var saveName = finalName
            while (true) {
                job.kick = false
                try {
                    if (job.cancelRequested) throw Exception("canceled")
                    saveName = nativeFetch(job, part, saveName)
                    break
                } catch (e: Exception) {
                    if (job.cancelRequested) throw e
                    val em = e.message ?: ""
                    if (!isNetworkError(em) && !job.kick) throw e
                    val size = part.length()
                    if (size > lastSize + 64 * 1024) fails = 0
                    lastSize = size
                    if (!job.kick && validated()) fails++
                    if (fails > 300) { job.netFail = true; throw e }
                    job.message = "reconnecting"
                    job.speed = 0L
                    notifyChange()
                    waitOnline(job, 30L * 60 * 1000)
                    sleepOrCancel(job, minOf(2000L * fails, 20000L))
                    if (job.cancelRequested) throw Exception("canceled")
                }
            }
            val done = File(tmp, saveName)
            if (done.exists()) done.delete()
            if (!part.renameTo(done)) { part.copyTo(done, overwrite = true); part.delete() }
            val path = publish(done)
            History.add(path, job.url, "direct", job.title, null, done.length(),
                MimeTypeMap.getSingleton().getMimeTypeFromExtension(done.extension.lowercase()) ?: "")
            job.saved = path
            job.progress = 100f
            finish(job, Status.DONE, path)
        } catch (e: Exception) {
            if (job.cancelRequested) finish(job, Status.CANCELED, "")
            else {
                if (isNetworkError(e.message ?: "")) job.netFail = true
                finish(job, Status.FAILED, (e.message ?: "error").take(120))
            }
        } finally {
            if (job.status == Status.DONE || (job.status == Status.CANCELED && !job.paused)) tmp.deleteRecursively()
        }
    }

    /** একবারের চেষ্টা: .part-এর শেষ থেকে চালায়। ফাইলের চূড়ান্ত নাম ফেরত দেয় */
    private fun nativeFetch(job: Job, part: File, name: String): String {
        var url = job.url
        var conn: java.net.HttpURLConnection? = null
        var resumeFrom = part.length()
        var saveName = name
        try {
            var hops = 0
            while (true) {
                val c = java.net.URL(url).openConnection() as java.net.HttpURLConnection
                job.conn = c
                c.instanceFollowRedirects = false
                c.connectTimeout = 20000
                c.readTimeout = 25000
                c.setRequestProperty("User-Agent", job.ua ?: "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36")
                c.setRequestProperty("Accept", "*/*")
                c.setRequestProperty("Accept-Encoding", "identity")
                if (!job.cookies.isNullOrBlank()) c.setRequestProperty("Cookie", job.cookies)
                val hdr = job.headers
                val refUsed = hdr?.get("Referer") ?: job.referer
                if (!refUsed.isNullOrBlank()) c.setRequestProperty("Referer", refUsed)
                if (hdr != null) for ((k, v) in hdr) if (!k.equals("Referer", true)) c.setRequestProperty(k, v)
                if (resumeFrom > 0) c.setRequestProperty("Range", "bytes=$resumeFrom-")
                val code = c.responseCode
                if (code in 301..303 || code == 307 || code == 308) {
                    val loc = c.getHeaderField("Location") ?: throw Exception("HTTP $code redirect")
                    url = java.net.URL(java.net.URL(url), loc).toString()
                    c.disconnect()
                    if (++hops > 10) throw Exception("too many redirects")
                    continue
                }
                if (code == 416 && resumeFrom > 0) {
                    // আংশিক ফাইল ঠিক নেই বা আগেই সম্পূর্ণ; পুরোটা নতুন করে
                    c.disconnect()
                    part.delete()
                    resumeFrom = 0
                    continue
                }
                if (code != 200 && code != 206) { c.disconnect(); throw Exception("HTTP error $code") }
                conn = c
                break
            }
            val c = conn!!
            nameFromDisposition(c.getHeaderField("Content-Disposition"))?.let {
                // শুধু তখনই বদলাই যখন আমাদের জানা নামে এক্সটেনশন নেই
                if (!name.substringAfterLast('.', "").let { e -> e.length in 1..8 }) saveName = safeFileName(it)
            }
            val resumed = c.responseCode == 206 && resumeFrom > 0
            if (!resumed && part.exists()) { part.delete(); resumeFrom = 0 }
            val len = c.contentLengthLong
            val total = if (len > 0) len + (if (resumed) resumeFrom else 0L) else 0L
            job.totalBytes = total
            job.message = ""
            notifyChange()
            val buf = ByteArray(64 * 1024)
            var got = if (resumed) resumeFrom else 0L
            var winStart = System.currentTimeMillis()
            var winBytes = 0L
            java.io.FileOutputStream(part, resumed).use { out ->
                c.inputStream.use { ins ->
                    while (true) {
                        if (job.cancelRequested) throw Exception("canceled")
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        got += n; winBytes += n
                        val now = System.currentTimeMillis()
                        if (now - winStart >= 500) {
                            job.speed = winBytes * 1000 / (now - winStart)
                            winStart = now; winBytes = 0L
                            if (total > 0) {
                                job.progress = (got * 100f / total).coerceIn(0f, 100f)
                                job.eta = if (job.speed > 0) (total - got) / job.speed else 0L
                            }
                            if (now - job.lastNotifyMs > 500) { job.lastNotifyMs = now; notifyChange() }
                        }
                    }
                }
            }
            if (total > 0 && got < total) throw Exception("incomplete download")
            return saveName
        } finally {
            job.conn = null
            try { conn?.disconnect() } catch (_: Exception) { }
        }
    }

    /** ৭ দিনের পুরনো অসমাপ্ত ফাইল পরিষ্কার */
    private fun cleanOldPartials() {
        try {
            val d = File(app.getExternalFilesDir(null) ?: app.filesDir, "dl")
            val limit = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
            d.listFiles()?.forEach { if (it.lastModified() < limit) it.deleteRecursively() }
        } catch (e: Exception) {
        }
    }

    /** ফাইলের দেখানোর নাম: সাধারণ পাথ হলে শেষ অংশ, বাছা-ফোল্ডারের (content://) ফাইল হলে সিস্টেম থেকে */
    fun displayNameOf(path: String): String {
        if (!path.startsWith("content://")) return path.substringAfterLast('/')
        val n = try {
            app.contentResolver.query(Uri.parse(path), arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                ?.use { c -> if (c.moveToFirst()) c.getString(0) else null }
        } catch (e: Exception) { null }
        return n ?: Uri.decode(path).substringAfterLast('/')
    }

    /** ব্যবহারকারীর বাছা ফোল্ডারের নাম; ডিফল্ট হলে খালি */
    fun saveFolderLabel(): String {
        val t = L.saveTree()
        if (t.isEmpty()) return ""
        return try {
            val id = android.provider.DocumentsContract.getTreeDocumentId(Uri.parse(t))
            val n = id.substringAfter(':', "")
            if (n.isEmpty()) "Internal storage" else n
        } catch (e: Exception) { "Custom" }
    }

    /** ব্যবহারকারীর বাছা ফোল্ডারে কপি; ফেরত দেয় ফাইলের content:// Uri */
    private fun publishToTree(f: File, tree: Uri): String {
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "application/octet-stream"
        val parent = android.provider.DocumentsContract.buildDocumentUriUsingTree(
            tree, android.provider.DocumentsContract.getTreeDocumentId(tree)
        )
        val resolver = app.contentResolver
        val doc = android.provider.DocumentsContract.createDocument(resolver, parent, mime, f.name)
            ?: throw Exception(L.t("mkFail"))
        try {
            resolver.openOutputStream(doc)!!.use { out -> f.inputStream().use { it.copyTo(out) } }
        } catch (e: Exception) {
            try { android.provider.DocumentsContract.deleteDocument(resolver, doc) } catch (_: Exception) { }
            throw e
        }
        return doc.toString()
    }

    /** ফাইলটা ব্যবহারকারীর বাছা ফোল্ডারে (না বাছলে ফোনের Downloads/MediaDownloader ফোল্ডারে) সরায় */
    private fun publish(f: File): String {
        val tree = L.saveTree()
        if (tree.isNotEmpty()) {
            // ফোল্ডার মুছে গেলে/অনুমতি চলে গেলে ডিফল্টে সেভ হয়, ডাউনলোড নষ্ট হয় না
            try { return publishToTree(f, Uri.parse(tree)) } catch (e: Exception) { }
        }
        val ext = f.extension.lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        if (Build.VERSION.SDK_INT >= 29) {
            val resolver = app.contentResolver
            val cv = ContentValues()
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime)
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MediaDownloader")
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1)
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                ?: throw Exception(L.t("mkFail"))
            resolver.openOutputStream(uri)!!.use { out -> f.inputStream().use { it.copyTo(out) } }
            val done = ContentValues()
            done.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, done, null, null)
            // নামে মিল থাকলে সিস্টেম নাম বদলে দেয়; আসল নামটা নিয়ে নেওয়া
            var realName = f.name
            resolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) realName = c.getString(0) ?: f.name
            }
            return "Download/MediaDownloader/" + realName
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "MediaDownloader")
            dir.mkdirs()
            val dest = File(dir, f.name)
            f.copyTo(dest, overwrite = true)
            MediaScannerConnection.scanFile(app, arrayOf(dest.absolutePath), arrayOf(mime), null)
        }
        return "Download/MediaDownloader/" + f.name
    }
}
