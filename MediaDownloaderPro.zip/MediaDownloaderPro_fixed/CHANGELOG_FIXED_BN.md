# MediaDownloaderPro — এই সংস্করণের পরিবর্তন

- Cloudflare/anti-bot/HTTP 403/429 ব্যর্থতা এখন পরিষ্কারভাবে দেখায়; অ্যাপ site access control bypass করার চেষ্টা করে না।
- yt-dlp analysis-এ audio `filesize` না থাকলে duration-ভিত্তিক আনুমানিক size দেখায়, তাই audio option-এ size blank থাকে না (এটি estimate, final output size নয়)।
- Downloads/MediaDownloader-এর বাস্তব file size প্রতিবার Files তালিকা refresh-এ MediaStore থেকে পড়ে history-তে update হয়।
- MIME type history-তে সংরক্ষিত হয়; extension না থাকলেও audio file-এ audio icon এবং built-in player-এর audio mode সঠিকভাবে কাজ করে।
- DownloadManager fallback সফল হলে media MIME history-তে লেখা হয়।

## সীমাবদ্ধতা

- Cloudflare challenge, CAPTCHA, login wall, DRM বা অন্য site access control bypass করা হয়নি এবং করা উচিতও নয়। অনুমোদিত/public media URL বা সাইটের official download/export ব্যবহার করুন।
- Android SDK না থাকায় এই sandbox-এ APK assemble করা যায়নি। Android Studio/CI environment-এ `./gradlew :app:assembleDebug` চালিয়ে final build করুন।
