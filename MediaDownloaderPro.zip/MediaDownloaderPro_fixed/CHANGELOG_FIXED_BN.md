# সংস্করণ 2.7 — পরিবর্তন

- **আপডেট চেক:** সেটিংসে "এবাউট"-এর উপরে "আপডেট চেক করুন" যোগ হয়েছে (পাশে বর্তমান সংস্করণ দেখায়)। চাপলে GitHub রিলিজ দেখে জানায় আপডেট আছে কিনা। আপডেট থাকলে "আপডেট করুন" চাপলে APK-র লিংক অ্যাপের নিজের ব্রাউজারে খোলে, ডাউনলোড অ্যাপের ভিতরের ডাউনলোডারে হয়, শেষ হলে ইনস্টলার নিজে খোলে। সিস্টেম ডাউনলোড ম্যানেজার আর ব্যবহার হয় না।
- **ডিফল্ট ব্রাউজার:** আগে ম্যানিফেস্টে http/https লিংকের ফিল্টার ছিল না, তাই ফোন এই অ্যাপকে ব্রাউজার হিসেবে চিনত না। ফিল্টার যোগ হয়েছে; অন্য অ্যাপের লিংক এখন এই অ্যাপের নতুন ট্যাবে খোলে। সেটিংসে "ডিফল্ট ব্রাউজার করুন" বাটনও আছে।
- **সব ডাউনলোড অ্যাপের ভিতরে:** zip/apk/pdf ইত্যাদি সাধারণ ফাইলও এখন অ্যাপের নিজস্ব ডাউনলোডারে নামে (প্রগ্রেস, থামানো/চালু, নেট কাটলে আংশিক ফাইল থেকে চালানো, ডাউনলোড তালিকা — সব অ্যাপের ভিতরেই)। ডাউনলোড ম্যানেজারে আর কিছু যায় না। ফাইল আগের মতোই Downloads/MediaDownloader ফোল্ডারে সেভ হয়।

# MediaDownloaderPro — এই সংস্করণের পরিবর্তন

- Cloudflare/anti-bot/HTTP 403/429 ব্যর্থতা এখন পরিষ্কারভাবে দেখায়; অ্যাপ site access control bypass করার চেষ্টা করে না।
- yt-dlp analysis-এ audio `filesize` না থাকলে duration-ভিত্তিক আনুমানিক size দেখায়, তাই audio option-এ size blank থাকে না (এটি estimate, final output size নয়)।
- Downloads/MediaDownloader-এর বাস্তব file size প্রতিবার Files তালিকা refresh-এ MediaStore থেকে পড়ে history-তে update হয়।
- MIME type history-তে সংরক্ষিত হয়; extension না থাকলেও audio file-এ audio icon এবং built-in player-এর audio mode সঠিকভাবে কাজ করে।
- DownloadManager fallback সফল হলে media MIME history-তে লেখা হয়।

## সীমাবদ্ধতা

- Cloudflare challenge, CAPTCHA, login wall, DRM বা অন্য site access control bypass করা হয়নি এবং করা উচিতও নয়। অনুমোদিত/public media URL বা সাইটের official download/export ব্যবহার করুন।
- Android SDK না থাকায় এই sandbox-এ APK assemble করা যায়নি। Android Studio/CI environment-এ `./gradlew :app:assembleDebug` চালিয়ে final build করুন।
