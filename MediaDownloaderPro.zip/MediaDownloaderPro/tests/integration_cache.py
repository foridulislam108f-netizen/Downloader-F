#!/usr/bin/env python3
"""Local yt-dlp regression tests. Requires Python yt-dlp and ffmpeg; no account/site needed.
This tests CLI behavior used by Engine, not Android/WebView runtime integration.
"""
import hashlib
import http.server
import json
import pathlib
import subprocess
import tempfile
import threading


def run(*args):
    result = subprocess.run(args, text=True, capture_output=True, timeout=90)
    if result.returncode:
        raise AssertionError(f"Command failed: {args}\n{result.stdout}\n{result.stderr}")
    return result.stdout


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    with tempfile.TemporaryDirectory() as td:
        root = pathlib.Path(td)
        for name, color, resolution in [("low", "blue", "160x90"), ("high", "red", "320x180")]:
            run("ffmpeg", "-v", "error", "-f", "lavfi", "-i", f"color=c={color}:s={resolution}:r=10",
                "-f", "lavfi", "-i", "sine=frequency=440:sample_rate=44100", "-t", "1", "-c:v", "libx264",
                "-pix_fmt", "yuv420p", "-c:a", "aac", "-y", str(root / f"{name}.mp4"))
        run("ffmpeg", "-v", "error", "-i", str(root / "high.mp4"), "-vn", "-c:a", "copy", "-y", str(root / "audio.m4a"))
        run("ffmpeg", "-v", "error", "-i", str(root / "high.mp4"), "-c", "copy", "-hls_time", "1", "-hls_list_size", "0",
            "-hls_segment_filename", str(root / "seg%d.ts"), "-y", str(root / "media.m3u8"))
        run("ffmpeg", "-v", "error", "-i", str(root / "high.mp4"), "-an", "-c:v", "copy", "-hls_time", "1", "-hls_list_size", "0",
            "-hls_segment_filename", str(root / "video%d.ts"), "-y", str(root / "video.m3u8"))
        run("ffmpeg", "-v", "error", "-i", str(root / "audio.m4a"), "-c:a", "copy", "-hls_time", "1", "-hls_list_size", "0",
            "-hls_segment_filename", str(root / "audio%d.ts"), "-y", str(root / "audio.m3u8"))
        (root / "master.m3u8").write_text('#EXTM3U\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID="audio",NAME="main",DEFAULT=YES,AUTOSELECT=YES,URI="audio.m3u8"\n'
                                         '#EXT-X-STREAM-INF:BANDWIDTH=300000,RESOLUTION=320x180,CODECS="avc1.64000b,mp4a.40.2",AUDIO="audio"\nvideo.m3u8\n')
        hits = []

        class Handler(http.server.SimpleHTTPRequestHandler):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, directory=str(root), **kwargs)

            def do_GET(self):
                hits.append(self.path)
                if self.path == "/stream":
                    self.path = "/media.m3u8"
                elif self.path == "/file":
                    self.path = "/high.mp4"
                if self.path == "/high.mp4":
                    if self.headers.get("Referer") != base + "/page":
                        self.send_error(403)
                        return
                super().do_GET()

            def guess_type(self, path):
                if path.endswith(".m3u8"):
                    return "application/vnd.apple.mpegurl"
                return super().guess_type(path)

            def log_message(self, *args):
                pass

        server = http.server.ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        base = f"http://127.0.0.1:{server.server_port}"
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        headers = {"Referer": base + "/page", "User-Agent": "MediaDL-regression"}
        metadata = {
            "id": "fixture", "title": "fixture", "extractor": "generic", "extractor_key": "Generic",
            "webpage_url": base + "/page", "original_url": base + "/page", "http_headers": headers,
            "formats": [
                {"format_id": "low", "url": base + "/low.mp4", "ext": "mp4", "height": 90,
                 "vcodec": "h264", "acodec": "aac", "http_headers": headers},
                {"format_id": "high", "url": base + "/high.mp4", "ext": "mp4", "height": 180,
                 "vcodec": "h264", "acodec": "aac", "http_headers": headers},
                {"format_id": "audio", "url": base + "/audio.m4a", "ext": "m4a", "vcodec": "none",
                 "acodec": "aac", "http_headers": headers},
            ],
        }
        info = root / "fixture.info.json"
        info.write_text(json.dumps(metadata))
        cli = ["python3", "-m", "yt_dlp", "--ignore-config", "--no-warnings", "--no-mtime", "--retries", "3",
               "--fragment-retries", "5", "--extractor-retries", "1", "--concurrent-fragments", "4", "--socket-timeout", "15"]
        try:
            for selector, source in [("high", "high.mp4"), ("low", "low.mp4"), ("bv*[height<=90]+ba/b[height<=90]/b", "low.mp4")]:
                output = root / ("cached-" + source)
                run(*cli, "--load-info-json", str(info), "--no-check-formats", "--referer", base + "/page",
                    "-f", selector, "-o", str(output))
                assert digest(output) == digest(root / source), selector
                output.unlink()
                print(f"PASS cached selection: {selector}")
            run(*cli, "--load-info-json", str(info), "--no-check-formats", "-f", "ba/b", "-x", "--audio-format", "mp3",
                "-o", str(root / "converted.%(ext)s"))
            assert (root / "converted.mp3").stat().st_size > 100
            assert not any(path.startswith("/page") for path in hits), hits
            print("PASS cached MP3 conversion; no page re-extraction or duplicate URL")
            run(*cli, "--referer", base + "/page", "--no-playlist", "-o", str(root / "hls.%(ext)s"), base + "/stream")
            assert (root / "hls.mp4").stat().st_size > 100
            print("PASS HLS manifest without .m3u8 URL suffix")
            run(*cli, "--referer", base + "/page", "--no-playlist", "-o", str(root / "direct.%(ext)s"), base + "/file")
            assert digest(root / "direct.mp4") == digest(root / "high.mp4")
            print("PASS direct file without extension, protected by Referer")
            analyzed = json.loads(run(*cli, "--dump-single-json", "--skip-download", "--no-check-formats",
                                     "--referer", base + "/page", base + "/file"))
            assert analyzed.get("formats"), "Engine requires a mapped format list"
            for key in ("requested_downloads", "requested_formats", "requested_subtitles"):
                analyzed.pop(key, None)
            analyzed_info = root / "analyzed.info.json"
            analyzed_info.write_text(json.dumps(analyzed))
            before = len(hits)
            run(*cli, "--load-info-json", str(analyzed_info), "--no-check-formats", "--referer", base + "/page",
                "-f", "bv*+ba/b", "-o", str(root / "analyzed.mp4"))
            assert digest(root / "analyzed.mp4") == digest(root / "high.mp4")
            assert hits[before:] == ["/file"], hits[before:]
            print("PASS actual analysis JSON reused with a single media request")
            master = json.loads(run(*cli, "--dump-single-json", "--skip-download", "--no-check-formats", base + "/master.m3u8"))
            for key in ("requested_downloads", "requested_formats", "requested_subtitles"):
                master.pop(key, None)
            info.write_text(json.dumps(master))
            run(*cli, "--load-info-json", str(info), "--no-check-formats", "-f", "bv*+ba/b", "--merge-output-format", "mp4",
                "-o", str(root / "merged.%(ext)s"))
            streams = json.loads(run("ffprobe", "-v", "error", "-show_streams", "-of", "json", str(root / "merged.mp4")))["streams"]
            assert {s["codec_type"] for s in streams} >= {"video", "audio"}
            print("PASS cached HLS master retains separate audio and video")
            print("All 8 local CLI regression scenarios passed.")
        finally:
            server.shutdown()
            server.server_close()


if __name__ == "__main__":
    main()
