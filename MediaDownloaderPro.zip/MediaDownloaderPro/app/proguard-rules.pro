# minify বন্ধ আছে; ভবিষ্যতে চালু করলে এগুলো রাখতে হবে
-keep class com.yausername.** { *; }
-keep class com.fasterxml.jackson.** { *; }
-keepclassmembers class com.foridul.mediadl.MainActivity$Bridge { *; }
