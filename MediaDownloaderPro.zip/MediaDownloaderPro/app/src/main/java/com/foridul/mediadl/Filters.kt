package com.foridul.mediadl

import android.content.Context
import android.webkit.WebResourceResponse
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/** ফিল্টার লিস্ট: বিজ্ঞাপন/ট্র্যাকার ডোমেইন ব্লক। লিস্টগুলো ডাউনলোড হয়ে ফোনে ক্যাশ থাকে। */
object Filters {

    class Def(val id: String, val name: String, val desc: String, val url: String, val color: String)

    val DEFS = listOf(
        Def("sb", "StevenBlack Hosts", "Block ads, trackers and malware",
            "https://raw.githubusercontent.com/StevenBlack/hosts/master/hosts", "#3d4450"),
        Def("el", "EasyList", "Block ads and annoying content",
            "https://easylist.to/easylist/easylist.txt", "#e0566a"),
        Def("agm", "AdGuard Mobile Ads filter", "Block mobile advertisements",
            "https://filters.adtidy.org/android/filters/11.txt", "#3fa34d"),
        Def("agt", "AdGuard Tracking Protection", "Block tracking and analytics",
            "https://filters.adtidy.org/android/filters/3.txt", "#3fa34d"),
        Def("ags", "AdGuard Social Media filter", "Block social media widgets",
            "https://filters.adtidy.org/android/filters/4.txt", "#8a5cf6"),
        Def("agr", "AdGuard Russian filter", "Block ads and tracking (Russian)",
            "https://filters.adtidy.org/android/filters/1.txt", "#3b82f6"),
        Def("aga", "AdGuard Annoyances", "Block annoying elements",
            "https://filters.adtidy.org/android/filters/14.txt", "#e8a33d"),
        Def("fb", "Fanboy's Annoyance List", "Block annoying ads and popups",
            "https://easylist.to/easylist/fanboy-annoyance.txt", "#5b5fc7"),
        Def("sbg", "StevenBlack Gambling", "Block gambling content",
            "https://raw.githubusercontent.com/StevenBlack/hosts/master/alternates/gambling-only/hosts", "#2aa39a")
    )

    @Volatile private var domains: Set<String> = emptySet()
    @Volatile private var master = true
    /** ব্যবহারকারী "Block this Ad" দিয়ে নিজে যে ডোমেইন ব্লক করেছে */
    @Volatile private var custom: Set<String> = emptySet()
    @Volatile var busy = false
        private set
    private lateinit var prefs: android.content.SharedPreferences
    private lateinit var dir: File

    /** ডোমেইন বদলালে (বা আপডেট শেষ হলে) কল হয়; UI থ্রেডে নয় */
    var onChange: (() -> Unit)? = null

    fun init(ctx: Context) {
        val app = ctx.applicationContext
        prefs = app.getSharedPreferences("mdl_filters", Context.MODE_PRIVATE)
        master = prefs.getBoolean("master", true)
        custom = prefs.getStringSet("custom", emptySet())?.toSet() ?: emptySet()
        dir = File(app.filesDir, "filters").apply { mkdirs() }
        rebuild()
        // সপ্তাহে একবার স্বয়ংক্রিয় আপডেট (ব্যবহারকারী অন্তত একবার আপডেট করলে)
        val last = prefs.getLong("updated", 0L)
        if (last > 0L && System.currentTimeMillis() - last > 7L * 24 * 3600 * 1000) update { }
    }

    fun isOn(id: String): Boolean = prefs.getBoolean("on_$id", true)

    /** মাস্টার সুইচ: বন্ধ থাকলে কোনো লিস্টই কাজ করে না, তবে লিস্টের টগল অপরিবর্তিত থাকে */
    fun setMaster(on: Boolean) {
        master = on
        prefs.edit().putBoolean("master", on).apply()
        onChange?.invoke()
    }

    fun setOn(id: String, on: Boolean) {
        prefs.edit().putBoolean("on_$id", on).apply()
        rebuild()
    }

    /** ডোমেইন বা তার মূল ডোমেইন (যেমন ads.x.com -> x.com) ব্লক তালিকায় আছে কি না */
    fun isBlocked(host: String?): Boolean {
        if (host == null) return false
        if (custom.isNotEmpty() && inSet(custom, host)) return true
        if (!master) return false
        return inSet(domains, host)
    }

    private fun inSet(set: Set<String>, host: String): Boolean {
        if (set.isEmpty()) return false
        var h = host.lowercase()
        while (true) {
            if (set.contains(h)) return true
            val i = h.indexOf('.')
            if (i < 0) return false
            h = h.substring(i + 1)
        }
    }

    /** লং-প্রেস মেনুর "Block this Ad": ডোমেইনটি নিজস্ব তালিকায় রাখে। পেজের নিজের সাইট হলে রাখে না (সাইট ভেঙে যাবে) */
    fun blockHost(host: String?, pageHost: String?): Boolean {
        val h = host?.lowercase() ?: return false
        if (pageHost != null && sameSite(h, pageHost.lowercase())) return false
        custom = custom + h
        prefs.edit().putStringSet("custom", HashSet(custom)).apply()
        return true
    }

    private val MEDIA_EXT = listOf(
        ".mp4", ".m4s", ".m4a", ".ts", ".webm", ".mkv", ".m3u8", ".mpd", ".mp3", ".aac", ".ogg", ".opus", ".flac"
    )

    /** ইউটিউবের বিজ্ঞাপন-এন্ডপয়েন্ট: ভিডিও চলবে, কিন্তু এই রিকোয়েস্টগুলো আটকায় */
    private val YT_AD_PATHS = listOf("/pagead/", "/api/stats/ads", "/ptracking", "/get_midroll")

    /** প্লেয়ার/ভিডিও সার্ভার: এখানকার রিকোয়েস্ট ডোমেইন তালিকা দিয়ে আটকানো হয় না */
    private val PLAYER_HOSTS = listOf("youtube.com", "youtube-nocookie.com", "googlevideo.com", "ytimg.com", "ggpht.com", "vimeo.com")

    /**
     * কোন সাব-রিকোয়েস্ট বন্ধ হবে।
     * - ভিডিও/অডিও স্ট্রিম, Range রিকোয়েস্ট ও প্লেয়ার সার্ভার কখনো বন্ধ হয় না (ভিডিও চলতে থাকে)।
     * - ইউটিউবের বিজ্ঞাপন এন্ডপয়েন্ট সবসময় বন্ধ।
     * - বাকি সব (ট্র্যাকার, বিজ্ঞাপনের iframe, স্ক্রিপ্ট) তালিকা অনুযায়ী বন্ধ।
     */
    fun shouldBlock(req: android.webkit.WebResourceRequest, pageHost: String?): Boolean {
        if (req.isForMainFrame || (!master && custom.isEmpty())) return false
        val h = req.url.host?.lowercase() ?: return false
        val path = req.url.path?.lowercase() ?: ""
        if (h.endsWith("youtube.com") && YT_AD_PATHS.any { path.startsWith(it) }) return true
        val headers = req.requestHeaders ?: emptyMap()
        val accept = (headers["Accept"] ?: headers["accept"] ?: "").lowercase()
        if (accept.contains("video/") || accept.contains("audio/") ||
            accept.contains("mpegurl") || accept.contains("dash+xml")
        ) return false
        if (headers.keys.any { it.equals("Range", ignoreCase = true) }) return false
        if (MEDIA_EXT.any { path.endsWith(it) }) return false
        if (PLAYER_HOSTS.any { h == it || h.endsWith(".$it") }) return false
        if (pageHost != null && sameSite(h, pageHost.lowercase())) return false
        return isBlocked(h)
    }

    /** মোটামুটি একই সাইট: শেষ দুটি লেবেল মিললে (যেমন cdn.site.com ও m.site.com) */
    private fun sameSite(a: String, b: String): Boolean {
        val x = a.split('.').takeLast(2)
        val y = b.split('.').takeLast(2)
        return x.size == 2 && x == y
    }

    fun emptyResponse(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))

    /** চালু থাকা লিস্টগুলোর ক্যাশ থেকে ডোমেইন সেট বানায় */
    private fun rebuild() {
        Thread {
            try {
                domains = emptySet()   // পুরনো সেট আগে ছেড়ে দিই, যাতে মেমোরি একসাথে দুটো না থাকে
                val all = HashSet<String>()
                for (d in DEFS) {
                    if (!isOn(d.id)) continue
                    val f = File(dir, d.id + ".txt")
                    if (f.exists()) f.forEachLine { if (it.isNotEmpty()) all.add(it) }
                }
                domains = all
                onChange?.invoke()
            } catch (e: Throwable) {
                domains = emptySet()
            }
        }.start()
    }

    /** সব লিস্ট ইন্টারনেট থেকে নতুন করে নামায় */
    fun update(onDone: () -> Unit) {
        if (busy) return
        busy = true
        Thread {
            var ok = 0
            for (d in DEFS) {
                try {
                    val c = URL(d.url).openConnection() as HttpURLConnection
                    c.connectTimeout = 15000
                    c.readTimeout = 60000
                    c.setRequestProperty("User-Agent", "MediaDL")
                    val tmp = File(dir, d.id + ".tmp")
                    c.inputStream.bufferedReader().use { r ->
                        tmp.bufferedWriter().use { w ->
                            r.forEachLine { line ->
                                parseLine(line)?.let { w.write(it); w.newLine() }
                            }
                        }
                    }
                    val dst = File(dir, d.id + ".txt")
                    dst.delete()
                    tmp.renameTo(dst)
                    ok++
                } catch (e: Throwable) {
                    // এই লিস্ট নামেনি বা মেমোরি কম; আগের ক্যাশ থাকলে সেটাই চলবে
                }
            }
            if (ok > 0) prefs.edit().putLong("updated", System.currentTimeMillis()).apply()
            busy = false
            rebuild()
            try { onDone() } catch (e: Throwable) { }
        }.start()
    }

    /** hosts ("0.0.0.0 domain") এবং AdBlock ("||domain^") দুই ফরম্যাটের লাইন থেকে ডোমেইন বের করে */
    private fun parseLine(raw: String): String? {
        val line = raw.trim()
        if (line.isEmpty() || line[0] == '!' || line.contains("##") || line.contains("#@#")) return null
        if (line.startsWith("0.0.0.0 ") || line.startsWith("127.0.0.1 ")) {
            val d = line.split(Regex("\\s+")).getOrNull(1)?.lowercase() ?: return null
            return if (d == "localhost" || d == "0.0.0.0" || !d.contains('.')) null else d
        }
        if (line.startsWith("||")) {
            var d = line.substring(2)
            val end = d.indexOfFirst { it == '^' || it == '/' || it == '$' || it == '*' || it == ':' }
            if (end >= 0) d = d.substring(0, end)
            d = d.lowercase()
            return if (d.contains('.') && d.all { it.isLetterOrDigit() || it == '.' || it == '-' }) d else null
        }
        return null
    }

    fun json(): String {
        val lists = JSONArray()
        for (d in DEFS) {
            lists.put(
                JSONObject()
                    .put("id", d.id).put("name", d.name).put("desc", d.desc)
                    .put("color", d.color).put("on", isOn(d.id))
            )
        }
        return JSONObject()
            .put("busy", busy)
            .put("master", master)
            .put("active", if (master) DEFS.count { isOn(it.id) } else 0)
            .put("domains", domains.size)
            .put("updated", prefs.getLong("updated", 0L))
            .put("lists", lists)
            .toString()
    }
}
