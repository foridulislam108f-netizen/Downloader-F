package com.foridul.mediadl

import android.content.Context

/** অ্যাপের নেটিভ অংশের বাংলা/ইংরেজি লেখা (HTML পেজগুলোর লেখা আলাদা, সেখানেই আছে) */
object L {

    @Volatile var lang = "en"
    private lateinit var prefs: android.content.SharedPreferences

    fun init(ctx: Context) {
        prefs = ctx.applicationContext.getSharedPreferences("mdl_ui", Context.MODE_PRIVATE)
        val l = prefs.getString("lang", "en")
        lang = if (l == "bn") "bn" else "en"
    }

    fun saveLang(l: String) {
        lang = if (l == "bn") "bn" else "en"
        prefs.edit().putString("lang", lang).apply()
    }

    /** "" = সিস্টেমের থিম */
    fun theme(): String = prefs.getString("theme", "") ?: ""
    fun setTheme(t: String) { prefs.edit().putString("theme", t).apply() }

    /** হোম পেজের থিম স্কিন: navy / black / white / glass (ডিফল্ট navy) */
    fun skin(): String = prefs.getString("skin", "navy") ?: "navy"
    fun setSkin(t: String) { prefs.edit().putString("skin", t).apply() }

    /** একসাথে সর্বোচ্চ কতটি ডাউনলোড চলবে (১–১০) */
    fun maxJobs(): Int = prefs.getInt("maxJobs", 3).coerceIn(1, 10)
    fun setMaxJobs(n: Int) { prefs.edit().putInt("maxJobs", n.coerceIn(1, 10)).apply() }

    /** পপ-আপ ও নতুন-উইন্ডোর বিজ্ঞাপন ব্লক (ডিফল্ট: চালু) */
    fun popupBlock(): Boolean = prefs.getBoolean("popBlock", true)
    fun setPopupBlock(on: Boolean) { prefs.edit().putBoolean("popBlock", on).apply() }

    /** ডেস্কটপ মোড (ডিফল্ট: বন্ধ) ও ওয়েব পেজে ডার্ক মোড (ডিফল্ট: বন্ধ) */
    /** নাইট মোড: পর্দায় হালকা উষ্ণ অন্ধকার আবরণ (চোখের আরামের জন্য) */
    fun nightMode(): Boolean = prefs.getBoolean("nightMode", false)
    fun setNightMode(on: Boolean) { prefs.edit().putBoolean("nightMode", on).apply() }

    fun desktopMode(): Boolean = prefs.getBoolean("desktopMode", false)
    fun setDesktopMode(on: Boolean) { prefs.edit().putBoolean("desktopMode", on).apply() }
    fun pageDark(): Boolean = prefs.getBoolean("pageDark", false)
    fun setPageDark(on: Boolean) { prefs.edit().putBoolean("pageDark", on).apply() }

    /** সাবটাইটেল ডাউনলোড: off | bn | en | both */
    fun subLang(): String = "off"   // সেটিংসের সাবটাইটেল অপশন সরানো হয়েছে; ভিডিওর সাথে সাবটাইটেল আর নামে না
    fun setSubLang(v: String) {
        prefs.edit().putString("subLang", if (v == "bn" || v == "en" || v == "both") v else "off").apply()
    }

    /** হোম পেজের সার্চ ইঞ্জিনের তালিকা ও বাছাই (JSON; হোম পেজ নিজেই বানায় ও পড়ে) */
    // নিউজপেপার তালিকা (JSON); খালি মানে এখনো কখনো বদলানো হয়নি, তখন ডিফল্ট তালিকা দেখানো হয়
    fun papers(): String = prefs.getString("papers", "") ?: ""
    fun setPapers(j: String) { if (j.length <= 40000) prefs.edit().putString("papers", j).apply() }

    fun searchCfg(): String = prefs.getString("searchCfg", "") ?: ""
    fun setSearchCfg(j: String) { if (j.length <= 20000) prefs.edit().putString("searchCfg", j).apply() }

    private val S: Map<String, Pair<String, String>> = mapOf(
        // নিচের বার
        "back" to Pair("পেছনে", "Back"),
        "fwd" to Pair("সামনে", "Forward"),
        "home" to Pair("হোম", "Home"),
        "dl" to Pair("ডাউনলোড", "Download"),
        "menu" to Pair("মেনু", "Menu"),
        "downloading" to Pair("ডাউনলোড", "Downloads"),
        "history" to Pair("ইতিহাস", "History"),
        "qrScan" to Pair("কিউআর স্ক্যানার", "QR scanner"),
        "qrPrompt" to Pair("কিউআর কোড ক্যামেরার সামনে ধরুন", "Point the camera at a QR code"),
        "qrResult" to Pair("স্ক্যানের ফলাফল", "Scan result"),
        "qrCopy" to Pair("কপি", "Copy"),
        "qrSearch" to Pair("সার্চ", "Search"),
        "qrClose" to Pair("বন্ধ", "Close"),
        "nightMode" to Pair("নাইট মোড", "Night mode"),
        "nightOn" to Pair("নাইট মোড চালু", "Night mode on"),
        "nightOff" to Pair("নাইট মোড বন্ধ", "Night mode off"),
        "newTab" to Pair("নতুন ট্যাব", "New tab"),
        "settings" to Pair("সেটিংস", "Settings"),
        "reload" to Pair("রিলোড", "Reload"),
        "popBlock" to Pair("পপ-আপ ব্লক", "Pop-up block"),
        "popBlockShort" to Pair("ব্লক", "Block"),
        "popOn" to Pair("পপ-আপ ব্লক চালু", "Pop-up block on"),
        "popOff" to Pair("পপ-আপ ব্লক বন্ধ", "Pop-up block off"),
        "popBlocked" to Pair("বিজ্ঞাপনের পপ-আপ ব্লক করা হয়েছে", "Ad pop-up blocked"),
        "popOffSub" to Pair("বন্ধ আছে", "Off"),
        // লিংকে লং-প্রেস মেনু
        "shareLink" to Pair("লিংক শেয়ার", "Share Link"),
        "openNew" to Pair("নতুন ট্যাবে খুলুন", "Open in New"),
        "openBg" to Pair("ব্যাকগ্রাউন্ডে খুলুন", "Open in Background"),
        "openedBg" to Pair("ব্যাকগ্রাউন্ডে খোলা হয়েছে", "Opened in background"),
        "copyLink" to Pair("লিংক কপি", "Copy Link"),
        "savePage" to Pair("পেজ সেভ", "Save Page"),
        "copyText" to Pair("লেখা কপি", "Copy Text"),
        "saveLink" to Pair("লিংক সেভ", "Save Link"),
        "blockAd" to Pair("এই বিজ্ঞাপন ব্লক করুন", "Block this Ad"),
        "copied" to Pair("কপি হয়েছে", "Copied"),
        "noText" to Pair("কপি করার মতো লেখা নেই", "No text to copy"),
        "adBlocked" to Pair("বিজ্ঞাপন ব্লক হয়েছে", "Ad blocked"),
        "adHidden" to Pair("লিংকটি লুকানো হয়েছে", "Link hidden"),
        "pageSaving" to Pair("পেজ সেভ হচ্ছে…", "Saving page…"),
        // বার্তা
        "openSite" to Pair("আগে একটা ওয়েবসাইট খুলুন বা লিংক দিন", "Open a website or enter a link first"),
        "added" to Pair("ডাউনলোড তালিকায় যোগ হয়েছে", "Added to downloads"),
        "started" to Pair("ডাউনলোড শুরু হয়েছে: ", "Download started: "),
        "failed" to Pair("ডাউনলোড ব্যর্থ: ", "Download failed: "),
        "missing" to Pair("ফাইলটি পাওয়া যাচ্ছে না", "File not found"),
        "noApp" to Pair("ফাইল খোলার মতো অ্যাপ পাওয়া যায়নি", "No app found to open this file"),
        "clipEmpty" to Pair("ক্লিপবোর্ডে কোনো লিংক নেই", "No link in the clipboard"),
        "engUpdating" to Pair("ইঞ্জিন আপডেট হচ্ছে…", "Updating engine…"),
        "engUpdFail" to Pair("আপডেট ব্যর্থ: ", "Update failed: "),
        "engUpdated" to Pair("ইঞ্জিন আপডেট হয়েছে (yt-dlp ", "Engine updated (yt-dlp "),
        "engLatest" to Pair("ইঞ্জিন আগে থেকেই সর্বশেষ (yt-dlp ", "Engine is already up to date (yt-dlp "),
        "engBusy" to Pair("ইঞ্জিন চালু হতে সময় নিচ্ছে, কিছুক্ষণ পর আবার চেষ্টা করুন", "The engine is still starting; try again in a moment"),
        "engFail" to Pair("ইঞ্জিন চালু করা যায়নি: ", "Engine failed to start: "),
        "dlDone" to Pair("✓ ডাউনলোড সম্পূর্ণ: ", "✓ Download complete: "),
        "dlFailed" to Pair("✗ ব্যর্থ: ", "✗ Failed: "),
        "noFile" to Pair("কোনো ফাইল তৈরি হয়নি", "No file was created"),
        "noFmt" to Pair("কোনো ফরম্যাট পাওয়া যায়নি", "No formats were found"),
        "anFail" to Pair("বিশ্লেষণ ব্যর্থ", "Analysis failed"),
        "mkFail" to Pair("Downloads-এ ফাইল তৈরি করা যায়নি", "Could not create the file in Downloads"),
        "folder" to Pair("ফোল্ডার: Downloads/MediaDownloader", "Folder: Downloads/MediaDownloader"),
        // archive.org / অতিরিক্ত অপশন
        "exArchive" to Pair("archive.org ফাইল-তালিকা থেকে বাছুন", "Pick from the archive.org file list"),
        "exDirect" to Pair("পেজে ধরা-পড়া সরাসরি ফাইল নামান", "Download the direct file detected on the page"),
        "exSelf" to Pair("এই লিংক সরাসরি ফাইল হিসেবে নামান", "Download this link as a direct file"),
        "listFetching" to Pair("ফাইল-তালিকা আনা হচ্ছে…", "Fetching file list…"),
        "listNone" to Pair("এই আইটেমে ডাউনলোডযোগ্য ভিডিও/অডিও ফাইল পাওয়া যায়নি (লগইন বা ধার-নেওয়া আইটেম হতে পারে)", "No downloadable video/audio files in this item (it may need login or be a lending item)"),
        "listFail" to Pair("তালিকা আনা যায়নি: ", "Could not fetch the list: "),
        "pickFile" to Pair("কোন ফাইল ডাউনলোড করবেন?", "Which file do you want to download?"),
        "private" to Pair("প্রাইভেট", "Private"),
        "privTab" to Pair("প্রাইভেট", "Private"),
        "newspaper" to Pair("নিউজপেপার", "Newspaper"),
        "addPaper" to Pair("পত্রিকা যোগ করুন", "Add newspaper"),
        "editPaper" to Pair("পত্রিকা বদলান", "Edit newspaper"),
        "paperName" to Pair("নাম", "Name"),
        "paperLink" to Pair("লিংক", "Link"),
        "paperBadName" to Pair("নাম লিখুন", "Enter a name"),
        "paperBadLink" to Pair("সঠিক লিংক দিন (যেমন prothomalo.com)", "Enter a valid link (e.g. prothomalo.com)"),
        "save" to Pair("সেভ", "Save"),
        "edit" to Pair("বদলান", "Edit"),
        "delete" to Pair("মুছুন", "Delete"),
        "paperEmpty" to Pair("কোনো পত্রিকা নেই; উপরের বাটন দিয়ে যোগ করুন", "No newspapers yet; add one with the button above"),
        "cancel" to Pair("বাতিল", "Cancel")
    )

    fun t(k: String): String {
        val p = S[k] ?: return k
        return if (lang == "en") p.second else p.first
    }
}
