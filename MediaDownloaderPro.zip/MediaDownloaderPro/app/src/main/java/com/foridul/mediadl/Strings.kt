package com.foridul.mediadl

import android.content.Context

/** অ্যাপের নেটিভ অংশের বাংলা/ইংরেজি লেখা (HTML পেজগুলোর লেখা আলাদা, সেখানেই আছে) */
object L {

    @Volatile var lang = "bn"
    private lateinit var prefs: android.content.SharedPreferences

    fun init(ctx: Context) {
        prefs = ctx.applicationContext.getSharedPreferences("mdl_ui", Context.MODE_PRIVATE)
        val l = prefs.getString("lang", "bn")
        lang = if (l == "en") "en" else "bn"
    }

    fun saveLang(l: String) {
        lang = if (l == "en") "en" else "bn"
        prefs.edit().putString("lang", lang).apply()
    }

    /** "" = সিস্টেমের থিম */
    fun theme(): String = prefs.getString("theme", "") ?: ""
    fun setTheme(t: String) { prefs.edit().putString("theme", t).apply() }

    /** একসাথে সর্বোচ্চ কতটি ডাউনলোড চলবে (১–১০) */
    fun maxJobs(): Int = prefs.getInt("maxJobs", 2).coerceIn(1, 10)
    fun setMaxJobs(n: Int) { prefs.edit().putInt("maxJobs", n.coerceIn(1, 10)).apply() }

    /** পপ-আপ ও নতুন-উইন্ডোর বিজ্ঞাপন ব্লক (ডিফল্ট: চালু) */
    fun popupBlock(): Boolean = prefs.getBoolean("popBlock", true)
    fun setPopupBlock(on: Boolean) { prefs.edit().putBoolean("popBlock", on).apply() }

    private val S: Map<String, Pair<String, String>> = mapOf(
        // নিচের বার
        "back" to Pair("পেছনে", "Back"),
        "fwd" to Pair("সামনে", "Forward"),
        "home" to Pair("হোম", "Home"),
        "dl" to Pair("ডাউনলোড", "Download"),
        "menu" to Pair("মেনু", "Menu"),
        "downloading" to Pair("ডাউনলোড", "Downloads"),
        "history" to Pair("ইতিহাস", "History"),
        "newTab" to Pair("নতুন ট্যাব", "New tab"),
        "settings" to Pair("সেটিংস", "Settings"),
        "reload" to Pair("রিলোড", "Reload"),
        "popBlock" to Pair("পপ-আপ ব্লক", "Pop-up block"),
        "popOn" to Pair("পপ-আপ ব্লক চালু", "Pop-up block on"),
        "popOff" to Pair("পপ-আপ ব্লক বন্ধ", "Pop-up block off"),
        "popBlocked" to Pair("বিজ্ঞাপনের পপ-আপ ব্লক করা হয়েছে", "Ad pop-up blocked"),
        "popOffSub" to Pair("বন্ধ আছে", "Off"),
        // বার্তা
        "openSite" to Pair("আগে একটা ওয়েবসাইট খুলুন বা লিংক দিন", "Open a website or enter a link first"),
        "added" to Pair("ডাউনলোড তালিকায় যোগ হয়েছে", "Added to downloads"),
        "started" to Pair("ডাউনলোড শুরু হয়েছে: ", "Download started: "),
        "failed" to Pair("ডাউনলোড ব্যর্থ: ", "Download failed: "),
        "missing" to Pair("ফাইলটি পাওয়া যাচ্ছে না", "File not found"),
        "noApp" to Pair("ফাইল খোলার মতো অ্যাপ পাওয়া যায়নি", "No app found to open this file"),
        "clipEmpty" to Pair("ক্লিপবোর্ডে কোনো লিংক নেই", "No link in the clipboard"),
        "engUpdating" to Pair("ইঞ্জিন আপডেট হচ্ছে…", "Updating engine…"),
        "engUpdFail" to Pair("আপডেট ব্যর্থ: ", "Update failed: "),
        "engUpdated" to Pair("ইঞ্জিন আপডেট হয়েছে (yt-dlp ", "Engine updated (yt-dlp "),
        "engLatest" to Pair("ইঞ্জিন আগে থেকেই সর্বশেষ (yt-dlp ", "Engine is already up to date (yt-dlp "),
        "engBusy" to Pair("ইঞ্জিন চালু হতে সময় নিচ্ছে, কিছুক্ষণ পর আবার চেষ্টা করুন", "The engine is still starting; try again in a moment"),
        "engFail" to Pair("ইঞ্জিন চালু করা যায়নি: ", "Engine failed to start: "),
        "dlDone" to Pair("✓ ডাউনলোড সম্পূর্ণ: ", "✓ Download complete: "),
        "dlFailed" to Pair("✗ ব্যর্থ: ", "✗ Failed: "),
        "noFile" to Pair("কোনো ফাইল তৈরি হয়নি", "No file was created"),
        "noFmt" to Pair("কোনো ফরম্যাট পাওয়া যায়নি", "No formats were found"),
        "anFail" to Pair("বিশ্লেষণ ব্যর্থ", "Analysis failed"),
        "mkFail" to Pair("Downloads-এ ফাইল তৈরি করা যায়নি", "Could not create the file in Downloads"),
        "folder" to Pair("ফোল্ডার: Downloads/MediaDownloader", "Folder: Downloads/MediaDownloader"),
        // archive.org / অতিরিক্ত অপশন
        "exArchive" to Pair("archive.org ফাইল-তালিকা থেকে বাছুন", "Pick from the archive.org file list"),
        "exDirect" to Pair("পেজে ধরা-পড়া সরাসরি ফাইল নামান", "Download the direct file detected on the page"),
        "exSelf" to Pair("এই লিংক সরাসরি ফাইল হিসেবে নামান", "Download this link as a direct file"),
        "listFetching" to Pair("ফাইল-তালিকা আনা হচ্ছে…", "Fetching file list…"),
        "listNone" to Pair("এই আইটেমে ডাউনলোডযোগ্য ভিডিও/অডিও ফাইল পাওয়া যায়নি (লগইন বা ধার-নেওয়া আইটেম হতে পারে)", "No downloadable video/audio files in this item (it may need login or be a lending item)"),
        "listFail" to Pair("তালিকা আনা যায়নি: ", "Could not fetch the list: "),
        "pickFile" to Pair("কোন ফাইল ডাউনলোড করবেন?", "Which file do you want to download?"),
        "cancel" to Pair("বাতিল", "Cancel")
    )

    fun t(k: String): String {
        val p = S[k] ?: return k
        return if (lang == "en") p.second else p.first
    }
}
