package com.foridul.mediadl

import android.content.ContentUris
import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * ডাউনলোড-ইতিহাস ("My Files")। ফাইল ফোনের Downloads/MediaDownloader ফোল্ডারে থাকে;
 * এখানে তার নাম, লিংক ও ডাউনলোডের ধরন জমা থাকে, যাতে ফাইল মুছে গেলে আবার নামানো যায়।
 */
object History {

    const val FOLDER = "Download/MediaDownloader/"

    private lateinit var prefs: SharedPreferences

    fun init(ctx: Context) {
        prefs = ctx.applicationContext.getSharedPreferences("mdl_hist", Context.MODE_PRIVATE)
    }

    @Synchronized
    private fun load(): MutableList<JSONObject> {
        val out = ArrayList<JSONObject>()
        try {
            val a = JSONArray(prefs.getString("items", "[]"))
            for (i in 0 until a.length()) out.add(a.getJSONObject(i))
        } catch (e: Exception) {
        }
        return out
    }

    @Synchronized
    private fun save(list: List<JSONObject>) {
        val a = JSONArray()
        for (o in list.take(200)) a.put(o)
        prefs.edit().putString("items", a.toString()).apply()
    }

    /** kind: "yt" (yt-dlp) অথবা "direct" (সরাসরি ফাইল-লিংক) */
    @Synchronized
    fun add(path: String, url: String, kind: String, title: String, args: List<Engine.Arg>?, size: Long) {
        val list = load()
        list.removeAll { it.optString("path") == path }
        val o = JSONObject()
        o.put("id", "h" + System.nanoTime())
        o.put("name", path.substringAfterLast('/'))
        o.put("path", path)
        o.put("url", url)
        o.put("kind", kind)
        o.put("title", title)
        o.put("size", size)
        o.put("time", System.currentTimeMillis())
        if (args != null) {
            val a = JSONArray()
            for (x in args) a.put(JSONObject().put("k", x.key).put("v", x.value ?: JSONObject.NULL))
            o.put("args", a)
        }
        list.add(0, o)
        save(list)
    }

    fun all(): List<JSONObject> = load()

    fun find(id: String): JSONObject? = load().firstOrNull { it.optString("id") == id }

    @Synchronized
    fun remove(id: String) {
        val list = load()
        list.removeAll { it.optString("id") == id }
        save(list)
    }

    fun argsOf(o: JSONObject): List<Engine.Arg> {
        val out = ArrayList<Engine.Arg>()
        val a = o.optJSONArray("args") ?: return out
        for (i in 0 until a.length()) {
            val x = a.getJSONObject(i)
            out.add(Engine.Arg(x.getString("k"), if (x.isNull("v")) null else x.getString("v")))
        }
        return out
    }

    /** ফাইলটা এখনও ফোনে আছে কিনা; থাকলে তার Uri */
    fun locate(ctx: Context, path: String): Uri? {
        val name = path.substringAfterLast('/')
        return try {
            if (Build.VERSION.SDK_INT >= 29) {
                ctx.contentResolver.query(
                    MediaStore.Downloads.EXTERNAL_CONTENT_URI,
                    arrayOf(MediaStore.MediaColumns._ID),
                    MediaStore.MediaColumns.DISPLAY_NAME + "=? AND " + MediaStore.MediaColumns.RELATIVE_PATH + "=?",
                    arrayOf(name, FOLDER),
                    null
                )?.use { c ->
                    if (c.moveToFirst()) ContentUris.withAppendedId(MediaStore.Downloads.EXTERNAL_CONTENT_URI, c.getLong(0)) else null
                }
            } else {
                val f = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "MediaDownloader/" + name)
                if (f.exists()) Uri.fromFile(f) else null
            }
        } catch (e: Exception) {
            null
        }
    }

    // ─── ব্রাউজ / ভিজিট হিস্টোরি (ওয়েবসাইট + দেখা ভিডিও) ───

    @Synchronized
    private fun loadVisits(): MutableList<JSONObject> {
        val out = ArrayList<JSONObject>()
        try {
            val a = JSONArray(prefs.getString("visits", "[]"))
            for (i in 0 until a.length()) out.add(a.getJSONObject(i))
        } catch (_: Exception) {
        }
        return out
    }

    @Synchronized
    private fun saveVisits(list: List<JSONObject>) {
        val a = JSONArray()
        for (o in list.take(300)) a.put(o)
        prefs.edit().putString("visits", a.toString()).apply()
    }

    /**
     * ওয়েবসাইট বা ভিডিও লিংক হিস্টোরিতে যোগ করে।
     * kind: "site" (পেজ) বা "video" (মিডিয়া/স্নিফ করা লিংক)
     */
    @Synchronized
    fun addVisit(url: String, title: String, kind: String) {
        if (url.isBlank() || !url.startsWith("http")) return
        // হোম পেজ বা অ্যাসেট ইগনোর
        if (url.contains("android_asset") || url.endsWith("/home") || url.contains("index.html")) return
        val list = loadVisits()
        // একই URL থাকলে সরিয়ে উপরে নিয়ে আসা
        list.removeAll { it.optString("url") == url }
        val o = JSONObject()
        o.put("id", "v" + System.nanoTime())
        o.put("url", url)
        o.put("title", title.ifBlank { url })
        o.put("kind", kind) // site | video
        o.put("time", System.currentTimeMillis())
        list.add(0, o)
        saveVisits(list)
    }

    fun allVisits(): List<JSONObject> = loadVisits()

    @Synchronized
    fun removeVisit(id: String) {
        val list = loadVisits()
        list.removeAll { it.optString("id") == id }
        saveVisits(list)
    }

    @Synchronized
    fun clearVisits() {
        prefs.edit().putString("visits", "[]").apply()
    }
}
