package com.foridul.mediadl

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

/** একটি মাল্টি-কানেকশন ডাউনলোডের অবস্থা (প্যানেলে দেখানোর জন্য) */
class ParJob(val id: Long, val name: String, val url: String) {
    companion object { const val RUN = 0; const val DONE = 1; const val FAIL = 2 }
    @Volatile var status = RUN
    val loaded = AtomicLong(0)
    @Volatile var total = 0L
    @Volatile var error = ""
    @Volatile var savedName = name
    val canceled = AtomicBoolean(false)
    fun cancel() { canceled.set(true) }
}

/**
 * যেকোনো সাধারণ ফাইল (apk, zip, pdf…) ৪টি HTTP Range কানেকশনে ভাগ করে নামায়।
 * সার্ভার Range না দিলে বা ফাইল ছোট হলে probe() null দেয়; তখন ডাকার কোড সিস্টেম DownloadManager-এ ফিরে যায়।
 */
object ParallelDownloader {
    const val CONNECTIONS = 4
    private const val MIN_SIZE = 2L * 1024 * 1024
    private const val MIN_CHUNK = 1L * 1024 * 1024
    private const val MAX_CHUNK = 16L * 1024 * 1024
    private val idGen = AtomicLong(-1)

    class Probe(val finalUrl: String, val total: Long)

    fun newId(): Long = idGen.getAndDecrement()

    private class Auth(val origHost: String?, val ua: String?, val referer: String?, val cookies: String?)

    private fun open(u: String, a: Auth, range: String): HttpURLConnection {
        val c = URL(u).openConnection() as HttpURLConnection
        c.instanceFollowRedirects = false
        c.connectTimeout = 15000
        c.readTimeout = 20000
        if (!a.ua.isNullOrEmpty()) c.setRequestProperty("User-Agent", a.ua)
        if (!a.referer.isNullOrEmpty()) c.setRequestProperty("Referer", a.referer)
        // কুকি শুধু মূল হোস্টে যাবে; রিডাইরেক্টের পর অন্য হোস্টে নয়
        if (!a.cookies.isNullOrEmpty() && URL(u).host.equals(a.origHost, true)) c.setRequestProperty("Cookie", a.cookies)
        c.setRequestProperty("Accept-Encoding", "identity")
        c.setRequestProperty("Range", range)
        return c
    }

    /** রিডাইরেক্ট ধরে শেষ URL ও মোট সাইজ বের করে; Range না চললে বা ২ MB-এর কম হলে null */
    fun probe(url: String, ua: String?, referer: String?, cookies: String?): Probe? {
        return try {
            val a = Auth(URL(url).host, ua, referer, cookies)
            var cur = url
            for (i in 0 until 8) {
                val c = open(cur, a, "bytes=0-0")
                try {
                    val code = c.responseCode
                    if (code in 300..399) {
                        val loc = c.getHeaderField("Location") ?: return null
                        cur = URL(URL(cur), loc).toString()
                        continue
                    }
                    if (code != 206) return null
                    val cr = c.getHeaderField("Content-Range") ?: return null
                    val total = cr.substringAfterLast('/').trim().toLongOrNull() ?: return null
                    return if (total >= MIN_SIZE) Probe(cur, total) else null
                } finally {
                    try { c.disconnect() } catch (e: Exception) {}
                }
            }
            null
        } catch (e: Exception) { null }
    }

    private class Dest(val uri: Uri?, val file: File?, val channel: FileChannel, val closeAll: () -> Unit, val shownName: String)

    private fun safeName(n: String): String {
        val s = n.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim()
        return if (s.isEmpty()) "download" else s
    }

    private fun createDest(ctx: Context, name: String): Dest {
        val ext = name.substringAfterLast('.', "").lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues()
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime)
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MediaDownloader")
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1)
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                ?: throw IOException("create failed")
            var shown = name
            ctx.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) shown = it.getString(0) ?: name
            }
            val pfd = ctx.contentResolver.openFileDescriptor(uri, "rw") ?: throw IOException("open failed")
            val fos = FileOutputStream(pfd.fileDescriptor)
            return Dest(uri, null, fos.channel, { try { fos.close() } catch (e: Exception) {}; try { pfd.close() } catch (e: Exception) {} }, shown)
        }
        val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "MediaDownloader")
        dir.mkdirs()
        var f = File(dir, name)
        var k = 1
        val base = name.substringBeforeLast('.', name)
        val dot = if (name.contains('.')) "." + name.substringAfterLast('.') else ""
        while (f.exists()) { f = File(dir, "$base ($k)$dot"); k++ }
        val raf = RandomAccessFile(f, "rw")
        return Dest(null, f, raf.channel, { try { raf.close() } catch (e: Exception) {} }, f.name)
    }

    /** ব্যাকগ্রাউন্ড থ্রেডে ডাউনলোড শুরু করে; অবস্থা job-এ আপডেট হয় */
    fun start(ctx: Context, job: ParJob, p: Probe, ua: String?, referer: String?, cookies: String?) {
        val app = ctx.applicationContext
        job.total = p.total
        Thread {
            var wake: PowerManager.WakeLock? = null
            var dest: Dest? = null
            try {
                wake = (app.getSystemService(Context.POWER_SERVICE) as PowerManager)
                    .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mediadl:par").apply { setReferenceCounted(false); acquire(2L * 3600 * 1000) }
            } catch (e: Exception) {}
            try {
                val d = createDest(app, safeName(job.name))
                dest = d
                job.savedName = d.shownName
                val a = Auth(try { URL(job.url).host } catch (e: Exception) { null }, ua, referer, cookies)
                val total = p.total
                val chunk = (total / 12).coerceIn(MIN_CHUNK, MAX_CHUNK)
                val n = ((total + chunk - 1) / chunk).toInt()
                val next = AtomicInteger(0)
                val failed = AtomicBoolean(false)
                val workers = (0 until minOf(CONNECTIONS, n)).map {
                    Thread {
                        val buf = ByteArray(64 * 1024)
                        while (!job.canceled.get() && !failed.get()) {
                            val i = next.getAndIncrement()
                            if (i >= n) break
                            val s = i * chunk
                            val e = minOf(total - 1, s + chunk - 1)
                            if (!fetch(p.finalUrl, a, s, e, d.channel, buf, job)) { failed.set(true); break }
                        }
                    }.also { it.start() }
                }
                workers.forEach { it.join() }
                d.closeAll()
                if (job.canceled.get() || failed.get() || job.loaded.get() < total) {
                    if (job.error.isEmpty()) job.error = if (job.canceled.get()) "canceled" else "incomplete"
                    discard(app, d)
                    job.status = ParJob.FAIL
                } else {
                    if (d.uri != null) {
                        val cv = ContentValues(); cv.put(MediaStore.MediaColumns.IS_PENDING, 0)
                        app.contentResolver.update(d.uri, cv, null, null)
                    } else if (d.file != null) {
                        MediaScannerConnection.scanFile(app, arrayOf(d.file.absolutePath), null, null)
                    }
                    job.status = ParJob.DONE
                }
            } catch (e: Exception) {
                job.error = e.message ?: "error"
                dest?.let { try { it.closeAll() } catch (x: Exception) {}; discard(app, it) }
                job.status = ParJob.FAIL
            } finally {
                try { wake?.let { if (it.isHeld) it.release() } } catch (e: Exception) {}
            }
        }.start()
    }

    private fun discard(ctx: Context, d: Dest) {
        try {
            if (d.uri != null) ctx.contentResolver.delete(d.uri, null, null)
            else d.file?.delete()
        } catch (e: Exception) {}
    }

    /** [s, e] টুকরো নামায়; কেটে গেলে যেখানে থেমেছিল সেখান থেকে আবার চেষ্টা (সর্বোচ্চ ৪ বার) */
    private fun fetch(url: String, a: Auth, s: Long, e: Long, ch: FileChannel, buf: ByteArray, job: ParJob): Boolean {
        var pos = s
        var attempt = 0
        while (pos <= e) {
            if (job.canceled.get()) return false
            var c: HttpURLConnection? = null
            try {
                c = open(url, a, "bytes=$pos-$e")
                val code = c.responseCode
                if (code != 206) throw IOException("HTTP $code")
                c.inputStream.use { ins ->
                    while (pos <= e) {
                        val r = ins.read(buf, 0, minOf(buf.size.toLong(), e - pos + 1).toInt())
                        if (r < 0) break
                        var off = 0
                        while (off < r) off += ch.write(ByteBuffer.wrap(buf, off, r - off), pos + off)
                        pos += r
                        job.loaded.addAndGet(r.toLong())
                        if (job.canceled.get()) return false
                    }
                }
                if (pos <= e) throw IOException("short read")
            } catch (ex: Exception) {
                if (job.canceled.get()) return false
                attempt++
                if (attempt > 4) { job.error = ex.message ?: "network"; return false }
                try { Thread.sleep(1000L * attempt) } catch (ie: InterruptedException) { return false }
            } finally {
                try { c?.disconnect() } catch (x: Exception) {}
            }
        }
        return true
    }
}
