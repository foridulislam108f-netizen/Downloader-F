package com.foridul.mediadl

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.net.wifi.WifiManager
import android.os.IBinder
import android.os.PowerManager

/** ডাউনলোড চলার সময় অ্যাপ ব্যাকগ্রাউন্ডে গেলেও যেন বন্ধ না হয়, তার জন্য ফোরগ্রাউন্ড সার্ভিস */
class DownloadService : Service() {

    companion object {
        private const val CH = "downloads"
        private const val ID = 4711
    }

    private val listener: () -> Unit = { refresh() }
    private var wake: PowerManager.WakeLock? = null
    private var wifi: WifiManager.WifiLock? = null

    // স্ক্রিন বন্ধ হলেও যেন CPU ও ওয়াইফাই ঘুমিয়ে ডাউনলোড না কাটে
    @Suppress("DEPRECATION")
    private fun lockOn() {
        try {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "mediadl:dl").apply { setReferenceCounted(false); acquire(12L * 3600 * 1000) }
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "mediadl:wifi").apply { setReferenceCounted(false); acquire() }
        } catch (e: Exception) {
        }
    }

    private fun lockOff() {
        try { wake?.let { if (it.isHeld) it.release() } } catch (e: Exception) {}
        try { wifi?.let { if (it.isHeld) it.release() } } catch (e: Exception) {}
        wake = null; wifi = null
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel(CH, "ডাউনলোড", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        }
        val n = build("ডাউনলোড শুরু হচ্ছে…", 0, true)
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(ID, n)
        }
        Engine.listeners.add(listener)
        lockOn()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        refresh()
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        Engine.listeners.remove(listener)
        lockOff()
        super.onDestroy()
    }

    private fun refresh() {
        val active = Engine.jobs.filter {
            it.status == Engine.Status.RUNNING || it.status == Engine.Status.QUEUED
        }
        if (active.isEmpty()) {
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return
        }
        val cur = active.firstOrNull { it.status == Engine.Status.RUNNING } ?: active[0]
        val pct = cur.progress.toInt().coerceIn(0, 100)
        val extra = if (active.size > 1) " (+" + (active.size - 1) + ")" else ""
        val text = cur.title.take(40) + extra
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .notify(ID, build(text, pct, cur.progress <= 0f))
    }

    private fun build(text: String, pct: Int, indeterminate: Boolean): Notification {
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CH)
        else Notification.Builder(this)
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        b.setSmallIcon(android.R.drawable.stat_sys_download)
            .setContentTitle("MediaDL Pro")
            .setContentText(text)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, pct, indeterminate)
            .setContentIntent(pi)
        return b.build()
    }
}
