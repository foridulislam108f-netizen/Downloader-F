package com.foridul.mediadl

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.MediaController
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView

/** ডাউনলোড করা ভিডিও/অডিও অ্যাপের ভেতরেই চালানোর প্লেয়ার */
class PlayerActivity : Activity() {
    private lateinit var video: VideoView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val uri = intent.data
        val name = intent.getStringExtra("name") ?: ""
        val mime = intent.getStringExtra("mime") ?: "*/*"
        val isAudio = intent.getBooleanExtra("audio", false)
        if (uri == null) { finish(); return }

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        video = VideoView(this)
        root.addView(video, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))

        if (isAudio) {
            val tv = TextView(this)
            tv.text = "♪\n\n" + name
            tv.setTextColor(Color.WHITE)
            tv.textSize = 18f
            tv.gravity = Gravity.CENTER
            tv.setTypeface(tv.typeface, Typeface.BOLD)
            tv.setPadding(48, 48, 48, 48)
            root.addView(tv, FrameLayout.LayoutParams(-1, -1))
        }

        val back = TextView(this)
        back.text = "‹  " + name
        back.setTextColor(Color.WHITE)
        back.textSize = 15f
        back.maxLines = 1
        back.ellipsize = android.text.TextUtils.TruncateAt.END
        back.setBackgroundColor(Color.argb(120, 0, 0, 0))
        back.setPadding(32, 28, 32, 28)
        back.setOnClickListener { finish() }
        root.addView(back, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        setContentView(root)

        val mc = MediaController(this)
        mc.setAnchorView(video)
        video.setMediaController(mc)
        video.setVideoURI(uri)
        video.setOnPreparedListener { it.isLooping = false; video.start() }
        video.setOnCompletionListener { mc.show(0) }
        video.setOnErrorListener { _, _, _ ->
            // চালানো না গেলে অন্য প্লেয়ার অ্যাপে চেষ্টা
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                )
            } catch (e: Exception) {
                Toast.makeText(this, L.t("noApp"), Toast.LENGTH_LONG).show()
            }
            finish()
            true
        }
    }

    override fun onPause() {
        super.onPause()
        if (::video.isInitialized) video.pause()
    }
}
