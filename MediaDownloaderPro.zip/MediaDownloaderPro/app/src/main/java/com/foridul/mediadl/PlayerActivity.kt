package com.foridul.mediadl

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView

/** ডাউনলোড করা ভিডিও/অডিও অ্যাপের ভেতরেই চালানোর প্লেয়ার */
class PlayerActivity : Activity() {
    private lateinit var video: VideoView
    private lateinit var ctrl: LinearLayout
    private lateinit var seek: SeekBar
    private lateinit var tPos: TextView
    private lateinit var tDur: TextView
    private lateinit var btnPlay: ImageView

    private val ui = Handler(Looper.getMainLooper())
    private var seeking = false
    private var controlsShown = false

    /** কন্ট্রোল ৫ সেকেন্ড পর মিলিয়ে যাবে */
    private val hideRunnable = Runnable { hideControls() }

    /** প্রতি ২৫০ms-এ সময়/সিকবার/প্লে বাটন আপডেট */
    private val tick = object : Runnable {
        override fun run() {
            if (::video.isInitialized && video.duration > 0) {
                if (!seeking) {
                    seek.progress = video.currentPosition
                    tPos.text = fmt(video.currentPosition.toLong())
                }
                btnPlay.setImageResource(
                    if (video.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
                )
            }
            ui.postDelayed(this, 250)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val uri = intent.data
        val name = intent.getStringExtra("name") ?: ""
        val mime = intent.getStringExtra("mime") ?: "*/*"
        val isAudio = intent.getBooleanExtra("audio", false)
        if (uri == null) { finish(); return }

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.BLACK)

        video = VideoView(this)
        root.addView(video, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))

        if (isAudio) {
            val tv = TextView(this)
            tv.text = "♪\n\n" + name
            tv.setTextColor(Color.WHITE)
            tv.textSize = 18f
            tv.gravity = Gravity.CENTER
            tv.setTypeface(tv.typeface, Typeface.BOLD)
            tv.setPadding(48, 48, 48, 48)
            root.addView(tv, FrameLayout.LayoutParams(-1, -1))
        }

        val back = TextView(this)
        back.text = "‹  " + name
        back.setTextColor(Color.WHITE)
        back.textSize = 15f
        back.maxLines = 1
        back.ellipsize = android.text.TextUtils.TruncateAt.END
        back.setBackgroundColor(Color.argb(120, 0, 0, 0))
        back.setPadding(32, 28, 32, 28)
        back.setOnClickListener { finish() }
        root.addView(back, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        // ---- নিচের কন্ট্রোল: একটু উপরে তোলা (dp(36) বটম মার্জিন) ----
        ctrl = buildControls()
        root.addView(
            ctrl,
            FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { bottomMargin = dp(36) }
        )

        setContentView(root)

        video.setVideoURI(uri)
        video.setOnPreparedListener {
            it.isLooping = false
            seek.max = video.duration
            tDur.text = fmt(video.duration.toLong())
            video.start()
            ui.post(tick)
            showControls()
        }
        video.setOnCompletionListener { showControls() }
        video.setOnErrorListener { _, _, _ ->
            // চালানো না গেলে অন্য প্লেয়ার অ্যাপে চেষ্টা
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                )
            } catch (e: Exception) {
                Toast.makeText(this, L.t("noApp"), Toast.LENGTH_LONG).show()
            }
            finish()
            true
        }
    }

    private fun buildControls(): LinearLayout {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(10))
        }

        // সময় | সিকবার | মোট সময়
        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        tPos = timeText("0:00")
        tDur = timeText("0:00")
        seek = SeekBar(this).apply {
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    if (fromUser) tPos.text = fmt(p.toLong())
                }
                override fun onStartTrackingTouch(sb: SeekBar) {
                    seeking = true
                    ui.removeCallbacks(hideRunnable)
                }
                override fun onStopTrackingTouch(sb: SeekBar) {
                    video.seekTo(sb.progress)
                    seeking = false
                    showControls()
                }
            })
        }
        row1.addView(tPos)
        row1.addView(seek, LinearLayout.LayoutParams(0, -2, 1f).apply {
            leftMargin = dp(8); rightMargin = dp(8)
        })
        row1.addView(tDur)

        // ‑১০s | প্লে/পজ | +১০s
        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val btnBack = iconButton(android.R.drawable.ic_media_rew) {
            video.seekTo(maxOf(0, video.currentPosition - 10_000))
            showControls()
        }
        btnPlay = iconButton(android.R.drawable.ic_media_play) {
            if (video.isPlaying) video.pause() else video.start()
            showControls()
        }
        val btnFwd = iconButton(android.R.drawable.ic_media_ff) {
            video.seekTo(minOf(video.duration, video.currentPosition + 10_000))
            showControls()
        }
        row2.addView(btnBack)
        row2.addView(btnPlay, LinearLayout.LayoutParams(-2, -2).apply {
            leftMargin = dp(28); rightMargin = dp(28)
        })
        row2.addView(btnFwd)

        col.addView(row1)
        col.addView(row2, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        return col
    }

    private fun timeText(s: String) = TextView(this).apply {
        text = s
        setTextColor(Color.WHITE)
        textSize = 12f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        minWidth = dp(44)
        gravity = Gravity.CENTER
    }

    /** Android-এর সাদা মিডিয়া আইকন, ডিফল্ট MediaController-এর মতোই (রঙ বদলায় না) */
    private fun iconButton(iconRes: Int, onClick: () -> Unit) = ImageView(this).apply {
        setImageResource(iconRes)
        setColorFilter(Color.WHITE)
        scaleType = ImageView.ScaleType.CENTER
        setPadding(dp(14), dp(6), dp(14), dp(6))
        setOnClickListener { onClick() }
    }

    /** যেকোনো টাচে কন্ট্রোল দেখায় এবং ৫ সেকেন্ডের টাইমার নতুন করে শুরু করে */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) showControls()
        return super.dispatchTouchEvent(ev)
    }

    private fun showControls() {
        if (!::ctrl.isInitialized) return
        ui.removeCallbacks(hideRunnable)
        if (!controlsShown) {
            controlsShown = true
            ctrl.visibility = android.view.View.VISIBLE
            ctrl.animate().cancel()
            ctrl.animate().alpha(1f).setDuration(150).start()
        }
        if (!seeking) ui.postDelayed(hideRunnable, 5000)
    }

    private fun hideControls() {
        if (!::ctrl.isInitialized || !controlsShown) return
        controlsShown = false
        ctrl.animate().cancel()
        ctrl.animate().alpha(0f).setDuration(200).withEndAction {
            if (!controlsShown) ctrl.visibility = android.view.View.GONE
        }.start()
    }

    private fun fmt(ms: Long): String {
        val s = maxOf(0L, ms) / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onPause() {
        super.onPause()
        if (::video.isInitialized) video.pause()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
