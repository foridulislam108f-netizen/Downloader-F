package com.foridul.mediadl

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import android.widget.Toast
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.youtubedl_android.mapper.VideoFormat
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * yt-dlp ইঞ্জিনের চারপাশের সব কাজ: বিশ্লেষণ, ডাউনলোড-কিউ, প্রগ্রেস, Downloads-এ সেভ, আপডেট।
 */
object Engine {

    enum class Status { QUEUED, RUNNING, DONE, FAILED, CANCELED }

    class Arg(val key: String, val value: String? = null)

    class Choice(val label: String, val args: List<Arg>)

    class Analysis(val title: String, val choices: List<Choice>)

    class Job(
        val id: String,
        val url: String,
        val title: String,
        val args: List<Arg>,
        val cookies: String?,
        val ua: String?
    ) {
        @Volatile var status = Status.QUEUED
        @Volatile var progress = 0f
        @Volatile var eta = 0L
        @Volatile var message = ""
        @Volatile var saved: String? = null
        @Volatile var cancelRequested = false
        @Volatile var lastNotifyMs = 0L
    }

    val jobs = CopyOnWriteArrayList<Job>()
    val listeners = CopyOnWriteArrayList<() -> Unit>()

    private lateinit var app: Context
    private val ready = CountDownLatch(1)
    @Volatile private var initError: String? = null
    private val pool = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())
    private val counter = AtomicInteger(0)

    // ---------- চালু করা ----------

    fun init(context: Context) {
        app = context.applicationContext
        History.init(app)
        Thread {
            try {
                YoutubeDL.getInstance().init(app)
                FFmpeg.getInstance().init(app)
            } catch (e: Exception) {
                initError = shortError(e)
            } finally {
                ready.countDown()
            }
            if (initError == null) autoUpdate()
        }.start()
    }

    private fun waitReady() {
        if (!ready.await(90, TimeUnit.SECONDS)) {
            throw Exception("ইঞ্জিন চালু হতে সময় নিচ্ছে, কিছুক্ষণ পর আবার চেষ্টা করুন")
        }
        val err = initError
        if (err != null) throw Exception("ইঞ্জিন চালু করা যায়নি: $err")
    }

    /** সাইটগুলো প্রায়ই বদলায়, তাই yt-dlp ৩ দিনে একবার নিজে আপডেট হয়। */
    private fun autoUpdate() {
        try {
            val p = app.getSharedPreferences("mdl", Context.MODE_PRIVATE)
            val last = p.getLong("lastUpdate", 0L)
            if (System.currentTimeMillis() - last < 3L * 24 * 3600 * 1000) return
            YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.STABLE)
            p.edit().putLong("lastUpdate", System.currentTimeMillis()).apply()
        } catch (e: Exception) {
            // নেটওয়ার্ক না থাকলে পরেরবার চেষ্টা হবে
        }
    }

    fun updateNow(): String {
        waitReady()
        val st = YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.STABLE)
        app.getSharedPreferences("mdl", Context.MODE_PRIVATE)
            .edit().putLong("lastUpdate", System.currentTimeMillis()).apply()
        val v = YoutubeDL.getInstance().versionName(app) ?: "?"
        return if (st == YoutubeDL.UpdateStatus.DONE) "ইঞ্জিন আপডেট হয়েছে (yt-dlp $v)"
        else "ইঞ্জিন আগে থেকেই সর্বশেষ (yt-dlp $v)"
    }

    // ---------- সাহায্যকারী ----------

    fun shortError(e: Throwable): String {
        val msg = e.message ?: e.toString()
        val lines = msg.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val line = lines.lastOrNull { it.contains("ERROR", ignoreCase = true) } ?: lines.lastOrNull() ?: msg
        return line.removePrefix("ERROR:").trim().take(300)
    }

    private fun notifyChange() {
        main.post { for (l in listeners) l() }
    }

    private fun toast(msg: String) {
        main.post { Toast.makeText(app, msg, Toast.LENGTH_LONG).show() }
    }

    /** WebView-এর লগইন-কুকি yt-dlp-কে দেওয়ার জন্য (লগইন লাগে এমন সাইটে কাজে লাগে) */
    private fun cookieFile(url: String, raw: String?): File? {
        if (raw.isNullOrBlank()) return null
        val host = Uri.parse(url).host ?: return null
        val domain = host.removePrefix("www.")
        val sb = StringBuilder("# Netscape HTTP Cookie File\n")
        for (part in raw.split(";")) {
            val kv = part.trim()
            val i = kv.indexOf('=')
            if (i <= 0) continue
            sb.append('.').append(domain).append("\tTRUE\t/\tFALSE\t0\t")
                .append(kv.substring(0, i)).append('\t').append(kv.substring(i + 1)).append('\n')
        }
        val f = File(app.cacheDir, "ck_" + System.nanoTime() + ".txt")
        f.writeText(sb.toString())
        return f
    }

    private fun commonNet(req: YoutubeDLRequest, ck: File?, ua: String?) {
        if (ck != null) req.addOption("--cookies", ck.absolutePath)
        if (!ua.isNullOrEmpty()) req.addOption("--user-agent", ua)
    }

    fun isPlaylistUrl(u: String): Boolean {
        val l = u.lowercase()
        if (l.contains("watch?v=") || l.contains("/video/") || l.contains("/shorts/") ||
            l.contains("/reel/") || l.contains("/status/") || l.contains("youtu.be/")
        ) return false
        return l.contains("/playlist") || l.contains("/channel/") || l.contains("/@") ||
            l.contains("/user/") || l.contains("/sets/")
    }

    private fun fmtSize(bytes: Long): String {
        val mb = bytes / 1048576.0
        return if (mb >= 1024) String.format("%.1f GB", mb / 1024) else String.format("%.0f MB", mb)
    }

    // ---------- বিশ্লেষণ: পেজে কী কী নামানো যায় ----------

    private val VIDEO_ARGS = listOf(
        Arg("-S", "res,ext:mp4:m4a"),
        Arg("--merge-output-format", "mp4/mkv")
    )

    fun analyze(url: String, rawCookies: String?, ua: String?): Analysis {
        waitReady()
        val ck = cookieFile(url, rawCookies)
        try {
            val req = YoutubeDLRequest(url)
            req.addOption("--no-playlist")
            req.addOption("--no-warnings")
            req.addOption("--socket-timeout", 20)
            commonNet(req, ck, ua)
            val info = YoutubeDL.getInstance().getInfo(req)

            val fm: List<VideoFormat> = info.formats ?: emptyList()
            fun size(f: VideoFormat): Long = if (f.fileSize > 0) f.fileSize else f.fileSizeApproximate
            fun isVideo(f: VideoFormat) = f.vcodec != null && f.vcodec != "none" && f.height > 0
            fun isAudioOnly(f: VideoFormat) =
                f.acodec != null && f.acodec != "none" && (f.vcodec == null || f.vcodec == "none")

            val bestAudio = fm.filter { isAudioOnly(it) }.maxOfOrNull { size(it) } ?: 0L
            val heights = fm.filter { isVideo(it) }.map { it.height }.distinct().sortedDescending().take(8)

            val out = ArrayList<Choice>()
            out.add(Choice("⭐ সেরা মান (ভিডিও)", listOf(Arg("-f", "bv*+ba/b")) + VIDEO_ARGS))
            for (h in heights) {
                val v = fm.filter { isVideo(it) && it.height == h }.maxOfOrNull { size(it) } ?: 0L
                val total = if (v > 0) v + bestAudio else 0L
                val sz = if (total > 0) " • ~" + fmtSize(total) else ""
                out.add(
                    Choice(
                        "🎬 ${h}p$sz",
                        listOf(Arg("-f", "bv*[height<=$h]+ba/b[height<=$h]/b")) + VIDEO_ARGS
                    )
                )
            }
            val aSz = if (bestAudio > 0) " • ~" + fmtSize(bestAudio) else ""
            out.add(
                Choice(
                    "🎵 শুধু অডিও – MP3",
                    listOf(Arg("-f", "ba/b"), Arg("-x"), Arg("--audio-format", "mp3"), Arg("--audio-quality", "0"))
                )
            )
            out.add(Choice("🎵 শুধু অডিও – মূল মান (দ্রুত)$aSz", listOf(Arg("-f", "ba/b"), Arg("-x"))))

            val title = info.title ?: info.fulltitle ?: url
            return Analysis(title, out)
        } finally {
            ck?.delete()
        }
    }

    fun playlistChoices(): List<Choice> {
        val base = listOf(Arg("--yes-playlist"), Arg("--ignore-errors"))
        return listOf(
            Choice("📃 পুরো প্লেলিস্ট – ভিডিও (সেরা মান)", base + listOf(Arg("-f", "bv*+ba/b")) + VIDEO_ARGS),
            Choice("📃 পুরো প্লেলিস্ট – ভিডিও (≤720p)", base + listOf(Arg("-f", "bv*[height<=720]+ba/b[height<=720]/b")) + VIDEO_ARGS),
            Choice(
                "📃 পুরো প্লেলিস্ট – MP3",
                base + listOf(Arg("-f", "ba/b"), Arg("-x"), Arg("--audio-format", "mp3"), Arg("--audio-quality", "0"))
            )
        )
    }

    // ---------- ডাউনলোড-কিউ ----------

    fun enqueue(ctx: Context, url: String, title: String, choice: Choice, cookies: String?, ua: String?): Job {
        val job = Job("j" + counter.incrementAndGet() + "_" + System.currentTimeMillis(), url, title, choice.args, cookies, ua)
        jobs.add(0, job)
        pool.execute { run(job) }
        val i = Intent(ctx, DownloadService::class.java)
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        notifyChange()
        return job
    }

    fun cancel(job: Job) {
        job.cancelRequested = true
        if (job.status == Status.RUNNING) {
            YoutubeDL.getInstance().destroyProcessById(job.id)
        } else if (job.status == Status.QUEUED) {
            finish(job, Status.CANCELED, "")
        }
    }

    fun clearFinished() {
        jobs.removeAll(jobs.filter {
            it.status == Status.DONE || it.status == Status.FAILED || it.status == Status.CANCELED
        })
        notifyChange()
    }

    private fun finish(job: Job, st: Status, msg: String) {
        job.status = st
        job.message = msg
        notifyChange()
        when (st) {
            Status.DONE -> toast("✓ ডাউনলোড সম্পূর্ণ: " + job.title.take(40))
            Status.FAILED -> toast("✗ ব্যর্থ: " + msg)
            else -> {}
        }
    }

    private fun isTemp(name: String): Boolean =
        name.contains(".part") || name.endsWith(".ytdl") || name.endsWith(".temp") || name.endsWith(".tmp")

    private fun run(job: Job) {
        if (job.cancelRequested) {
            finish(job, Status.CANCELED, "")
            return
        }
        job.status = Status.RUNNING
        notifyChange()

        val base = app.getExternalFilesDir(null) ?: app.filesDir
        val tmp = File(base, "dl/" + job.id)
        tmp.mkdirs()
        val ck = cookieFile(job.url, job.cookies)
        try {
            waitReady()
            val playlist = job.args.any { it.key == "--yes-playlist" }
            val tpl = if (playlist) "%(playlist_index)s - %(title).100B.%(ext)s" else "%(title).100B.%(ext)s"

            val req = YoutubeDLRequest(job.url)
            req.addOption("-o", File(tmp, tpl).absolutePath)
            req.addOption("--no-mtime")
            req.addOption("--no-warnings")
            req.addOption("--retries", 10)
            req.addOption("--fragment-retries", 10)
            req.addOption("--concurrent-fragments", 4)
            req.addOption("--socket-timeout", 30)
            if (!playlist) req.addOption("--no-playlist")
            commonNet(req, ck, job.ua)
            for (a in job.args) {
                val v = a.value
                if (v == null) req.addOption(a.key) else req.addOption(a.key, v)
            }

            YoutubeDL.getInstance().execute(req, job.id) { p, eta, _ ->
                job.progress = p
                job.eta = eta
                val now = System.currentTimeMillis()
                if (now - job.lastNotifyMs > 500) {
                    job.lastNotifyMs = now
                    notifyChange()
                }
            }

            val files = tmp.listFiles()?.filter { it.isFile && !isTemp(it.name) } ?: emptyList()
            if (files.isEmpty()) throw Exception("কোনো ফাইল তৈরি হয়নি")
            var last = ""
            for (f in files) {
                last = publish(f)
                History.add(last, job.url, "yt", job.title, job.args, f.length())
            }
            job.saved = last
            job.progress = 100f
            finish(job, Status.DONE, last)
        } catch (e: YoutubeDL.CanceledException) {
            finish(job, Status.CANCELED, "")
        } catch (e: Exception) {
            if (job.cancelRequested) finish(job, Status.CANCELED, "")
            else finish(job, Status.FAILED, shortError(e))
        } finally {
            ck?.delete()
            tmp.deleteRecursively()
        }
    }

    /** ফাইলটা ফোনের Downloads/MediaDownloader ফোল্ডারে সরায় */
    private fun publish(f: File): String {
        val ext = f.extension.lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        if (Build.VERSION.SDK_INT >= 29) {
            val resolver = app.contentResolver
            val cv = ContentValues()
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime)
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MediaDownloader")
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1)
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                ?: throw Exception("Downloads-এ ফাইল তৈরি করা যায়নি")
            resolver.openOutputStream(uri)!!.use { out -> f.inputStream().use { it.copyTo(out) } }
            val done = ContentValues()
            done.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, done, null, null)
            // নামে মিল থাকলে সিস্টেম নাম বদলে দেয়; আসল নামটা নিয়ে নেওয়া
            var realName = f.name
            resolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) realName = c.getString(0) ?: f.name
            }
            return "Download/MediaDownloader/" + realName
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "MediaDownloader")
            dir.mkdirs()
            val dest = File(dir, f.name)
            f.copyTo(dest, overwrite = true)
            MediaScannerConnection.scanFile(app, arrayOf(dest.absolutePath), arrayOf(mime), null)
        }
        return "Download/MediaDownloader/" + f.name
    }
}
