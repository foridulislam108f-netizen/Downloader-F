package com.foridul.mediadl

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import android.widget.Toast
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import com.yausername.youtubedl_android.mapper.VideoFormat
import java.io.File
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/**
 * yt-dlp ইঞ্জিনের চারপাশের সব কাজ: বিশ্লেষণ, ডাউনলোড-কিউ, প্রগ্রেস, Downloads-এ সেভ, আপডেট।
 */
object Engine {

    enum class Status { QUEUED, RUNNING, DONE, FAILED, CANCELED }

    class Arg(val key: String, val value: String? = null)

    /** kind: "video" | "audio" | "playlist"; sub: সাইজ/ফরম্যাট-বিবরণ (প্যানেলে ছোট লেখায় দেখায়) */
    class Choice(val label: String, val args: List<Arg>, val kind: String = "video", val sub: String = "")

    class Analysis(val title: String, val video: List<Choice>, val audio: List<Choice>)

    class Job(
        val id: String,
        val url: String,
        val title: String,
        val args: List<Arg>,
        val cookies: String?,
        val ua: String?,
        val label: String = ""
    ) {
        @Volatile var status = Status.QUEUED
        @Volatile var progress = 0f
        @Volatile var eta = 0L
        @Volatile var message = ""
        @Volatile var saved: String? = null
        @Volatile var cancelRequested = false
        @Volatile var lastNotifyMs = 0L
    }

    val jobs = CopyOnWriteArrayList<Job>()
    val listeners = CopyOnWriteArrayList<() -> Unit>()

    private lateinit var app: Context
    private val ready = CountDownLatch(1)
    @Volatile private var initError: String? = null
    private val pool = Executors.newFixedThreadPool(2)
    private val main = Handler(Looper.getMainLooper())
    private val counter = AtomicInteger(0)

    // ---------- চালু করা ----------

    fun init(context: Context) {
        app = context.applicationContext
        History.init(app)
        L.init(app)
        Thread {
            try {
                YoutubeDL.getInstance().init(app)
                FFmpeg.getInstance().init(app)
            } catch (e: Exception) {
                initError = shortError(e)
            } finally {
                ready.countDown()
            }
            cleanOldPartials()
            if (initError == null) autoUpdate()
        }.start()
    }

    private fun waitReady() {
        if (!ready.await(90, TimeUnit.SECONDS)) {
            throw Exception(L.t("engBusy"))
        }
        val err = initError
        if (err != null) throw Exception(L.t("engFail") + err)
    }

    /** সাইটগুলো প্রায়ই বদলায়, তাই yt-dlp ৩ দিনে একবার নিজে আপডেট হয়। */
    private fun autoUpdate() {
        try {
            val p = app.getSharedPreferences("mdl", Context.MODE_PRIVATE)
            val last = p.getLong("lastUpdate", 0L)
            if (System.currentTimeMillis() - last < 3L * 24 * 3600 * 1000) return
            YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.STABLE)
            p.edit().putLong("lastUpdate", System.currentTimeMillis()).apply()
        } catch (e: Exception) {
            // নেটওয়ার্ক না থাকলে পরেরবার চেষ্টা হবে
        }
    }

    fun updateNow(): String {
        waitReady()
        val st = YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.STABLE)
        app.getSharedPreferences("mdl", Context.MODE_PRIVATE)
            .edit().putLong("lastUpdate", System.currentTimeMillis()).apply()
        val v = YoutubeDL.getInstance().versionName(app) ?: "?"
        return if (st == YoutubeDL.UpdateStatus.DONE) L.t("engUpdated") + v + ")"
        else L.t("engLatest") + v + ")"
    }

    // ---------- সাহায্যকারী ----------

    fun shortError(e: Throwable): String {
        val msg = e.message ?: e.toString()
        val lines = msg.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val line = lines.lastOrNull { it.contains("ERROR", ignoreCase = true) } ?: lines.lastOrNull() ?: msg
        return line.removePrefix("ERROR:").trim().take(300)
    }

    private fun notifyChange() {
        main.post { for (l in listeners) l() }
    }

    private fun toast(msg: String) {
        main.post { Toast.makeText(app, msg, Toast.LENGTH_LONG).show() }
    }

    /** WebView-এর লগইন-কুকি yt-dlp-কে দেওয়ার জন্য (লগইন লাগে এমন সাইটে কাজে লাগে) */
    private fun cookieFile(url: String, raw: String?): File? {
        if (raw.isNullOrBlank()) return null
        val host = Uri.parse(url).host ?: return null
        val domain = host.removePrefix("www.")
        val sb = StringBuilder("# Netscape HTTP Cookie File\n")
        for (part in raw.split(";")) {
            val kv = part.trim()
            val i = kv.indexOf('=')
            if (i <= 0) continue
            sb.append('.').append(domain).append("\tTRUE\t/\tFALSE\t0\t")
                .append(kv.substring(0, i)).append('\t').append(kv.substring(i + 1)).append('\n')
        }
        val f = File(app.cacheDir, "ck_" + System.nanoTime() + ".txt")
        f.writeText(sb.toString())
        return f
    }

    private fun commonNet(req: YoutubeDLRequest, ck: File?, ua: String?) {
        if (ck != null) req.addOption("--cookies", ck.absolutePath)
        if (!ua.isNullOrEmpty()) req.addOption("--user-agent", ua)
    }

    fun isPlaylistUrl(u: String): Boolean {
        val l = u.lowercase()
        if (l.contains("watch?v=") || l.contains("/video/") || l.contains("/shorts/") ||
            l.contains("/reel/") || l.contains("/status/") || l.contains("youtu.be/")
        ) return false
        return l.contains("/playlist") || l.contains("/channel/") || l.contains("/@") ||
            l.contains("/user/") || l.contains("/sets/")
    }

    private fun fmtSize(bytes: Long): String {
        val mb = bytes / 1048576.0
        return if (mb >= 1024) String.format("%.1f GB", mb / 1024) else String.format("%.0f MB", mb)
    }

    // ---------- বিশ্লেষণ: পেজে কী কী নামানো যায় ----------

    private val VIDEO_ARGS = listOf(
        Arg("-S", "res,ext:mp4:m4a"),
        Arg("--merge-output-format", "mp4/mkv")
    )

    private fun isYoutube(u: String): Boolean {
        val l = u.lowercase()
        return l.contains("youtube.com") || l.contains("youtu.be") || l.contains("youtube-nocookie.com")
    }

    /** YouTube প্রায়ই কিছু ক্লায়েন্টকে আটকে দেয়; একটা ব্যর্থ হলে পরেরটা চেষ্টা করা হয় */
    private fun youtubeFallbacks(): List<List<Arg>> = listOf(
        emptyList(),
        listOf(Arg("--extractor-args", "youtube:player_client=mweb")),
        listOf(Arg("--extractor-args", "youtube:player_client=android_vr")),
        listOf(Arg("--extractor-args", "youtube:player_client=tv_embedded"))
    )

    fun analyze(url: String, rawCookies: String?, ua: String?): Analysis {
        waitReady()
        val ck = cookieFile(url, rawCookies)
        try {
            val tries = if (isYoutube(url)) youtubeFallbacks() else listOf(emptyList())
            var lastErr: Exception? = null
            var info: com.yausername.youtubedl_android.mapper.VideoInfo? = null
            var extra: List<Arg> = emptyList()
            for (t in tries) {
                try {
                    val req = YoutubeDLRequest(url)
                    req.addOption("--no-playlist")
                    req.addOption("--no-warnings")
                    req.addOption("--socket-timeout", 20)
                    for (a in t) req.addOption(a.key, a.value ?: "")
                    commonNet(req, ck, ua)
                    val r = YoutubeDL.getInstance().getInfo(req)
                    if ((r.formats ?: emptyList<VideoFormat>()).isEmpty()) throw Exception(L.t("noFmt"))
                    info = r
                    extra = t
                    break
                } catch (e: Exception) {
                    lastErr = e
                }
            }
            if (info == null) throw (lastErr ?: Exception(L.t("anFail")))

            val fm: List<VideoFormat> = info.formats ?: emptyList()
            fun size(f: VideoFormat): Long = if (f.fileSize > 0) f.fileSize else f.fileSizeApproximate
            fun isVideo(f: VideoFormat) = f.vcodec != null && f.vcodec != "none" && f.height > 0
            fun isAudioOnly(f: VideoFormat) =
                f.acodec != null && f.acodec != "none" && (f.vcodec == null || f.vcodec == "none")

            val audioFmts = fm.filter { isAudioOnly(it) }
            val bestAudio = audioFmts.maxOfOrNull { size(it) } ?: 0L
            val heights = fm.filter { isVideo(it) }.map { it.height }.distinct().sortedDescending()

            // ---- ভিডিও: সব রেজোলিউশন ----
            val video = ArrayList<Choice>()
            video.add(Choice("⭐ Best", listOf(Arg("-f", "bv*+ba/b")) + VIDEO_ARGS + extra, "video", "best"))
            for (h in heights) {
                val sameH = fm.filter { isVideo(it) && it.height == h }
                val v = sameH.maxOfOrNull { size(it) } ?: 0L
                val total = if (v > 0) v + bestAudio else 0L
                val ext = sameH.firstOrNull { it.ext == "mp4" }?.ext ?: sameH.firstOrNull()?.ext ?: "mp4"
                val sub = ext.uppercase() + (if (total > 0) " • ~" + fmtSize(total) else "")
                video.add(
                    Choice(
                        "${h}p",
                        listOf(Arg("-f", "bv*[height<=$h]+ba/b[height<=$h]/b")) + VIDEO_ARGS + extra,
                        "video", sub
                    )
                )
            }

            // ---- অডিও: MP3 (রূপান্তর) + মূল ফরম্যাটগুলো ----
            val audio = ArrayList<Choice>()
            fun mp3(q: String, label: String, sub: String) = Choice(
                label,
                listOf(Arg("-f", "ba/b"), Arg("-x"), Arg("--audio-format", "mp3"), Arg("--audio-quality", q)) + extra,
                "audio", sub
            )
            audio.add(mp3("0", "MP3 • Best", "MP3" + (if (bestAudio > 0) " • ~" + fmtSize(bestAudio) else "")))
            audio.add(mp3("192K", "MP3 • 192 kbps", "MP3"))
            audio.add(mp3("128K", "MP3 • 128 kbps", "MP3"))
            val byExt = audioFmts.groupBy { it.ext ?: "audio" }
            for ((ext, list) in byExt) {
                val best = list.maxByOrNull { size(it) } ?: continue
                val sz = size(best)
                audio.add(
                    Choice(
                        ext.uppercase() + " • Original",
                        listOf(Arg("-f", best.formatId ?: "ba/b"), Arg("-x")) + extra,
                        "audio",
                        ext.uppercase() + (if (sz > 0) " • ~" + fmtSize(sz) else "")
                    )
                )
            }
            if (byExt.isEmpty()) {
                audio.add(Choice("Original", listOf(Arg("-f", "ba/b"), Arg("-x")) + extra, "audio", ""))
            }

            val title = info.title ?: info.fulltitle ?: url
            return Analysis(title, video, audio)
        } finally {
            ck?.delete()
        }
    }

    fun playlistChoices(): List<Choice> {
        val base = listOf(Arg("--yes-playlist"), Arg("--ignore-errors"))
        return listOf(
            Choice("Playlist • Video (Best)", base + listOf(Arg("-f", "bv*+ba/b")) + VIDEO_ARGS, "playlist", ""),
            Choice("Playlist • Video (≤720p)", base + listOf(Arg("-f", "bv*[height<=720]+ba/b[height<=720]/b")) + VIDEO_ARGS, "playlist", ""),
            Choice(
                "Playlist • MP3",
                base + listOf(Arg("-f", "ba/b"), Arg("-x"), Arg("--audio-format", "mp3"), Arg("--audio-quality", "0")),
                "playlist", ""
            )
        )
    }

    // ---------- ডাউনলোড-কিউ ----------

    fun enqueue(ctx: Context, url: String, title: String, choice: Choice, cookies: String?, ua: String?): Job {
        val job = Job("j" + counter.incrementAndGet() + "_" + System.currentTimeMillis(), url, title, choice.args, cookies, ua, choice.label)
        jobs.add(0, job)
        pool.execute { run(job) }
        val i = Intent(ctx, DownloadService::class.java)
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        notifyChange()
        return job
    }

    /** ব্যর্থ/বাতিল ডাউনলোড আবার শুরু; আংশিক ফাইল থাকলে সেখান থেকেই চলে */
    fun retry(ctx: Context, job: Job) {
        if (job.status != Status.FAILED && job.status != Status.CANCELED) return
        job.cancelRequested = false
        job.progress = 0f
        job.eta = 0L
        job.message = ""
        job.status = Status.QUEUED
        pool.execute { run(job) }
        val i = Intent(ctx, DownloadService::class.java)
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        notifyChange()
    }

    /** একই লিংক+ফরম্যাট হলে একই ফোল্ডার, যাতে .part ফাইল থেকে চালিয়ে যাওয়া যায় */
    private fun resumeDir(job: Job): File {
        val key = (job.url + "|" + job.args.joinToString(",") { it.key + "=" + (it.value ?: "") }).hashCode().toUInt().toString(16)
        return File(app.getExternalFilesDir(null) ?: app.filesDir, "dl/r_$key")
    }

    private fun isNetworkError(msg: String): Boolean {
        val m = msg.lowercase()
        return listOf(
            "timed out", "timeout", "connection", "reset", "unreachable", "network", "ssl", "eof",
            "incomplete", "http error 5", "temporary failure", "name resolution", "broken pipe", "read error"
        ).any { m.contains(it) }
    }

    fun cancel(job: Job) {
        job.cancelRequested = true
        if (job.status == Status.RUNNING) {
            YoutubeDL.getInstance().destroyProcessById(job.id)
        } else if (job.status == Status.QUEUED) {
            finish(job, Status.CANCELED, "")
        }
    }

    fun clearFinished() {
        jobs.removeAll(jobs.filter {
            it.status == Status.DONE || it.status == Status.FAILED || it.status == Status.CANCELED
        })
        notifyChange()
    }

    private fun finish(job: Job, st: Status, msg: String) {
        job.status = st
        job.message = msg
        notifyChange()
        when (st) {
            Status.DONE -> toast(L.t("dlDone") + job.title.take(40))
            Status.FAILED -> toast(L.t("dlFailed") + msg)
            else -> {}
        }
    }

    private fun isTemp(name: String): Boolean =
        name.contains(".part") || name.endsWith(".ytdl") || name.endsWith(".temp") || name.endsWith(".tmp")

    private fun run(job: Job) {
        if (job.status != Status.QUEUED) return   // পুরনো/দ্বিতীয় কাজ হলে বাদ
        if (job.cancelRequested) {
            finish(job, Status.CANCELED, "")
            return
        }
        job.status = Status.RUNNING
        notifyChange()

        val tmp = resumeDir(job)
        tmp.mkdirs()
        val ck = cookieFile(job.url, job.cookies)
        try {
            waitReady()
            val playlist = job.args.any { it.key == "--yes-playlist" }
            val tpl = if (playlist) "%(playlist_index)s - %(title).100B.%(ext)s" else "%(title).100B.%(ext)s"

            val req = YoutubeDLRequest(job.url)
            req.addOption("-o", File(tmp, tpl).absolutePath)
            req.addOption("--no-mtime")
            req.addOption("--no-warnings")
            req.addOption("--retries", 10)
            req.addOption("--fragment-retries", 10)
            req.addOption("--concurrent-fragments", 4)
            req.addOption("--socket-timeout", 30)
            if (!playlist) req.addOption("--no-playlist")
            commonNet(req, ck, job.ua)
            for (a in job.args) {
                val v = a.value
                if (v == null) req.addOption(a.key) else req.addOption(a.key, v)
            }

            req.addOption("--continue")
            var attempt = 0
            while (true) {
                attempt++
                try {
                    YoutubeDL.getInstance().execute(req, job.id) { p, eta, _ ->
                        job.progress = p
                        job.eta = eta
                        val now = System.currentTimeMillis()
                        if (now - job.lastNotifyMs > 500) {
                            job.lastNotifyMs = now
                            notifyChange()
                        }
                    }
                    break
                } catch (e: YoutubeDL.CanceledException) {
                    throw e
                } catch (e: Exception) {
                    // নেট কেটে গেলে নিজে নিজে ৩ বার পর্যন্ত আবার চেষ্টা; আংশিক ফাইল থেকেই চলে
                    if (job.cancelRequested || attempt >= 4 || !isNetworkError(e.message ?: "")) throw e
                    job.message = "reconnecting"
                    notifyChange()
                    Thread.sleep(3000L * attempt)
                }
            }

            val files = tmp.listFiles()?.filter { it.isFile && !isTemp(it.name) } ?: emptyList()
            if (files.isEmpty()) throw Exception(L.t("noFile"))
            var last = ""
            for (f in files) {
                last = publish(f)
                History.add(last, job.url, "yt", job.title, job.args, f.length())
            }
            job.saved = last
            job.progress = 100f
            finish(job, Status.DONE, last)
        } catch (e: YoutubeDL.CanceledException) {
            finish(job, Status.CANCELED, "")
        } catch (e: Exception) {
            if (job.cancelRequested) finish(job, Status.CANCELED, "")
            else finish(job, Status.FAILED, shortError(e))
        } finally {
            ck?.delete()
            // সফল বা বাতিল হলে আংশিক ফাইল মুছে যায়; ব্যর্থ হলে থাকে, যাতে Re-download সেখান থেকে চলে
            if (job.status == Status.DONE || job.status == Status.CANCELED) tmp.deleteRecursively()
        }
    }

    /** ৭ দিনের পুরনো অসমাপ্ত ফাইল পরিষ্কার */
    private fun cleanOldPartials() {
        try {
            val d = File(app.getExternalFilesDir(null) ?: app.filesDir, "dl")
            val limit = System.currentTimeMillis() - 7L * 24 * 3600 * 1000
            d.listFiles()?.forEach { if (it.lastModified() < limit) it.deleteRecursively() }
        } catch (e: Exception) {
        }
    }

    /** ফাইলটা ফোনের Downloads/MediaDownloader ফোল্ডারে সরায় */
    private fun publish(f: File): String {
        val ext = f.extension.lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        if (Build.VERSION.SDK_INT >= 29) {
            val resolver = app.contentResolver
            val cv = ContentValues()
            cv.put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
            cv.put(MediaStore.MediaColumns.MIME_TYPE, mime)
            cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MediaDownloader")
            cv.put(MediaStore.MediaColumns.IS_PENDING, 1)
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                ?: throw Exception(L.t("mkFail"))
            resolver.openOutputStream(uri)!!.use { out -> f.inputStream().use { it.copyTo(out) } }
            val done = ContentValues()
            done.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, done, null, null)
            // নামে মিল থাকলে সিস্টেম নাম বদলে দেয়; আসল নামটা নিয়ে নেওয়া
            var realName = f.name
            resolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) realName = c.getString(0) ?: f.name
            }
            return "Download/MediaDownloader/" + realName
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "MediaDownloader")
            dir.mkdirs()
            val dest = File(dir, f.name)
            f.copyTo(dest, overwrite = true)
            MediaScannerConnection.scanFile(app, arrayOf(dest.absolutePath), arrayOf(mime), null)
        }
        return "Download/MediaDownloader/" + f.name
    }
}
