package com.foridul.mediadl

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    companion object {
        private const val HOME = "file:///android_asset/index.html"
        private val MEDIA = Regex(
            ".*\\.(mp4|m4v|webm|mkv|mov|3gp|mp3|m4a|aac|ogg|opus|wav|flac)(\\?.*|#.*)?$",
            RegexOption.IGNORE_CASE
        )

        // archive.org আইটেম পেজ: /details/ID বা /embed/ID
        private val ARCHIVE = Regex(
            "^https?://([a-z0-9.-]+\\.)?archive\\.org/(details|embed)/([^/?#]+)",
            RegexOption.IGNORE_CASE
        )
        private val ARCHIVE_EXT = setOf(
            "mp4", "m4v", "webm", "mkv", "ogv", "mov", "avi", "mpg", "mpeg",
            "mp3", "m4a", "ogg", "opus", "flac", "wav", "aac"
        )

        // পেজে (iframe ও shadow DOM সহ) ভিডিও/অডিও চলছে কিনা জানায়
        private val WATCHER = """
(function(){
  if(window.__mdl)return; window.__mdl=1;
  var n=0, cache=[];
  function scan(root,out,depth,deep){
    try{
      root.querySelectorAll('video,audio').forEach(function(e){out.push(e)});
      if(deep){
        root.querySelectorAll('*').forEach(function(x){
          if(x.shadowRoot&&depth<4)scan(x.shadowRoot,out,depth+1,deep);
        });
      }
      if(depth<4){
        root.querySelectorAll('iframe,frame').forEach(function(f){
          try{if(f.contentDocument)scan(f.contentDocument,out,depth+1,deep);}catch(x){}
        });
      }
    }catch(x){}
  }
  function tick(){
    var list=[];
    var deep=(n++%4)===0;
    scan(document,list,0,deep);
    if(deep)cache=list.slice();
    else cache.forEach(function(e){if(list.indexOf(e)<0&&e.isConnected)list.push(e)});
    var best=null;
    list.forEach(function(e){
      if(!e.paused&&!e.ended&&e.readyState>=1){
        if(!best||(e.videoWidth||0)>(best.videoWidth||0))best=e;
      }
    });
    try{
      if(best)Android.media(true,best.currentSrc||best.src||'');
      else Android.media(false,'');
    }catch(x){}
  }
  setInterval(tick,700);
  ['play','playing','pause','ended','emptied'].forEach(function(ev){
    document.addEventListener(ev,function(){setTimeout(tick,50)},true);
  });
  tick();
})();
""".trimIndent()
    }

    private lateinit var web: WebView
    private lateinit var root: FrameLayout
    private lateinit var dlBtn: TextView
    private lateinit var homeBtn: TextView
    private lateinit var jobsBtn: TextView
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    @Volatile private var lastSniffed = ""
    @Volatile private var playingUrl = ""
    @Volatile private var playing = false
    @Volatile private var nativePlaying = false

    private val handler = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() {
            checkNative()
            updateButtons()
            handler.postDelayed(this, 1000)
        }
    }
    private val uiListener: () -> Unit = { updateButtons() }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        setContentView(root)

        web = WebView(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            setSupportMultipleWindows(false)
            builtInZoomControls = false
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }

        web.addJavascriptInterface(Bridge(), "Android")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? {
                val u = request.url.toString()
                if (MEDIA.matches(u)) lastSniffed = u
                return null
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                lastSniffed = ""
                playing = false
                nativePlaying = false
                playingUrl = ""
                updateButtons()
            }

            override fun onPageCommitVisible(view: WebView, url: String?) {
                inject(view, url)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                inject(view, url)
                updateButtons()
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (newProgress >= 20) inject(view, view.url)
            }

            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                if (customView != null) { cb.onCustomViewHidden(); return }
                customView = view
                customCb = cb
                root.addView(view, 1, FrameLayout.LayoutParams(-1, -1))
                web.visibility = View.GONE
                updateButtons()
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility =
                    View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            }

            override fun onHideCustomView() {
                val v = customView ?: return
                root.removeView(v)
                customView = null
                web.visibility = View.VISIBLE
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
                customCb?.onCustomViewHidden()
                updateButtons()
            }
        }

        // সাধারণ ফাইল-ডাউনলোড লিংকও একই পথে যাবে
        web.setDownloadListener { url, _, cd, mime, _ ->
            startDownload(url, URLUtil.guessFileName(url, cd, mime))
        }

        // ডান পাশের ডাউনলোড বাটন (সব সাইটে দেখায়; চাপলে পেজ বিশ্লেষণ হয়, চেপে ধরলে মেনু)
        dlBtn = circle("⬇", 0xFF455A64.toInt(), 56)
        root.addView(dlBtn, FrameLayout.LayoutParams(dp(56), dp(56)).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            rightMargin = dp(12)
        })
        dlBtn.visibility = View.GONE
        dlBtn.setOnClickListener { startAnalyze(null) }
        dlBtn.setOnLongClickListener { showMenu(); true }

        // হোমে ফেরার ছোট বাটন (সাইটে থাকলে দেখায়)
        homeBtn = circle("⌂", 0xCC16232A.toInt(), 40)
        root.addView(homeBtn, FrameLayout.LayoutParams(dp(40), dp(40)).apply {
            gravity = Gravity.START or Gravity.TOP
            leftMargin = dp(8)
            topMargin = dp(36)
        })
        homeBtn.visibility = View.GONE
        homeBtn.setOnClickListener { web.loadUrl(HOME) }

        // ডাউনলোড-তালিকা বাটন (কিছু ডাউনলোড থাকলে দেখায়)
        jobsBtn = circle("⇩", 0xCC16232A.toInt(), 40)
        root.addView(jobsBtn, FrameLayout.LayoutParams(dp(48), dp(40)).apply {
            gravity = Gravity.END or Gravity.TOP
            rightMargin = dp(8)
            topMargin = dp(36)
        })
        jobsBtn.visibility = View.GONE
        jobsBtn.setOnClickListener { showJobs() }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        if (Build.VERSION.SDK_INT <= 28 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 2)

        Engine.listeners.add(uiListener)
        web.loadUrl(HOME)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** অন্য অ্যাপ থেকে "Share → Media Downloader" করলে লিংক এখানে আসে */
    private fun handleIntent(i: Intent?) {
        if (i == null || i.action != Intent.ACTION_SEND) return
        val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
        val url = Regex("https?://\\S+").find(text)?.value ?: return
        web.post { startAnalyze(url) }
    }

    override fun onDestroy() {
        Engine.listeners.remove(uiListener)
        super.onDestroy()
    }

    private fun dp(v: Int) = Math.round(v * resources.displayMetrics.density)

    private fun circle(text: String, color: Int, size: Int): TextView =
        TextView(this).apply {
            this.text = text
            setTextColor(Color.WHITE)
            textSize = if (size > 50) 24f else 18f
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = if (size > 50 || text == "⌂") GradientDrawable.OVAL else GradientDrawable.RECTANGLE
                cornerRadius = dp(20).toFloat()
                setColor(color)
            }
            elevation = dp(6).toFloat()
        }

    private fun inject(view: WebView, url: String?) {
        if (url != null && url.startsWith("http")) view.evaluateJavascript(WATCHER, null)
    }

    // JS ওয়াচার যে ভিডিও ধরতে পারে না (cross-origin iframe), তার জন্য ফোনের অডিও-অবস্থা দেখে নেওয়া
    private fun checkNative() {
        val u = web.url
        val onSite = u != null && u.startsWith("http")
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val now = onSite && lastSniffed.isNotEmpty() && am.isMusicActive
        if (now != nativePlaying) nativePlaying = now
    }

    private fun updateButtons() = runOnUiThread {
        val u = web.url
        val onSite = u != null && u.startsWith("http")
        homeBtn.visibility = if (onSite && customView == null) View.VISIBLE else View.GONE
        dlBtn.visibility = if (onSite) View.VISIBLE else View.GONE

        // মিডিয়া চললে বা ধরা পড়লে বাটন উজ্জ্বল সবুজ, নইলে ধূসর
        val hot = playing || nativePlaying || lastSniffed.isNotEmpty()
        (dlBtn.background as GradientDrawable).setColor(if (hot) 0xFF0E7C66.toInt() else 0xFF455A64.toInt())

        val running = Engine.jobs.count {
            it.status == Engine.Status.RUNNING || it.status == Engine.Status.QUEUED
        }
        if (Engine.jobs.isEmpty() || customView != null) {
            jobsBtn.visibility = View.GONE
        } else {
            jobsBtn.visibility = View.VISIBLE
            jobsBtn.text = if (running > 0) "⇩$running" else "✓"
        }
    }

    // ---------------------------------------------------------------------
    //  পেজ বিশ্লেষণ → ফরম্যাট বাছাই → ডাউনলোড (yt-dlp ইঞ্জিন)
    // ---------------------------------------------------------------------

    private fun startAnalyze(target: String?) {
        val url = target ?: web.url ?: return
        if (!url.startsWith("http")) {
            Toast.makeText(this, "আগে একটা ওয়েবসাইট খুলুন বা লিংক দিন", Toast.LENGTH_SHORT).show()
            return
        }
        val cookies = CookieManager.getInstance().getCookie(url)
        val ua = web.settings.userAgentString

        if (Engine.isPlaylistUrl(url)) {
            showChoices(url, "প্লেলিস্ট / চ্যানেল", Engine.playlistChoices(), cookies, ua)
            return
        }

        var cancelled = false
        val dlg = AlertDialog.Builder(this)
            .setTitle("বিশ্লেষণ হচ্ছে…")
            .setMessage("পেজ থেকে ভিডিও/অডিও খোঁজা হচ্ছে। একটু অপেক্ষা করুন।")
            .setNegativeButton("বাতিল") { _, _ -> cancelled = true }
            .setOnCancelListener { cancelled = true }
            .create()
        dlg.show()

        Thread {
            var err: String? = null
            val res: Engine.Analysis? = try {
                Engine.analyze(url, cookies, ua)
            } catch (e: Exception) {
                err = Engine.shortError(e)
                null
            }
            runOnUiThread {
                if (cancelled || isFinishing) return@runOnUiThread
                dlg.dismiss()
                if (res != null) showChoices(url, res.title, res.choices, cookies, ua)
                else showAnalyzeError(url, err ?: "")
            }
        }.start()
    }

    private fun extraActions(url: String): ArrayList<Pair<String, () -> Unit>> {
        val list = ArrayList<Pair<String, () -> Unit>>()
        val id = archiveId()
        if (id != null) {
            list.add("📁 archive.org ফাইল-তালিকা থেকে বাছুন" to { archiveDownload(id) })
        }
        val direct = if (playingUrl.startsWith("http") && !playingUrl.lowercase().contains(".m3u8")) playingUrl else lastSniffed
        if (direct.isNotEmpty()) {
            list.add("🔗 পেজে ধরা-পড়া সরাসরি ফাইল নামান" to { startDownload(direct, null) })
        }
        return list
    }

    private fun showChoices(url: String, title: String, choices: List<Engine.Choice>, cookies: String?, ua: String?) {
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()
        for (c in choices) {
            labels.add(c.label)
            actions.add {
                Engine.enqueue(this, url, title, c, cookies, ua)
                Toast.makeText(this, "ডাউনলোড তালিকায় যোগ হয়েছে", Toast.LENGTH_SHORT).show()
            }
        }
        for (e in extraActions(url)) {
            labels.add(e.first)
            actions.add(e.second)
        }
        AlertDialog.Builder(this)
            .setTitle(title.take(70))
            .setItems(labels.toTypedArray()) { _, i -> actions[i]() }
            .setNegativeButton("বাতিল", null)
            .show()
    }

    private fun showAnalyzeError(url: String, err: String) {
        if (err.isNotEmpty()) Toast.makeText(this, err, Toast.LENGTH_LONG).show()
        val labels = ArrayList<String>()
        val actions = ArrayList<() -> Unit>()
        for (e in extraActions(url)) {
            labels.add(e.first)
            actions.add(e.second)
        }
        labels.add("🔄 ইঞ্জিন আপডেট করে আবার চেষ্টা")
        actions.add { updateEngine { startAnalyze(url) } }
        AlertDialog.Builder(this)
            .setTitle("এই পেজ থেকে মিডিয়া বের করা যায়নি")
            .setItems(labels.toTypedArray()) { _, i -> actions[i]() }
            .setNegativeButton("বন্ধ", null)
            .show()
    }

    private fun showMenu() {
        val items = arrayOf(
            "📋 ডাউনলোড তালিকা",
            "📎 ক্লিপবোর্ডের লিংক ডাউনলোড",
            "🔄 ইঞ্জিন (yt-dlp) আপডেট করুন"
        )
        AlertDialog.Builder(this)
            .setItems(items) { _, i ->
                when (i) {
                    0 -> showJobs()
                    1 -> {
                        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val t = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
                        val u = Regex("https?://\\S+").find(t)?.value
                        if (u == null) Toast.makeText(this, "ক্লিপবোর্ডে কোনো লিংক নেই", Toast.LENGTH_SHORT).show()
                        else startAnalyze(u)
                    }
                    2 -> updateEngine(null)
                    else -> {}
                }
            }
            .setNegativeButton("বন্ধ", null)
            .show()
    }

    private fun updateEngine(after: (() -> Unit)?) {
        Toast.makeText(this, "ইঞ্জিন আপডেট হচ্ছে…", Toast.LENGTH_SHORT).show()
        Thread {
            val msg = try {
                Engine.updateNow()
            } catch (e: Exception) {
                "আপডেট ব্যর্থ: " + Engine.shortError(e)
            }
            runOnUiThread {
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                after?.invoke()
            }
        }.start()
    }

    // ---------- ডাউনলোড-তালিকা ----------

    private fun statusText(j: Engine.Job): String = when (j.status) {
        Engine.Status.QUEUED -> " • অপেক্ষায়"
        Engine.Status.RUNNING -> " • " + j.progress.toInt().coerceIn(0, 100) + "%"
        Engine.Status.DONE -> " • সম্পন্ন"
        Engine.Status.FAILED -> " • ব্যর্থ"
        Engine.Status.CANCELED -> " • বাতিল"
    }

    private fun showJobs() {
        val list = Engine.jobs.toList()
        if (list.isEmpty()) {
            Toast.makeText(this, "কোনো ডাউনলোড নেই", Toast.LENGTH_SHORT).show()
            return
        }
        val labels = list.map { it.title.take(40) + statusText(it) }
        AlertDialog.Builder(this)
            .setTitle("ডাউনলোড তালিকা")
            .setItems(labels.toTypedArray()) { _, i -> showJob(list[i]) }
            .setPositiveButton("সম্পন্নগুলো মুছুন") { _, _ ->
                Engine.clearFinished()
                updateButtons()
            }
            .setNegativeButton("বন্ধ", null)
            .show()
    }

    private fun showJob(j: Engine.Job) {
        val detail = when (j.status) {
            Engine.Status.DONE -> "সেভ হয়েছে: " + (j.saved ?: "Download/MediaDownloader")
            Engine.Status.FAILED -> "কারণ: " + j.message
            Engine.Status.RUNNING -> "চলছে: " + j.progress.toInt().coerceIn(0, 100) + "%" +
                (if (j.eta > 0) " (বাকি ~" + j.eta + " সেকেন্ড)" else "")
            else -> statusText(j).removePrefix(" • ")
        }
        val b = AlertDialog.Builder(this)
            .setTitle(j.title.take(60))
            .setMessage(detail + "\n\n" + j.url.take(120))
            .setNeutralButton("ফিরে যান") { _, _ -> showJobs() }
            .setNegativeButton("বন্ধ", null)
        if (j.status == Engine.Status.RUNNING || j.status == Engine.Status.QUEUED) {
            b.setPositiveButton("বাতিল করুন") { _, _ -> Engine.cancel(j) }
        }
        b.show()
    }

    // ---------- archive.org: ফাইল-তালিকা থেকে বাছাই ----------

    private fun archiveId(): String? {
        val u = web.url ?: return null
        return ARCHIVE.find(u)?.groupValues?.get(3)
    }

    private fun archiveDownload(id: String) {
        Toast.makeText(this, "ফাইল-তালিকা আনা হচ্ছে…", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val c = URL("https://archive.org/metadata/" + Uri.encode(id)).openConnection() as HttpURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 20000
                c.setRequestProperty("User-Agent", web.settings.userAgentString)
                val body = c.inputStream.bufferedReader().use { it.readText() }
                val files = JSONObject(body).optJSONArray("files")
                val names = ArrayList<String>()
                val labels = ArrayList<String>()
                if (files != null) {
                    val items = ArrayList<Pair<String, Long>>()
                    for (i in 0 until files.length()) {
                        val f = files.getJSONObject(i)
                        val name = f.optString("name")
                        val ext = name.substringAfterLast('.', "").lowercase()
                        if (name.isEmpty() || ext !in ARCHIVE_EXT) continue
                        items.add(Pair(name, f.optString("size", "0").toLongOrNull() ?: 0L))
                    }
                    items.sortByDescending { it.second }
                    for (t in items.take(40)) {
                        names.add(t.first)
                        val size = if (t.second > 0) String.format(" • %.1f MB", t.second / 1048576.0) else ""
                        labels.add(t.first.substringAfterLast('/') + size)
                    }
                }
                runOnUiThread {
                    if (names.isEmpty()) {
                        Toast.makeText(this, "এই আইটেমে ডাউনলোডযোগ্য ভিডিও/অডিও ফাইল পাওয়া যায়নি (লগইন বা ধার-নেওয়া আইটেম হতে পারে)", Toast.LENGTH_LONG).show()
                    } else {
                        AlertDialog.Builder(this)
                            .setTitle("কোন ফাইল ডাউনলোড করবেন?")
                            .setItems(labels.toTypedArray()) { _, which ->
                                val n = names[which]
                                startDownload(
                                    "https://archive.org/download/" + Uri.encode(id) + "/" + Uri.encode(n, "/"),
                                    n.substringAfterLast('/')
                                )
                            }
                            .setNegativeButton("বাতিল", null)
                            .show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "তালিকা আনা যায়নি: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    // ---------- সরাসরি ফাইল-লিংক: সিস্টেম DownloadManager ----------

    private fun startDownload(url: String, name: String?) {
        try {
            val fileName = if (name.isNullOrEmpty()) URLUtil.guessFileName(url, null, null) else name
            val r = DownloadManager.Request(Uri.parse(url))
            CookieManager.getInstance().getCookie(url)?.let { r.addRequestHeader("Cookie", it) }
            r.addRequestHeader("User-Agent", web.settings.userAgentString)
            val ref = web.url
            if (ref != null && ref.startsWith("http")) r.addRequestHeader("Referer", ref)
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            r.setTitle(fileName)
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
            Toast.makeText(this, "ডাউনলোড শুরু হয়েছে: $fileName", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "ডাউনলোড ব্যর্থ: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private inner class Bridge {
        @JavascriptInterface
        fun openUrl(url: String) {
            runOnUiThread { web.loadUrl(url) }
        }

        // হোম পেজের "ডাউনলোড" ঘর: সরাসরি ফাইল হলে দ্রুত পথে, নইলে yt-dlp দিয়ে বিশ্লেষণ
        @JavascriptInterface
        fun download(url: String, name: String) {
            runOnUiThread {
                if (MEDIA.matches(url)) startDownload(url, name) else startAnalyze(url)
            }
        }

        @JavascriptInterface
        fun media(isPlaying: Boolean, url: String) {
            if (playing != isPlaying || url != playingUrl) {
                playing = isPlaying
                playingUrl = url
                updateButtons()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            customView != null -> web.webChromeClient?.onHideCustomView()
            web.canGoBack() -> web.goBack()
            else -> @Suppress("DEPRECATION") super.onBackPressed()
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(poll)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(poll)
        CookieManager.getInstance().flush()
    }
}
