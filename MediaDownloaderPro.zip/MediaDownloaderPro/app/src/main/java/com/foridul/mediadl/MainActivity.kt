package com.foridul.mediadl

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    companion object {
        private const val HOME = "file:///android_asset/index.html"
        private const val PANEL = "file:///android_asset/panel.html"
        private val MEDIA = Regex(
            ".*\\.(mp4|m4v|webm|mkv|mov|3gp|mp3|m4a|aac|ogg|opus|wav|flac)(\\?.*|#.*)?$",
            RegexOption.IGNORE_CASE
        )

        // archive.org আইটেম পেজ: /details/ID বা /embed/ID
        private val ARCHIVE = Regex(
            "^https?://([a-z0-9.-]+\\.)?archive\\.org/(details|embed)/([^/?#]+)",
            RegexOption.IGNORE_CASE
        )
        private val ARCHIVE_EXT = setOf(
            "mp4", "m4v", "webm", "mkv", "ogv", "mov", "avi", "mpg", "mpeg",
            "mp3", "m4a", "ogg", "opus", "flac", "wav", "aac"
        )

        // পেজে (iframe ও shadow DOM সহ) ভিডিও/অডিও চলছে কিনা জানায়
        private val WATCHER = """
(function(){
  if(window.__mdl)return; window.__mdl=1;
  var n=0, cache=[];
  function scan(root,out,depth,deep){
    try{
      root.querySelectorAll('video,audio').forEach(function(e){out.push(e)});
      if(deep){
        root.querySelectorAll('*').forEach(function(x){
          if(x.shadowRoot&&depth<4)scan(x.shadowRoot,out,depth+1,deep);
        });
      }
      if(depth<4){
        root.querySelectorAll('iframe,frame').forEach(function(f){
          try{if(f.contentDocument)scan(f.contentDocument,out,depth+1,deep);}catch(x){}
        });
      }
    }catch(x){}
  }
  function tick(){
    var list=[];
    var deep=(n++%4)===0;
    scan(document,list,0,deep);
    if(deep)cache=list.slice();
    else cache.forEach(function(e){if(list.indexOf(e)<0&&e.isConnected)list.push(e)});
    var best=null;
    list.forEach(function(e){
      if(!e.paused&&!e.ended&&e.readyState>=1){
        if(!best||(e.videoWidth||0)>(best.videoWidth||0))best=e;
      }
    });
    try{
      if(best)Android.media(true,best.currentSrc||best.src||'');
      else Android.media(false,'');
    }catch(x){}
  }
  setInterval(tick,700);
  ['play','playing','pause','ended','emptied'].forEach(function(ev){
    document.addEventListener(ev,function(){setTimeout(tick,50)},true);
  });
  tick();
})();
""".trimIndent()
    }


    private lateinit var web: WebView
    private lateinit var panel: WebView
    private lateinit var root: FrameLayout
    private lateinit var bar: LinearLayout
    private lateinit var dlBtn: ImageView
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    // নিচের বারের বাটনগুলো
    private class BarBtn(val box: LinearLayout, val icon: ImageView, val label: TextView)
    private val btns = LinkedHashMap<String, BarBtn>()

    // প্যানেল: null = বন্ধ, "dl" = ডাউনলোড, "files" = আমার ফাইল
    @Volatile private var panelMode: String? = null
    private var panelReady = false
    private var pendingShow: Pair<String, String>? = null

    @Volatile private var lastSniffed = ""
    @Volatile private var playingUrl = ""
    @Volatile private var playing = false
    @Volatile private var nativePlaying = false

    private class DmItem(val id: Long, val name: String, val url: String) {
        @Volatile var recorded = false
    }
    private var lastDoneSig = -1
    private val dmJobs = CopyOnWriteArrayList<DmItem>()
    private var lastJobsJson = ""

    // সর্বশেষ বিশ্লেষণের ফল (প্যানেলের তালিকার ক্রম ধরে বাছাই হয়)
    private class Cached(
        val url: String, val title: String, val cookies: String?, val ua: String?,
        val video: List<Engine.Choice>, val audio: List<Engine.Choice>, val playlist: List<Engine.Choice>
    )
    @Volatile private var cached: Cached? = null
    @Volatile private var analyzeToken = 0

    private val handler = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() {
            checkNative()
            updateButtons()
            pushJobs()
            handler.postDelayed(this, 1000)
        }
    }
    private val uiListener: () -> Unit = { updateButtons(); pushJobs() }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        L.init(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        setContentView(col)

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        col.addView(root, LinearLayout.LayoutParams(-1, 0, 1f))
        bar = buildBar()
        col.addView(bar)
        applyGap()

        web = WebView(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))

        panel = WebView(this)
        root.addView(panel, FrameLayout.LayoutParams(-1, -1))
        panel.visibility = View.GONE

        for (w in listOf(web, panel)) {
            w.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                setSupportMultipleWindows(false)
                builtInZoomControls = false
            }
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(web, true)
        }

        web.addJavascriptInterface(Bridge(), "Android")
        panel.addJavascriptInterface(Bridge(), "Android")

        panel.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                panelReady = true
                pendingShow?.let { showPanelNow(it.first, it.second) }
                pendingShow = null
            }
        }
        panel.loadUrl(PANEL)

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? {
                val u = request.url.toString()
                if (MEDIA.matches(u)) lastSniffed = u
                return null
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                lastSniffed = ""
                playing = false
                nativePlaying = false
                playingUrl = ""
                updateButtons()
            }

            override fun onPageCommitVisible(view: WebView, url: String?) {
                inject(view, url)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                inject(view, url)
                updateButtons()
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (newProgress >= 20) inject(view, view.url)
            }

            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                if (customView != null) { cb.onCustomViewHidden(); return }
                customView = view
                customCb = cb
                root.addView(view, root.indexOfChild(web) + 1, FrameLayout.LayoutParams(-1, -1))
                web.visibility = View.GONE
                bar.visibility = View.GONE
                updateButtons()
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility =
                    View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            }

            override fun onHideCustomView() {
                val v = customView ?: return
                root.removeView(v)
                customView = null
                web.visibility = View.VISIBLE
                bar.visibility = View.VISIBLE
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
                customCb?.onCustomViewHidden()
                updateButtons()
            }
        }

        // সাধারণ ফাইল-ডাউনলোড লিংকও একই পথে যাবে
        web.setDownloadListener { url, _, cd, mime, _ ->
            startDownload(url, URLUtil.guessFileName(url, cd, mime))
        }

        // ডান পাশের ডাউনলোড বাটন (৪০dp): শুধু সাইটে ভিডিও/অডিও চলার সময় দেখায়
        dlBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_arrow_down)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFFB76646.toInt())
            }
            elevation = dp(6).toFloat()
        }
        root.addView(dlBtn, FrameLayout.LayoutParams(dp(40), dp(40)).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            rightMargin = dp(12)
        })
        dlBtn.visibility = View.GONE
        dlBtn.setOnClickListener { startAnalyze(null) }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        if (Build.VERSION.SDK_INT <= 28 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 2)

        Engine.listeners.add(uiListener)
        web.loadUrl(HOME)
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** অন্য অ্যাপ থেকে "Share → Media Downloader" করলে লিংক এখানে আসে */
    private fun handleIntent(i: Intent?) {
        if (i == null || i.action != Intent.ACTION_SEND) return
        val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
        val url = Regex("https?://\\S+").find(text)?.value ?: return
        web.post { startAnalyze(url) }
    }

    override fun onDestroy() {
        Engine.listeners.remove(uiListener)
        super.onDestroy()
    }

    private fun dp(v: Int) = Math.round(v * resources.displayMetrics.density)

    private fun q(s: String) = JSONObject.quote(s)

    // ---------------------------------------------------------------------
    //  নিচের বার (সব সময় দেখা যায়)
    // ---------------------------------------------------------------------

    private fun isDark(): Boolean = when (L.theme()) {
        "dark" -> true
        "light" -> false
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    private fun buildBar(): LinearLayout {
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(if (isDark()) 0xFF0A1114.toInt() else 0xFF16232A.toInt())
        }
        val defs = listOf(
            "back" to R.drawable.ic_bar_back,
            "fwd" to R.drawable.ic_bar_fwd,
            "home" to R.drawable.ic_bar_home,
            "dl" to R.drawable.ic_bar_dl,
            "files" to R.drawable.ic_bar_files
        )
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        for ((key, res) in defs) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isClickable = true
                setBackgroundResource(tv.resourceId)
            }
            val icon = ImageView(this).apply {
                setImageResource(res)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            val label = TextView(this).apply {
                textSize = 11f
                maxLines = 1
                gravity = Gravity.CENTER
            }
            box.addView(icon, LinearLayout.LayoutParams(dp(24), dp(24)))
            label.visibility = View.GONE
            b.addView(box, LinearLayout.LayoutParams(0, -1, 1f))
            btns[key] = BarBtn(box, icon, label)
            box.setOnClickListener { onBar(key) }
        }
        relabelBar()
        return b
    }

    private fun applyGap() {
        val g = dp(L.gap())
        bar.layoutParams = LinearLayout.LayoutParams(-1, dp(40) + g)
        bar.setPadding(0, 0, 0, g)
    }

    private fun relabelBar() {
        for ((k, b) in btns) { b.label.text = L.t(k); b.box.contentDescription = L.t(k) }
    }

    private fun onBar(key: String) {
        when (key) {
            "back" -> if (panelMode != null) hidePanel() else if (web.canGoBack()) web.goBack()
            "fwd" -> if (panelMode == null && web.canGoForward()) web.goForward()
            "home" -> {
                hidePanel()
                if (web.url?.startsWith(HOME) != true) web.loadUrl(HOME)
            }
            "dl" -> if (panelMode == "dl") hidePanel() else {
                val u = web.url
                showPanel("dl", if (u != null && u.startsWith("http")) u else "")
            }
            "files" -> if (panelMode == "files") hidePanel() else showPanel("files", "")
        }
        updateButtons()
    }

    private fun updateBar() {
        val u = web.url
        val onHome = u != null && u.startsWith(HOME)
        val pm = panelMode
        fun paint(k: String, enabled: Boolean, active: Boolean) {
            val b = btns[k] ?: return
            val c = if (!enabled) 0x598FA09D else if (active) 0xFF5BE0C0.toInt() else 0xFF8FA09D.toInt()
            b.icon.setColorFilter(c)
            b.label.setTextColor(c)
            b.box.isEnabled = enabled
        }
        paint("back", pm != null || web.canGoBack(), false)
        paint("fwd", pm == null && web.canGoForward(), false)
        paint("home", true, pm == null && onHome)
        paint("dl", true, pm == "dl")
        paint("files", true, pm == "files")
    }

    // ---------------------------------------------------------------------
    //  প্যানেল (পুরো পেজ): ডাউনলোড ও আমার ফাইল
    // ---------------------------------------------------------------------

    private fun showPanel(mode: String, url: String) {
        if (!panelReady) { pendingShow = Pair(mode, url); panelMode = mode; panel.visibility = View.VISIBLE; updateButtons(); return }
        showPanelNow(mode, url)
    }

    private fun showPanelNow(mode: String, url: String) {
        panelMode = mode
        panel.visibility = View.VISIBLE
        lastJobsJson = ""
        panel.evaluateJavascript(
            "window.__show&&window.__show(" + q(mode) + "," + q(url) + "," + q(L.lang) + "," + q(L.theme()) + ")", null
        )
        pushJobs()
        if (mode == "files") pushFiles()
        updateButtons()
    }

    private fun hidePanel() {
        panelMode = null
        panel.visibility = View.GONE
        updateButtons()
    }

    private fun inject(view: WebView, url: String?) {
        if (url != null && url.startsWith("http")) view.evaluateJavascript(WATCHER, null)
    }

    // JS ওয়াচার যে ভিডিও ধরতে পারে না (cross-origin iframe), তার জন্য ফোনের অডিও-অবস্থা দেখে নেওয়া
    private fun checkNative() {
        val u = web.url
        val onSite = u != null && u.startsWith("http")
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val now = onSite && lastSniffed.isNotEmpty() && am.isMusicActive
        if (now != nativePlaying) nativePlaying = now
    }

    private fun updateButtons() = runOnUiThread {
        val u = web.url
        val onSite = u != null && u.startsWith("http")
        dlBtn.visibility =
            if (onSite && (playing || nativePlaying) && panelMode == null) View.VISIBLE else View.GONE
        updateBar()
    }

    // ---------------------------------------------------------------------
    //  পেজ বিশ্লেষণ → ফরম্যাট বাছাই (প্যানেলে) → ডাউনলোড (yt-dlp ইঞ্জিন)
    // ---------------------------------------------------------------------

    /** target == null হলে বর্তমান পেজ। প্যানেল খুলে সেখানেই বিশ্লেষণ চলে। */
    private fun startAnalyze(target: String?) {
        val url = target ?: web.url ?: ""
        if (!url.startsWith("http")) {
            Toast.makeText(this, L.t("openSite"), Toast.LENGTH_SHORT).show()
            return
        }
        showPanel("dl", url)
    }

    private fun arr(l: List<Engine.Choice>): JSONArray {
        val a = JSONArray()
        for ((i, c) in l.withIndex()) a.put(JSONObject().put("i", i).put("label", c.label).put("sub", c.sub))
        return a
    }

    private fun extrasFor(url: String): List<Pair<String, String>> {
        val list = ArrayList<Pair<String, String>>()
        if (archiveId() != null) list.add("archive" to L.t("exArchive"))
        val direct = if (playingUrl.startsWith("http") && !playingUrl.lowercase().contains(".m3u8")) playingUrl else lastSniffed
        if (direct.isNotEmpty()) list.add("direct" to L.t("exDirect"))
        if (MEDIA.matches(url)) list.add("self" to L.t("exSelf"))
        return list
    }

    private fun analysisJson(url: String, c: Cached?, err: String?): String {
        val o = JSONObject()
        o.put("url", url)
        o.put("title", c?.title ?: "")
        o.put("video", arr(c?.video ?: emptyList()))
        o.put("audio", arr(c?.audio ?: emptyList()))
        o.put("playlist", arr(c?.playlist ?: emptyList()))
        if (err != null) o.put("err", err)
        val ex = JSONArray()
        for (e in extrasFor(url)) ex.put(JSONObject().put("id", e.first).put("label", e.second))
        o.put("extras", ex)
        return o.toString()
    }

    private fun pushAnalysis(json: String) {
        runOnUiThread { panel.evaluateJavascript("window.__analysis&&window.__analysis(" + q(json) + ")", null) }
    }

    private fun analyzeForPanel(url: String) {
        val token = ++analyzeToken
        val cookies = CookieManager.getInstance().getCookie(url)
        val ua = web.settings.userAgentString
        if (Engine.isPlaylistUrl(url)) {
            val c = Cached(url, "", cookies, ua, emptyList(), emptyList(), Engine.playlistChoices())
            cached = c
            pushAnalysis(analysisJson(url, c, null))
            return
        }
        Thread {
            try {
                val a = Engine.analyze(url, cookies, ua)
                if (token != analyzeToken) return@Thread
                val c = Cached(url, a.title, cookies, ua, a.video, a.audio, emptyList())
                cached = c
                runOnUiThread { pushAnalysis(analysisJson(url, c, null)) }
            } catch (e: Exception) {
                if (token != analyzeToken) return@Thread
                cached = null
                val msg = Engine.shortError(e)
                runOnUiThread { pushAnalysis(analysisJson(url, null, msg)) }
            }
        }.start()
    }

    private fun pick(kind: String, idx: Int) {
        val c = cached ?: return
        val list = when (kind) {
            "video" -> c.video
            "audio" -> c.audio
            else -> c.playlist
        }
        val choice = list.getOrNull(idx) ?: return
        Engine.enqueue(this, c.url, c.title.ifEmpty { c.url }, choice, c.cookies, c.ua)
        Toast.makeText(this, L.t("added"), Toast.LENGTH_SHORT).show()
        lastJobsJson = ""
        pushJobs()
    }

    private fun pickExtra(id: String, url: String) {
        when (id) {
            "archive" -> archiveId()?.let { archiveDownload(it) }
            "direct" -> {
                val direct = if (playingUrl.startsWith("http") && !playingUrl.lowercase().contains(".m3u8")) playingUrl else lastSniffed
                if (direct.isNotEmpty()) startDownload(direct, null)
            }
            "self" -> startDownload(url, null)
        }
    }

    private fun updateEngine() {
        Toast.makeText(this, L.t("engUpdating"), Toast.LENGTH_SHORT).show()
        Thread {
            val msg = try {
                Engine.updateNow()
            } catch (e: Exception) {
                L.t("engUpdFail") + Engine.shortError(e)
            }
            runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
        }.start()
    }

    // ---------- ডাউনলোড প্যানেলে চলমান ডাউনলোড দেখানো ----------

    private fun jobsJson(): String {
        val arr = JSONArray()
        for (j in Engine.jobs) {
            val o = JSONObject()
            o.put("id", j.id)
            o.put("name", j.title)
            o.put("label", j.label)
            o.put("st", when (j.status) {
                Engine.Status.QUEUED -> "queue"
                Engine.Status.RUNNING -> "run"
                Engine.Status.DONE -> "done"
                Engine.Status.FAILED -> "fail"
                Engine.Status.CANCELED -> "cancel"
            })
            o.put("pct", if (j.status == Engine.Status.RUNNING && j.progress > 0f) j.progress.toInt().coerceIn(0, 100) else -1)
            o.put("eta", j.eta)
            o.put("rc", j.message == "reconnecting" && j.status == Engine.Status.RUNNING)
            o.put("msg", if (j.status == Engine.Status.FAILED) j.message.take(120) else "")
            arr.put(o)
        }
        val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        for (d in dmJobs) {
            val c = dm.query(DownloadManager.Query().setFilterById(d.id))
            c.use { cur ->
                if (!cur.moveToFirst()) {
                    dmJobs.remove(d) // বাতিল/মুছে গেছে
                    return@use
                }
                val status = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val so = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val total = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                if (status == DownloadManager.STATUS_SUCCESSFUL && !d.recorded) {
                    d.recorded = true
                    val lu = cur.getString(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI))
                    val real = lu?.let { Uri.parse(it).lastPathSegment } ?: d.name
                    History.add(History.FOLDER + real, d.url, "direct", d.name, null, so)
                }
                val o = JSONObject()
                o.put("id", "dm:" + d.id)
                o.put("name", d.name)
                o.put("label", "")
                o.put("st", when (status) {
                    DownloadManager.STATUS_RUNNING -> "run"
                    DownloadManager.STATUS_SUCCESSFUL -> "done"
                    DownloadManager.STATUS_FAILED -> "fail"
                    else -> "queue"
                })
                o.put("pct", if (total > 0) (so * 100 / total).toInt().coerceIn(0, 100) else -1)
                o.put("loaded", so)
                o.put("total", if (total > 0) total else 0)
                o.put("eta", 0)
                o.put("rc", false)
                o.put("msg", "")
                arr.put(o)
            }
        }
        return arr.toString()
    }

    /** প্যানেল খোলা থাকলে চলমান ডাউনলোডের তালিকা পাঠায় */
    private fun pushJobs() {
        if (panelMode == null || !panelReady) return
        val json = try { jobsJson() } catch (e: Exception) { return }
        val sig = Engine.jobs.count { it.status == Engine.Status.DONE } + dmJobs.count { it.recorded }
        if (sig != lastDoneSig) {
            lastDoneSig = sig
            if (panelMode == "files") pushFiles()
        }
        if (json == lastJobsJson) return
        lastJobsJson = json
        panel.evaluateJavascript(
            "window.__nativeJobs&&window.__nativeJobs(" + q(json) + ")", null
        )
    }

    // ---------- My Files: ডাউনলোড-ইতিহাস, ফাইল খোলা, আবার ডাউনলোড ----------

    private fun pushFiles() {
        if (panelMode == null || !panelReady) return
        val ctx = applicationContext
        Thread {
            val arr = JSONArray()
            for (o in History.all()) {
                val path = o.optString("path")
                var ex = History.locate(ctx, path) != null
                // নতুন ফাইল সিস্টেমের ইনডেক্সে আসতে কয়েক সেকেন্ড লাগতে পারে
                if (!ex && System.currentTimeMillis() - o.optLong("time") < 120000L) ex = true
                val x = JSONObject()
                x.put("id", o.optString("id"))
                x.put("name", o.optString("name"))
                x.put("path", path)
                x.put("size", o.optLong("size"))
                x.put("time", o.optLong("time"))
                x.put("ex", ex)
                arr.put(x)
            }
            val json = arr.toString()
            runOnUiThread {
                panel.evaluateJavascript(
                    "window.__nativeFiles&&window.__nativeFiles(" + q(json) + ")", null
                )
            }
        }.start()
    }

    private fun openHistoryFile(id: String) {
        val o = History.find(id) ?: return
        val uri = History.locate(this, o.optString("path"))
        if (uri == null) {
            Toast.makeText(this, L.t("missing"), Toast.LENGTH_SHORT).show()
            pushFiles()
            return
        }
        val ext = o.optString("name").substringAfterLast('.', "").lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            Toast.makeText(this, L.t("noApp"), Toast.LENGTH_LONG).show()
        }
    }

    private fun openDownloadFolder() {
        try {
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(
                Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADownload%2FMediaDownloader"),
                "vnd.android.document/directory"
            )
            startActivity(i)
        } catch (e: Exception) {
            try {
                startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
            } catch (e2: Exception) {
                Toast.makeText(this, L.t("folder"), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun redownloadItem(id: String) {
        val o = History.find(id) ?: return
        val url = o.optString("url")
        if (url.isEmpty()) return
        if (o.optString("kind") == "direct") {
            startDownload(url, o.optString("name"))
        } else {
            val ck = CookieManager.getInstance().getCookie(url)
            Engine.enqueue(
                this, url, o.optString("title", o.optString("name")),
                Engine.Choice("again", History.argsOf(o)), ck, web.settings.userAgentString
            )
            Toast.makeText(this, L.t("started"), Toast.LENGTH_SHORT).show()
        }
        lastJobsJson = ""
        pushJobs()
    }

    // ---------- archive.org: ফাইল-তালিকা থেকে বাছাই ----------

    private fun archiveId(): String? {
        val u = web.url ?: return null
        return ARCHIVE.find(u)?.groupValues?.get(3)
    }

    private fun archiveDownload(id: String) {
        Toast.makeText(this, L.t("listFetching"), Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val c = URL("https://archive.org/metadata/" + Uri.encode(id)).openConnection() as HttpURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 20000
                c.setRequestProperty("User-Agent", web.settings.userAgentString)
                val body = c.inputStream.bufferedReader().use { it.readText() }
                val files = JSONObject(body).optJSONArray("files")
                val names = ArrayList<String>()
                val labels = ArrayList<String>()
                if (files != null) {
                    val items = ArrayList<Pair<String, Long>>()
                    for (i in 0 until files.length()) {
                        val f = files.getJSONObject(i)
                        val name = f.optString("name")
                        val ext = name.substringAfterLast('.', "").lowercase()
                        if (name.isEmpty() || ext !in ARCHIVE_EXT) continue
                        items.add(Pair(name, f.optString("size", "0").toLongOrNull() ?: 0L))
                    }
                    items.sortByDescending { it.second }
                    for (t in items.take(40)) {
                        names.add(t.first)
                        val size = if (t.second > 0) String.format(" • %.1f MB", t.second / 1048576.0) else ""
                        labels.add(t.first.substringAfterLast('/') + size)
                    }
                }
                runOnUiThread {
                    if (names.isEmpty()) {
                        Toast.makeText(this, L.t("listNone"), Toast.LENGTH_LONG).show()
                    } else {
                        AlertDialog.Builder(this)
                            .setTitle(L.t("pickFile"))
                            .setItems(labels.toTypedArray()) { _, which ->
                                val n = names[which]
                                startDownload(
                                    "https://archive.org/download/" + Uri.encode(id) + "/" + Uri.encode(n, "/"),
                                    n.substringAfterLast('/')
                                )
                            }
                            .setNegativeButton(L.t("cancel"), null)
                            .show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, L.t("listFail") + e.message, Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    // ---------- সরাসরি ফাইল-লিংক: সিস্টেম DownloadManager ----------

    private fun startDownload(url: String, name: String?) {
        try {
            val fileName = if (name.isNullOrEmpty()) URLUtil.guessFileName(url, null, null) else name
            val r = DownloadManager.Request(Uri.parse(url))
            CookieManager.getInstance().getCookie(url)?.let { r.addRequestHeader("Cookie", it) }
            r.addRequestHeader("User-Agent", web.settings.userAgentString)
            val ref = web.url
            if (ref != null && ref.startsWith("http")) r.addRequestHeader("Referer", ref)
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            r.setTitle(fileName)
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "MediaDownloader/" + fileName)
            val dmId = (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
            dmJobs.add(DmItem(dmId, fileName, url))
            lastJobsJson = ""
            pushJobs()
            Toast.makeText(this, L.t("started") + fileName, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, L.t("failed") + e.message, Toast.LENGTH_LONG).show()
        }
    }

    private inner class Bridge {
        // ---- হোম পেজ (index.html) ----
        @JavascriptInterface
        fun openUrl(url: String) {
            runOnUiThread { hidePanel(); web.loadUrl(url) }
        }

        // হোম পেজের "ডাউনলোড" ঘর: সরাসরি ফাইল হলে দ্রুত পথে, নইলে বিশ্লেষণ প্যানেলে
        @JavascriptInterface
        fun download(url: String, name: String) {
            runOnUiThread {
                if (MEDIA.matches(url)) startDownload(url, name) else startAnalyze(url)
            }
        }

        // ---- ভাষা / থিম / বারের ফাঁকা জায়গা (দুই পেজই এগুলো ব্যবহার করে) ----
        @JavascriptInterface
        fun getLang(): String = L.lang

        @JavascriptInterface
        fun getTheme(): String = L.theme()

        @JavascriptInterface
        fun getGap(): Int = L.gap()

        @JavascriptInterface
        fun setLang(l: String) {
            L.saveLang(l)
            runOnUiThread {
                relabelBar()
                panel.evaluateJavascript("window.__lang&&window.__lang(" + q(L.lang) + ")", null)
            }
        }

        @JavascriptInterface
        fun setTheme(t: String) {
            L.setTheme(t)
            runOnUiThread { bar.setBackgroundColor(if (isDark()) 0xFF0A1114.toInt() else 0xFF16232A.toInt()) }
        }

        @JavascriptInterface
        fun setGap(g: Int) {
            L.setGap(g)
            runOnUiThread { applyGap() }
        }

        // ---- প্যানেল ----
        @JavascriptInterface
        fun panelClose() { runOnUiThread { hidePanel() } }

        @JavascriptInterface
        fun analyze(url: String) { runOnUiThread { analyzeForPanel(url) } }

        @JavascriptInterface
        fun pick(kind: String, idx: Int) { runOnUiThread { this@MainActivity.pick(kind, idx) } }

        @JavascriptInterface
        fun pickExtra(id: String, url: String) { runOnUiThread { this@MainActivity.pickExtra(id, url) } }

        @JavascriptInterface
        fun updateEngine() { runOnUiThread { this@MainActivity.updateEngine() } }

        @JavascriptInterface
        fun clipboardLink(): String {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
            val u = Regex("https?://\\S+").find(t)?.value
            if (u == null) runOnUiThread { Toast.makeText(this@MainActivity, L.t("clipEmpty"), Toast.LENGTH_SHORT).show() }
            return u ?: ""
        }

        @JavascriptInterface
        fun refreshFiles() { runOnUiThread { pushFiles() } }

        @JavascriptInterface
        fun openFile(id: String) { runOnUiThread { openHistoryFile(id) } }

        @JavascriptInterface
        fun openFolder() { runOnUiThread { openDownloadFolder() } }

        @JavascriptInterface
        fun redownload(id: String) { runOnUiThread { redownloadItem(id) } }

        @JavascriptInterface
        fun removeFile(id: String) {
            runOnUiThread {
                History.remove(id)
                pushFiles()
            }
        }

        @JavascriptInterface
        fun cancelJob(id: String) {
            runOnUiThread {
                if (id.startsWith("dm:")) {
                    val n = id.removePrefix("dm:").toLongOrNull()
                    if (n != null) {
                        (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(n)
                        dmJobs.removeAll { it.id == n }
                    }
                } else {
                    Engine.jobs.firstOrNull { it.id == id }?.let { Engine.cancel(it) }
                }
                lastJobsJson = ""
                pushJobs()
            }
        }

        /** Re-download: ব্যর্থ/বাতিল ডাউনলোড আবার শুরু; yt-dlp-এর আংশিক ফাইল থাকলে সেখান থেকেই চলে */
        @JavascriptInterface
        fun retryJob(id: String) {
            runOnUiThread {
                if (id.startsWith("dm:")) {
                    val n = id.removePrefix("dm:").toLongOrNull()
                    val d = dmJobs.firstOrNull { it.id == n }
                    if (d != null) {
                        (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(d.id)
                        dmJobs.remove(d)
                        startDownload(d.url, d.name)
                    }
                } else {
                    Engine.jobs.firstOrNull { it.id == id }?.let { Engine.retry(this@MainActivity, it) }
                }
                lastJobsJson = ""
                pushJobs()
            }
        }

        @JavascriptInterface
        fun clearJobs() {
            runOnUiThread {
                Engine.clearFinished()
                // শেষ হওয়া সিস্টেম-ডাউনলোড শুধু তালিকা থেকে সরে (ফাইল মোছে না)
                val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                for (d in dmJobs) {
                    dm.query(DownloadManager.Query().setFilterById(d.id)).use { c ->
                        if (!c.moveToFirst() ||
                            c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) != DownloadManager.STATUS_RUNNING &&
                            c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) != DownloadManager.STATUS_PENDING &&
                            c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) != DownloadManager.STATUS_PAUSED
                        ) dmJobs.remove(d)
                    }
                }
                lastJobsJson = ""
                pushJobs()
                updateButtons()
            }
        }

        @JavascriptInterface
        fun media(isPlaying: Boolean, url: String) {
            if (playing != isPlaying || url != playingUrl) {
                playing = isPlaying
                playingUrl = url
                updateButtons()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            customView != null -> web.webChromeClient?.onHideCustomView()
            panelMode != null -> hidePanel()
            web.canGoBack() -> web.goBack()
            else -> @Suppress("DEPRECATION") super.onBackPressed()
        }
    }

    override fun onResume() {
        super.onResume()
        handler.post(poll)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(poll)
        CookieManager.getInstance().flush()
    }
}
