package com.foridul.mediadl

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    companion object {
        private const val HOME = "file:///android_asset/index.html"
        private const val PANEL = "file:///android_asset/panel.html"
        private val MEDIA = Regex(
            ".*\\.(mp4|m4v|webm|mkv|mov|3gp|mp3|m4a|aac|ogg|opus|wav|flac|m3u8|mpd)(\\?.*|#.*)?$",
            RegexOption.IGNORE_CASE
        )
        private val STREAM = Regex(".*\\.(m3u8|mpd)(\\?.*|#.*)?$", RegexOption.IGNORE_CASE)

        // archive.org আইটেম পেজ: /details/ID বা /embed/ID
        private val ARCHIVE = Regex(
            "^https?://([a-z0-9.-]+\\.)?archive\\.org/(details|embed)/([^/?#]+)",
            RegexOption.IGNORE_CASE
        )
        private val ARCHIVE_EXT = setOf(
            "mp4", "m4v", "webm", "mkv", "ogv", "mov", "avi", "mpg", "mpeg",
            "mp3", "m4a", "ogg", "opus", "flac", "wav", "aac"
        )

        // পেজে (iframe ও shadow DOM সহ) ভিডিও/অডিও চলছে কিনা জানায়
        private val WATCHER = """
(function(){
  if(window.__mdl)return; window.__mdl=1;
  var n=0, cache=[];
  function scan(root,out,depth,deep){
    try{
      root.querySelectorAll('video,audio').forEach(function(e){out.push(e)});
      if(deep){
        root.querySelectorAll('*').forEach(function(x){
          if(x.shadowRoot&&depth<4)scan(x.shadowRoot,out,depth+1,deep);
        });
      }
      if(depth<4){
        root.querySelectorAll('iframe,frame').forEach(function(f){
          try{if(f.contentDocument)scan(f.contentDocument,out,depth+1,deep);}catch(x){}
        });
      }
    }catch(x){}
  }
  function tick(){
    var list=[];
    var deep=(n++%4)===0;
    scan(document,list,0,deep);
    if(deep)cache=list.slice();
    else cache.forEach(function(e){if(list.indexOf(e)<0&&e.isConnected)list.push(e)});
    var best=null;
    list.forEach(function(e){
      if(!e.paused&&!e.ended&&e.readyState>=1){
        if(!best||(e.videoWidth||0)>(best.videoWidth||0))best=e;
      }
    });
    try{
      if(best)Android.media(true,best.currentSrc||best.src||'');
      else Android.media(false,'');
    }catch(x){}
  }
  setInterval(tick,700);
  ['play','playing','pause','ended','emptied'].forEach(function(ev){
    document.addEventListener(ev,function(){setTimeout(tick,50)},true);
  });
  tick();
})();
""".trimIndent()
    }


    private lateinit var web: WebView
    private lateinit var panel: WebView
    private lateinit var root: FrameLayout
    private lateinit var bar: LinearLayout
    private lateinit var tabScroll: android.widget.HorizontalScrollView
    private lateinit var tabStrip: LinearLayout

    /** ট্যাব: kind = "web" (ওয়েবপেজ, নিজস্ব WebView) বা "dl" (ডাউনলোড তালিকা) */
    private class TabInfo(val kind: String, var wv: WebView?) { var icon: android.graphics.Bitmap? = null }
    private val tabs = ArrayList<TabInfo>()
    private var cur: TabInfo? = null
    private var lastWeb: TabInfo? = null
    private lateinit var dlBtn: ImageView
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    // নিচের বারের বাটনগুলো
    private class BarBtn(val box: LinearLayout, val icon: ImageView, val label: TextView)
    private val btns = LinkedHashMap<String, BarBtn>()

    // প্যানেল: null = বন্ধ, "dl" = ডাউনলোড, "files" = আমার ফাইল
    @Volatile private var panelMode: String? = null
    private var panelReady = false
    private var pendingShow: Pair<String, String>? = null

    @Volatile private var lastSniffed = ""
    /** পেজ লোডের সময় ধরা সব মিডিয়া লিংক (m3u8/mpd/mp4/mp3 ইত্যাদি), ক্রম বজায় রেখে অনন্য */
    private val sniffed = CopyOnWriteArrayList<String>()
    @Volatile private var playingUrl = ""
    @Volatile private var playing = false
    @Volatile private var nativePlaying = false
    /** বর্তমান পেজের host (UI থ্রেডে বসে; ব্যাকগ্রাউন্ড থ্রেডের ফিল্টার এটা পড়ে — view.url সেখানে ডাকা যায় না) */
    @Volatile private var pageHost: String? = null
    /** পেজ লোডের শুরুতেই অন্য অ্যাপে গান চলছিল: তখন isMusicActive দিয়ে এই পেজে ভিডিও চলছে ধরা হবে না */
    @Volatile private var foreignMusic = false

    private class DmItem(val id: Long, val name: String, val url: String) {
        @Volatile var recorded = false
    }
    private var lastDoneSig = -1
    private val dmJobs = CopyOnWriteArrayList<DmItem>()
    private var lastJobsJson = ""

    // সর্বশেষ বিশ্লেষণের ফল (প্যানেলের তালিকার ক্রম ধরে বাছাই হয়)
    private class Cached(
        val url: String, val title: String, val cookies: String?, val ua: String?,
        val video: List<Engine.Choice>, val audio: List<Engine.Choice>, val playlist: List<Engine.Choice>
    )
    @Volatile private var cached: Cached? = null
    @Volatile private var analyzeToken = 0

    private val handler = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() {
            checkNative()
            updateButtons()
            pushJobs()
            handler.postDelayed(this, 1000)
        }
    }
    private val uiListener: () -> Unit = { updateButtons(); pushJobs() }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        L.init(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        setContentView(col)

        tabStrip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        tabScroll = android.widget.HorizontalScrollView(this).apply {
            setBackgroundColor(0xFF0A1114.toInt())
            isHorizontalScrollBarEnabled = false
            addView(tabStrip)
        }
        col.addView(tabScroll, LinearLayout.LayoutParams(-1, dp(38)))

        root = FrameLayout(this).apply { setBackgroundColor(if (isDark()) 0xFF111A33.toInt() else 0xFFF4F5FA.toInt()) }
        col.addView(root, LinearLayout.LayoutParams(-1, 0, 1f))
        bar = buildBar()
        col.addView(bar)
        applyBarHeight()

        panel = WebView(this)
        panel.setBackgroundColor(if (isDark()) 0xFF0F1719.toInt() else 0xFFEEF2F1.toInt())
        root.addView(panel, FrameLayout.LayoutParams(-1, -1))
        panel.visibility = View.GONE

        for (w in listOf(panel)) {
            w.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                setSupportMultipleWindows(false)
                builtInZoomControls = false
            }
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(panel, true)
        }

        panel.addJavascriptInterface(Bridge(true), "Android")

        panel.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                panelReady = true
                pendingShow?.let { showPanelNow(it.first, it.second) }
                pendingShow = null
            }
        }
        panel.loadUrl(PANEL)

        // ডান পাশের ডাউনলোড বাটন (৪০dp): শুধু সাইটে ভিডিও/অডিও চলার সময় দেখায়
        dlBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_arrow_down)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFFB76646.toInt())
            }
            elevation = dp(6).toFloat()
        }
        root.addView(dlBtn, FrameLayout.LayoutParams(dp(40), dp(40)).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            rightMargin = dp(12)
        })
        dlBtn.visibility = View.GONE
        dlBtn.setOnClickListener { startAnalyze(null) }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        if (Build.VERSION.SDK_INT <= 28 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 2)

        Engine.listeners.add(uiListener)
        Filters.onChange = {
            runOnUiThread {
                if (::web.isInitialized) web.evaluateJavascript("window.__filtersDone&&window.__filtersDone()", null)
            }
        }
        Filters.init(this)
        newWebTab(HOME)
        handleIntent(intent)
        scheduleSpare(2500L)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** অন্য অ্যাপ থেকে "Share → Media Downloader" করলে লিংক এখানে আসে */
    private fun handleIntent(i: Intent?) {
        if (i == null || i.action != Intent.ACTION_SEND) return
        val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
        val url = Regex("https?://\\S+").find(text)?.value ?: return
        web.post { startAnalyze(url) }
    }

    override fun onDestroy() {
        Engine.listeners.remove(uiListener)
        Filters.onChange = null
        handler.removeCallbacksAndMessages(null)
        // WebView গুলো destroy না করলে মেমরি লিক হয়
        try {
            for (t in tabs) t.wv?.let { v -> (v.parent as? android.view.ViewGroup)?.removeView(v); v.stopLoading(); v.destroy() }
            tabs.clear()
            spareWv?.destroy(); spareWv = null
            (panel.parent as? android.view.ViewGroup)?.removeView(panel)
            panel.destroy()
        } catch (e: Exception) { }
        super.onDestroy()
    }

    /** সিস্টেম ডার্ক/লাইট বদলালে Activity নতুন হয় না (ট্যাব থাকে); শুধু রঙ বদলে নিই */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        bar.setBackgroundColor(if (isDark()) 0xFF0A1114.toInt() else 0xFF16232A.toInt())
        if (panelReady) panel.evaluateJavascript("window.__theme&&window.__theme(" + q(L.theme()) + ")", null)
    }

    private fun dp(v: Int) = Math.round(v * resources.displayMetrics.density)

    private fun q(s: String) = JSONObject.quote(s)

    // ---------------------------------------------------------------------
    //  নিচের বার (সব সময় দেখা যায়)
    // ---------------------------------------------------------------------

    private fun isDark(): Boolean = when (L.theme()) {
        "dark" -> true
        "light" -> false
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    /** এক ওয়েব ট্যাবের জন্য নতুন WebView (সেটিং, ক্লায়েন্ট, ডাউনলোড লিসেনার সহ) */
    private fun newWebView(): WebView {
        val v = WebView(this)
        // পেজ আঁকার আগে WebView-এর ডিফল্ট সাদা ব্যাকগ্রাউন্ড ঝলক দিত; থিম অনুযায়ী রঙ দিয়ে রাখি
        v.setBackgroundColor(if (isDark()) 0xFF111A33.toInt() else 0xFFF4F5FA.toInt())
        v.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            setSupportMultipleWindows(true)
            // এটা বন্ধ থাকলে WebView ইউজার-ট্যাপ ছাড়া খোলা পপ-আপ চুপচাপ ফেলে দেয় এবং onCreateWindow ডাকেই না,
            // ফলে ব্লক হলেও গণনা হতো না। চালু রাখলে সব পপ-আপের চেষ্টা আমাদের কাছে আসে, আমরা ব্লক করে গুনি
            javaScriptCanOpenWindowsAutomatically = true
            builtInZoomControls = false
        }
        // ওয়েবসাইট থেকে শুধু আমাদের নিজের হোম পেজ (file:///android_asset/index.html) Bridge-এর ফাংশন চালাতে পারবে;
        // অন্য যেকোনো সাইটের জন্য শুধু media() খোলা (ভিডিও চলছে কিনা জানাতে)
        val br = Bridge(false)
        v.addJavascriptInterface(br, "Android")
        CookieManager.getInstance().setAcceptThirdPartyCookies(v, true)
        v.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? {
                if (view !== web) return null
                // ফিল্টার লিস্টে থাকা বিজ্ঞাপন/ট্র্যাকার ডোমেইনের সাব-রিকোয়েস্ট খালি উত্তর দিয়ে বন্ধ
                // ফিল্টারের কোনো ত্রুটি যেন পুরো অ্যাপ বন্ধ না করে: ত্রুটি হলে অনুরোধ আটকানো হয় না
                val blockIt = try {
                    Filters.shouldBlock(request, pageHost)
                } catch (e: Throwable) { false }
                if (blockIt) return Filters.emptyResponse()
                val u = request.url.toString()
                if (MEDIA.matches(u)) {
                    lastSniffed = u
                    // একই লিংক বারবার না ঢোকানো; সর্বশেষগুলো উপরে রাখতে সরানো
                    sniffed.remove(u)
                    sniffed.add(0, u)
                    if (sniffed.size > 40) sniffed.removeAt(sniffed.lastIndex)
                }
                return null
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                br.onHome = url?.startsWith(HOME) == true
                if (view !== web) return
                pageHost = try { Uri.parse(url ?: "").host } catch (e: Exception) { null }
                foreignMusic = try { (getSystemService(Context.AUDIO_SERVICE) as AudioManager).isMusicActive } catch (e: Exception) { false }
                lastSniffed = ""
                sniffed.clear()
                playing = false
                nativePlaying = false
                playingUrl = ""
                updateButtons()
            }

            override fun onPageCommitVisible(view: WebView, url: String?) {
                br.onHome = url?.startsWith(HOME) == true
                if (view === web) dropPendingOld()
                inject(view, url)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                if (view === web) dropPendingOld()
                try {
                inject(view, url)
                recordVisit(url, view.title)
                if (pendingSettings && view === web && url?.startsWith(HOME) == true) {
                    pendingSettings = false
                    view.evaluateJavascript("window.__openSettings&&window.__openSettings()", null)
                }
                renderTabs()
                updateButtons()
                } catch (e: Throwable) { }
            }
        }

        v.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (newProgress >= 20) inject(view, view.url)
            }

            /**
             * পপ-আপ/নতুন ট্যাব: ব্লক চালু থাকলে বন্ধ (false), না থাকলে একই পেজে খোলে।
             * ব্লক বন্ধ থাকলে ছোট ডামি WebView দিয়ে URL টা মূল পেজেই লোড হয়।
             */
            override fun onCreateWindow(
                view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message
            ): Boolean {
                // ব্যবহারকারী নিজে ট্যাপ করা লিংক (isUserGesture) বন্ধ হয় না; বিজ্ঞাপনের পপ-আপ বন্ধ হয়
                if (L.popupBlock() && !isUserGesture) {
                    popBlockedCount++
                    val now = System.currentTimeMillis()
                    if (now - lastPopToast > 2500L) {
                        lastPopToast = now
                        val msg = L.t("popBlocked") + " (" + bnDigits(popBlockedCount) + ")"
                        Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
                    }
                    return false
                }
                val tmp = WebView(this@MainActivity)
                tmp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                        web.loadUrl(r.url.toString())
                        return true
                    }
                }
                (resultMsg.obj as WebView.WebViewTransport).webView = tmp
                resultMsg.sendToTarget()
                return true
            }

            override fun onReceivedIcon(view: WebView, icon: android.graphics.Bitmap?) {
                tabs.firstOrNull { it.wv === view }?.icon = icon
            }

            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                if (customView != null) { cb.onCustomViewHidden(); return }
                customView = view
                customCb = cb
                root.addView(view, root.indexOfChild(web) + 1, FrameLayout.LayoutParams(-1, -1))
                web.visibility = View.GONE
                bar.visibility = View.GONE
                tabScroll.visibility = View.GONE
                updateButtons()
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility =
                    View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            }

            override fun onHideCustomView() {
                val v = customView ?: return
                root.removeView(v)
                customView = null
                web.visibility = View.VISIBLE
                bar.visibility = View.VISIBLE
                tabScroll.visibility = View.VISIBLE
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
                customCb?.onCustomViewHidden()
                updateButtons()
            }
        }

        // লিংকে লং-প্রেস করলে ছোট মেনু (থিম অনুযায়ী রঙ)
        v.setOnTouchListener { _, e ->
            touchX = e.rawX.toInt()
            touchY = e.rawY.toInt()
            false
        }
        v.setOnLongClickListener { view ->
            val wv = view as WebView
            if (wv.url?.startsWith(HOME) == true) return@setOnLongClickListener false
            val hit = wv.hitTestResult
            val t = hit.type
            if (t != WebView.HitTestResult.SRC_ANCHOR_TYPE && t != WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE)
                return@setOnLongClickListener false
            val extra = hit.extra
            val h = Handler(Looper.getMainLooper()) { m ->
                val url = (if (t == WebView.HitTestResult.SRC_ANCHOR_TYPE) extra else null)
                    ?: m.data?.getString("url") ?: ""
                val text = (m.data?.getString("title") ?: "").trim()
                if (url.startsWith("http")) showLinkMenu(wv, url, text)
                true
            }
            wv.requestFocusNodeHref(h.obtainMessage())
            true
        }

        // সাধারণ ফাইল-ডাউনলোড লিংকও একই পথে যাবে
        v.setDownloadListener { url, _, cd, mime, _ ->
            val name = URLUtil.guessFileName(url, cd, mime)
            when {
                url.startsWith("blob:") || url.startsWith("data:") ->
                    Toast.makeText(this, L.t("failed") + "blob", Toast.LENGTH_SHORT).show()
                // ভিডিও/অডিও হলে yt-dlp ইঞ্জিনে; zip/apk/pdf ইত্যাদি সাধারণ ফাইল হলে সিস্টেম DownloadManager-এ
                mime?.startsWith("video/") == true || mime?.startsWith("audio/") == true || MEDIA.matches(url) ->
                    startDownload(url, name)
                else -> startDownloadDm(url, name)
            }
        }

        return v
    }

    private fun buildBar(): LinearLayout {
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(if (isDark()) 0xFF0A1114.toInt() else 0xFF16232A.toInt())
        }
        val defs = listOf(
            "back" to R.drawable.ic_bar_back,
            "fwd" to R.drawable.ic_bar_fwd,
            "home" to R.drawable.ic_bar_home,
            "dl" to R.drawable.ic_bar_dl,
            "menu" to R.drawable.ic_bar_menu
        )
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        for ((key, res) in defs) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isClickable = true
                setBackgroundResource(tv.resourceId)
            }
            val icon = ImageView(this).apply {
                setImageResource(res)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            val label = TextView(this).apply {
                textSize = 11f
                maxLines = 1
                gravity = Gravity.CENTER
            }
            box.addView(icon, LinearLayout.LayoutParams(dp(24), dp(24)))
            label.visibility = View.GONE
            b.addView(box, LinearLayout.LayoutParams(0, -1, 1f))
            btns[key] = BarBtn(box, icon, label)
            box.setOnClickListener { onBar(key) }
        }
        relabelBar()
        return b
    }

    /** নিচের বারের উচ্চতা স্থির (৪০ dp), কোনো ফাঁকা জায়গা নেই */
    private fun applyBarHeight() {
        bar.layoutParams = LinearLayout.LayoutParams(-1, dp(40))
    }

    private fun relabelBar() {
        for ((k, b) in btns) { b.label.text = L.t(k); b.box.contentDescription = L.t(k) }
    }

    private fun onBar(key: String) {
        if (key != "menu") ensureWebTab()
        when (key) {
            "back" -> if (panelMode != null) hidePanel() else if (web.canGoBack()) web.goBack()
            "fwd" -> if (panelMode == null && web.canGoForward()) web.goForward()
            "home" -> {
                hidePanel()
                if (web.url?.startsWith(HOME) != true) web.loadUrl(HOME)
            }
            "dl" -> if (panelMode == "dl") hidePanel() else {
                val u = web.url
                showPanel("dl", if (u != null && u.startsWith("http")) u else "")
            }
            "menu" -> showBarMenu()
        }
        updateButtons()
    }

    private fun updateBar() {
        val u = web.url
        val onHome = u != null && u.startsWith(HOME)
        val pm = panelMode
        fun paint(k: String, enabled: Boolean, active: Boolean) {
            val b = btns[k] ?: return
            val c = if (!enabled) 0x598FA09D else if (active) 0xFF5BE0C0.toInt() else 0xFF8FA09D.toInt()
            b.icon.setColorFilter(c)
            b.label.setTextColor(c)
            b.box.isEnabled = enabled
        }
        paint("back", pm != null || web.canGoBack(), false)
        paint("fwd", pm == null && web.canGoForward(), false)
        paint("home", true, pm == null && onHome)
        paint("dl", true, pm == "dl")
        paint("menu", true, false)
    }

    // ---------------------------------------------------------------------
    //  প্যানেল (পুরো পেজ): ডাউনলোড ও আমার ফাইল
    // ---------------------------------------------------------------------

    private fun showPanel(mode: String, url: String) {
        if (!panelReady) { pendingShow = Pair(mode, url); panelMode = mode; panel.visibility = View.VISIBLE; updateButtons(); return }
        showPanelNow(mode, url)
    }

    private fun showPanelNow(mode: String, url: String) {
        panelMode = mode
        lastJobsJson = ""
        // আগে প্যানেল দেখিয়ে পরে ভেতরের পেজ বদলানো হতো (পুরনো দৃশ্য ঝলকে উঠত); এখন ভেতরটা বদলে তারপর দেখাই
        panel.evaluateJavascript(
            "window.__show&&window.__show(" + q(mode) + "," + q(url) + "," + q(L.lang) + "," + q(L.theme()) + ")"
        ) { if (panelMode != null) panel.visibility = View.VISIBLE }
        pushJobs()
        if (mode == "files") pushFiles()
        if (mode == "hist") pushHist()
        updateButtons()
    }

    private fun hidePanel() {
        panelMode = null
        panel.visibility = View.GONE
        updateButtons()
    }

    private fun inject(view: WebView, url: String?) {
        if (url != null && url.startsWith("http")) {
            view.evaluateJavascript(WATCHER, null)
            if (url.contains("youtube.com")) view.evaluateJavascript(AD_SKIP, null)
        }
    }

    // ইউটিউব বিজ্ঞাপন: বিজ্ঞাপন চললে ভিডিওর শেষে সরিয়ে দেয় এবং Skip বাটন চাপে; মূল ভিডিও চলতে থাকে
    private val AD_SKIP = """
(function(){
  if(window.__mdlAd)return; window.__mdlAd=1;
  function tick(){
    try{
      var p=document.querySelector('.html5-video-player');
      var v=document.querySelector('video');
      if(p&&v&&p.classList.contains('ad-showing')&&isFinite(v.duration)&&v.duration>0){ v.currentTime=v.duration; }
      var sk=document.querySelector('.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button');
      if(sk) sk.click();
      var ov=document.querySelector('.ytp-ad-overlay-close-button');
      if(ov) ov.click();
    }catch(e){}
  }
  setInterval(tick,400);
})();
"""

    // JS ওয়াচার যে ভিডিও ধরতে পারে না (cross-origin iframe), তার জন্য ফোনের অডিও-অবস্থা দেখে নেওয়া
    private fun checkNative() {
        val u = web.url
        val onSite = u != null && u.startsWith("http")
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val music = am.isMusicActive
        if (!music) foreignMusic = false   // অন্য অ্যাপের গান থেমেছে; এরপর শুরু হওয়া শব্দ এই পেজের হতে পারে
        val now = onSite && lastSniffed.isNotEmpty() && music && !foreignMusic
        if (now != nativePlaying) nativePlaying = now
    }

    private fun updateButtons() = runOnUiThread {
        val u = web.url
        val onSite = u != null && u.startsWith("http")
        // ⬇ বাটন: শুধু যখন সাইটে ভিডিও/অডিও চলছে তখন দেখায়
        dlBtn.visibility =
            if (onSite && (playing || nativePlaying) && panelMode == null) View.VISIBLE else View.GONE
        // ডাউনলোড-পেজ ফুল স্ক্রিনে চলে, তাই তখন নিচের বার লুকানো থাকে
        bar.visibility = if (customView != null) View.GONE else View.VISIBLE
        updateBar()
    }

    // ---------------------------------------------------------------------
    //  পেজ বিশ্লেষণ → ফরম্যাট বাছাই (প্যানেলে) → ডাউনলোড (yt-dlp ইঞ্জিন)
    // ---------------------------------------------------------------------

    /** target == null হলে বর্তমান পেজ। প্যানেল খুলে সেখানেই বিশ্লেষণ চলে। */
    private fun startAnalyze(target: String?) {
        ensureWebTab()
        val url = target ?: web.url ?: ""
        if (!url.startsWith("http")) {
            Toast.makeText(this, L.t("openSite"), Toast.LENGTH_SHORT).show()
            return
        }
        showPanel("dl", url)
    }

    private fun arr(l: List<Engine.Choice>): JSONArray {
        val a = JSONArray()
        for ((i, c) in l.withIndex()) a.put(JSONObject().put("i", i).put("label", c.label).put("sub", c.sub))
        return a
    }

    private fun extrasFor(url: String): List<Pair<String, String>> {
        val list = ArrayList<Pair<String, String>>()
        if (archiveId() != null) list.add("archive" to L.t("exArchive"))
        val direct = if (playingUrl.startsWith("http") && !STREAM.matches(playingUrl)) playingUrl else lastSniffed
        if (direct.isNotEmpty()) list.add("direct" to L.t("exDirect"))
        if (MEDIA.matches(url) && !STREAM.matches(url)) list.add("self" to L.t("exSelf"))
        return list
    }

    private fun analysisJson(url: String, c: Cached?, err: String?): String {
        val o = JSONObject()
        o.put("url", url)
        o.put("title", c?.title ?: "")
        o.put("video", arr(c?.video ?: emptyList()))
        o.put("audio", arr(c?.audio ?: emptyList()))
        o.put("playlist", arr(c?.playlist ?: emptyList()))
        if (err != null) o.put("err", err)
        val ex = JSONArray()
        for (e in extrasFor(url)) ex.put(JSONObject().put("id", e.first).put("label", e.second))
        o.put("extras", ex)
        // পেজে ধরা মিডিয়া লিংকগুলো (জাপানি সাইটের HLS/DASH-এর জন্য জরুরি)
        // শুধু তখনই দেখাই যখন বিশ্লেষণ করা URL বর্তমান পেজের সাথে মিলে
        val page = web.url ?: ""
        val samePage = page.isNotEmpty() && (url == page || url.startsWith(page.substringBefore('?')) || page.startsWith(url.substringBefore('?')))
        val sn = JSONArray()
        if (samePage || url.isBlank()) {
            for (s in rankedSniffed()) {
                val kind = when {
                    STREAM.matches(s) -> "stream"
                    s.lowercase().contains(".mp3") || s.lowercase().contains(".m4a") ||
                        s.lowercase().contains(".aac") || s.lowercase().contains(".ogg") ||
                        s.lowercase().contains(".opus") || s.lowercase().contains(".wav") ||
                        s.lowercase().contains(".flac") -> "audio"
                    else -> "video"
                }
                val label = sniffLabel(s)
                sn.put(JSONObject().put("url", s).put("kind", kind).put("label", label))
            }
        }
        o.put("sniffed", sn)
        return o.toString()
    }

    /** স্নিফ করা লিংকের স্মার্ট স্কোর — master/index আগে, সেগমেন্ট পেছনে */
    private fun scoreSniffed(u: String): Int {
        val l = u.lowercase()
        var s = 0
        if (l.contains("master")) s += 120
        if (l.contains("index") && (l.contains(".m3u8") || l.contains(".mpd"))) s += 100
        if (l.contains("playlist") || l.contains("manifest") || l.contains("pl.m3u8")) s += 80
        if (l.contains("live") && STREAM.matches(u)) s += 30
        if (STREAM.matches(u)) s += 50
        // রেজোলিউশন ইঙ্গিত থাকলে বোনাস
        when {
            l.contains("1080") || l.contains("1920") -> s += 25
            l.contains("720") || l.contains("1280") -> s += 20
            l.contains("540") || l.contains("480") || l.contains("360") -> s += 10
        }
        // সেগমেন্ট / ফ্র্যাগমেন্ট বাদ
        if (l.contains("/segment") || l.contains("/frag") || l.contains("/chunk") ||
            l.contains(".ts") || l.contains("byterange") || l.contains("/media_")) s -= 80
        // খুব লম্বা টোকেন-হেভি URL একটু কমাও
        if (u.length > 220) s -= 15
        if (l.endsWith(".mpd")) s += 15
        return s
    }

    private fun rankedSniffed(): List<String> =
        sniffed.distinct().sortedByDescending { scoreSniffed(it) }

    private fun sniffLabel(u: String): String {
        val l = u.lowercase()
        return when {
            l.contains("master") -> "Master playlist"
            l.contains("index") && STREAM.matches(u) -> "Index playlist"
            l.contains("playlist") || l.contains("manifest") -> "Playlist"
            l.contains("1080") || l.contains("1920") -> "≈1080p"
            l.contains("720") || l.contains("1280") -> "≈720p"
            l.contains("540") -> "≈540p"
            l.contains("480") -> "≈480p"
            l.contains("360") -> "≈360p"
            STREAM.matches(u) -> "HLS/DASH stream"
            l.contains(".mp3") || l.contains(".m4a") || l.contains(".aac") -> "Audio file"
            else -> "Media file"
        }
    }

    private fun pushAnalysis(json: String) {
        runOnUiThread { panel.evaluateJavascript("window.__analysis&&window.__analysis(" + q(json) + ")", null) }
    }

    private fun analyzeForPanel(url: String) {
        val token = ++analyzeToken
        val cookies = CookieManager.getInstance().getCookie(url)
        val ua = web.settings.userAgentString
        val pageRef = web.url?.takeIf { it.startsWith("http") } ?: url
        if (Engine.isPlaylistUrl(url)) {
            val c = Cached(url, "", cookies, ua, emptyList(), emptyList(), Engine.playlistChoices())
            cached = c
            pushAnalysis(analysisJson(url, c, null))
            return
        }
        Thread {
            try {
                val a = Engine.analyze(url, cookies, ua, pageRef)
                if (token != analyzeToken) return@Thread
                val c = Cached(url, a.title, cookies, ua, a.video, a.audio, emptyList())
                cached = c
                runOnUiThread { pushAnalysis(analysisJson(url, c, null)) }
            } catch (e: Exception) {
                if (token != analyzeToken) return@Thread
                cached = null
                val msg = Engine.shortError(e)
                // yt-dlp ব্যর্থ হলেও স্নিফ করা লিংকগুলো প্যানেলে দেখানো হয় (ফলব্যাক)
                runOnUiThread { pushAnalysis(analysisJson(url, null, msg)) }
            }
        }.start()
    }

    private fun pick(kind: String, idx: Int) {
        val c = cached ?: return
        val list = when (kind) {
            "video" -> c.video
            "audio" -> c.audio
            else -> c.playlist
        }
        val choice = list.getOrNull(idx) ?: return
        val pageRef = web.url?.takeIf { it.startsWith("http") } ?: c.url
        Engine.enqueue(this, c.url, c.title.ifEmpty { c.url }, choice, c.cookies, c.ua, pageRef)
        // বাছাই করার সাথে সাথে সাদা ডাউনলোড-পেজ খোলে; ডাউনলোড সেখানেই চলে
        showPanel("files", "")
    }

    private fun pickExtra(id: String, url: String) {
        when (id) {
            "archive" -> archiveId()?.let { archiveDownload(it) }
            "direct" -> {
                val direct = if (playingUrl.startsWith("http") && !STREAM.matches(playingUrl)) playingUrl else lastSniffed
                if (direct.isNotEmpty()) pickSniffed(direct)
            }
            "self" -> startDownload(url, null)
        }
    }

    /** স্নিফ করা m3u8 থেকে বের করা কোয়ালিটি অপশন (url + লেবেল) */
    private class SniffVar(val url: String, val label: String, val sub: String = "")
    @Volatile private var sniffVars: List<SniffVar> = emptyList()
    @Volatile private var sniffVarsToken = 0
    @Volatile private var sniffVarsPage = ""

    /**
     * প্যানেলের "পেজে পাওয়া মিডিয়া" তালিকা থেকে বাছাই।
     * m3u8 হলে আগে মাস্টার পার্স করে কোয়ালিটি লিস্ট দেখায়; না থাকলে সরাসরি ডাউনলোড।
     */
    private fun pickSniffed(mediaUrl: String) {
        if (mediaUrl.isBlank()) return
        val page = web.url?.takeIf { it.startsWith("http") } ?: mediaUrl
        if (mediaUrl.lowercase().contains(".m3u8")) {
            probeM3u8(mediaUrl, page)
            return
        }
        if (STREAM.matches(mediaUrl)) {
            // mpd বা অন্য স্ট্রিম → আগে রেজোলিউশন তালিকা দেখাও, ব্যর্থ হলে তখনই সরাসরি বেস্ট
            analyzeStreamForPanel(mediaUrl, page)
            return
        }
        startDownload(mediaUrl, null)
    }

    private fun downloadStream(mediaUrl: String, page: String, label: String) {
        val cookies = CookieManager.getInstance().getCookie(page)
        val ua = web.settings.userAgentString
        val choice = Engine.Choice(
            label,
            listOf(
                Engine.Arg("-f", "bv*+ba/b"),
                Engine.Arg("--merge-output-format", "mp4")
            ),
            "video",
            "stream"
        )
        Engine.enqueue(this, mediaUrl, page, choice, cookies, ua, page)
        showPanel("files", "")
        Toast.makeText(this, L.t("added"), Toast.LENGTH_SHORT).show()
    }

    /** m3u8 ফেচ করে মাস্টার হলে কোয়ালিটি লিস্ট প্যানেলে পাঠায় */
    private fun probeM3u8(m3u8Url: String, page: String) {
        val token = ++sniffVarsToken
        sniffVarsPage = page
        // প্যানেলে লোডিং দেখানো
        val loading = JSONObject()
            .put("url", page)
            .put("probing", true)
            .put("probeUrl", m3u8Url)
            .toString()
        runOnUiThread {
            panel.evaluateJavascript("window.__sniffQualities&&window.__sniffQualities(" + q(loading) + ")", null)
        }
        Thread {
            try {
                val text = fetchText(m3u8Url, page)
                if (token != sniffVarsToken) return@Thread
                val vars = parseM3u8Master(text, m3u8Url)
                if (vars.isEmpty()) {
                    // মিডিয়া প্লেলিস্ট বা পার্স ব্যর্থ → yt-dlp দিয়ে রেজোলিউশন তালিকা দেখাও
                    runOnUiThread { analyzeStreamForPanel(m3u8Url, page) }
                    return@Thread
                }
                sniffVars = vars
                val arr = JSONArray()
                for ((i, v) in vars.withIndex()) {
                    arr.put(JSONObject().put("i", i).put("label", v.label).put("sub", v.sub).put("url", v.url))
                }
                val o = JSONObject()
                    .put("url", page)
                    .put("probeUrl", m3u8Url)
                    .put("qualities", arr)
                runOnUiThread {
                    panel.evaluateJavascript("window.__sniffQualities&&window.__sniffQualities(" + q(o.toString()) + ")", null)
                }
            } catch (e: Exception) {
                if (token != sniffVarsToken) return@Thread
                // ফেচ ব্যর্থ → yt-dlp দিয়ে রেজোলিউশন তালিকা দেখাও
                runOnUiThread { analyzeStreamForPanel(m3u8Url, page) }
            }
        }.start()
    }

    /** স্ট্রিম লিংক (mpd / মাস্টার ছাড়া m3u8) yt-dlp দিয়ে বিশ্লেষণ করে একই রেজোলিউশন তালিকা দেখায়; ব্যর্থ হলে সরাসরি বেস্ট নামায় */
    private fun analyzeStreamForPanel(mediaUrl: String, page: String) {
        val token = ++analyzeToken
        val loading = JSONObject()
            .put("url", page)
            .put("probing", true)
            .put("probeUrl", mediaUrl)
            .toString()
        runOnUiThread {
            panel.evaluateJavascript("window.__sniffQualities&&window.__sniffQualities(" + q(loading) + ")", null)
        }
        val cookies = CookieManager.getInstance().getCookie(page)
        val ua = web.settings.userAgentString
        Thread {
            try {
                val a = Engine.analyze(mediaUrl, cookies, ua, page)
                if (token != analyzeToken) return@Thread
                val c = Cached(mediaUrl, a.title, cookies, ua, a.video, a.audio, emptyList())
                cached = c
                runOnUiThread { pushAnalysis(analysisJson(page, c, null)) }
            } catch (e: Exception) {
                if (token != analyzeToken) return@Thread
                runOnUiThread { downloadStream(mediaUrl, page, sniffLabel(mediaUrl)) }
            }
        }.start()
    }

    private fun pickSniffQuality(idx: Int) {
        val v = sniffVars.getOrNull(idx) ?: return
        val page = sniffVarsPage.ifEmpty { web.url ?: v.url }
        downloadStream(v.url, page, v.label)
    }

    /** Referer/UA/Cookie সহ টেক্সট ফেচ */
    private fun fetchText(url: String, referer: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 12000
        c.readTimeout = 15000
        c.instanceFollowRedirects = true
        c.setRequestProperty("User-Agent", web.settings.userAgentString)
        if (referer.startsWith("http")) {
            c.setRequestProperty("Referer", referer)
            try {
                val u = Uri.parse(referer)
                if (!u.host.isNullOrEmpty()) c.setRequestProperty("Origin", "${u.scheme}://${u.host}")
            } catch (_: Exception) { }
        }
        CookieManager.getInstance().getCookie(referer)?.let { c.setRequestProperty("Cookie", it) }
        c.setRequestProperty("Accept", "*/*")
        val code = c.responseCode
        if (code !in 200..299) throw Exception("HTTP $code")
        return c.inputStream.bufferedReader().use { it.readText() }
    }

    /**
     * HLS মাস্টার প্লেলিস্ট পার্স। `#EXT-X-STREAM-INF` থেকে রেজোলিউশন/ব্যান্ডউইথ বের করে।
     * মিডিয়া প্লেলিস্ট হলে খালি লিস্ট (কলিং সাইড সরাসরি ডাউনলোড করবে)।
     */
    private fun parseM3u8Master(text: String, baseUrl: String): List<SniffVar> {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.none { it.startsWith("#EXT-X-STREAM-INF", ignoreCase = true) }) {
            // অডিও-only মাস্টার?
            if (lines.any { it.startsWith("#EXT-X-MEDIA", ignoreCase = true) && it.contains("TYPE=AUDIO", ignoreCase = true) }) {
                // সিম্পল: পুরো মাস্টারই একটা অপশন হিসেবে দাও
                return listOf(SniffVar(baseUrl, "Audio playlist", "master"))
            }
            return emptyList()
        }
        val out = ArrayList<SniffVar>()
        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            if (line.startsWith("#EXT-X-STREAM-INF", ignoreCase = true)) {
                val info = line.substringAfter(':')
                val bw = Regex("BANDWIDTH=(\\d+)", RegexOption.IGNORE_CASE).find(info)?.groupValues?.get(1)?.toLongOrNull()
                val res = Regex("RESOLUTION=(\\d+)x(\\d+)", RegexOption.IGNORE_CASE).find(info)
                val name = Regex("NAME=\"([^\"]+)\"", RegexOption.IGNORE_CASE).find(info)?.groupValues?.get(1)
                val codecs = Regex("CODECS=\"([^\"]+)\"", RegexOption.IGNORE_CASE).find(info)?.groupValues?.get(1) ?: ""
                val isAudioOnly = codecs.isNotEmpty() && !codecs.contains("avc", true) &&
                    !codecs.contains("hvc", true) && !codecs.contains("vp9", true) &&
                    !codecs.contains("av01", true) && codecs.contains("mp4a", true)
                i++
                while (i < lines.size && lines[i].startsWith("#")) i++
                if (i >= lines.size) break
                val raw = lines[i]
                if (raw.startsWith("#")) continue
                val abs = resolveUrl(baseUrl, raw)
                val height = res?.groupValues?.get(2)?.toIntOrNull()
                val label = when {
                    !name.isNullOrBlank() -> name
                    height != null -> "${height}p"
                    isAudioOnly -> "Audio only"
                    else -> "Stream"
                }
                val mbps = if (bw != null && bw > 0) String.format("%.1f Mbps", bw / 1_000_000.0) else ""
                val sub = listOfNotNull(
                    if (height != null && name != null) "${height}p" else null,
                    mbps.ifEmpty { null },
                    if (isAudioOnly) "audio" else null
                ).joinToString(" • ")
                out.add(SniffVar(abs, label, sub))
            }
            i++
        }
        // উচ্চ রেজোলিউশন আগে
        return out.sortedByDescending { v ->
            Regex("(\\d{3,4})p").find(v.label)?.groupValues?.get(1)?.toIntOrNull()
                ?: Regex("(\\d{3,4})p").find(v.sub)?.groupValues?.get(1)?.toIntOrNull()
                ?: 0
        }
    }

    private fun resolveUrl(base: String, ref: String): String {
        if (ref.startsWith("http://") || ref.startsWith("https://")) return ref
        return try {
            URL(URL(base), ref).toString()
        } catch (_: Exception) {
            ref
        }
    }

    private fun updateEngine() {
        Toast.makeText(this, L.t("engUpdating"), Toast.LENGTH_SHORT).show()
        Thread {
            val msg = try {
                Engine.updateNow()
            } catch (e: Exception) {
                L.t("engUpdFail") + Engine.shortError(e)
            }
            runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
        }.start()
    }

    // ---------- ডাউনলোড প্যানেলে চলমান ডাউনলোড দেখানো ----------

    private val dmSample = HashMap<Long, Pair<Long, Long>>()   // id -> (বাইট, সময়)
    private val dmSpeedMap = HashMap<Long, Long>()

    private fun dmSpeed(id: Long, bytes: Long): Long {
        val now = System.currentTimeMillis()
        val last = dmSample[id]
        if (last == null) { dmSample[id] = Pair(bytes, now); return 0L }
        val dt = now - last.second
        if (dt >= 700) {
            val v = ((bytes - last.first).coerceAtLeast(0L) * 1000L) / dt
            dmSpeedMap[id] = v
            dmSample[id] = Pair(bytes, now)
        }
        return dmSpeedMap[id] ?: 0L
    }

    private fun jobsJson(): String {
        val arr = JSONArray()
        for (j in Engine.jobs) {
            val o = JSONObject()
            o.put("id", j.id)
            o.put("name", j.title)
            o.put("label", j.label)
            o.put("st", when (j.status) {
                Engine.Status.QUEUED -> "queue"
                Engine.Status.RUNNING -> "run"
                Engine.Status.DONE -> "done"
                Engine.Status.FAILED -> "fail"
                Engine.Status.CANCELED -> "cancel"
            })
            o.put("paused", j.paused)
            o.put("pct", if ((j.status == Engine.Status.RUNNING || j.paused) && j.progress > 0f) j.progress.toInt().coerceIn(0, 100) else -1)
            o.put("eta", j.eta)
            o.put("speed", if (j.status == Engine.Status.RUNNING) j.speed else 0L)
            o.put("total", j.totalBytes)
            o.put("loaded", if (j.totalBytes > 0 && j.progress > 0f) (j.totalBytes * (j.progress / 100.0)).toLong() else 0L)
            o.put("rc", j.message == "reconnecting" && j.status == Engine.Status.RUNNING)
            o.put("msg", if (j.status == Engine.Status.FAILED) j.message.take(120) else "")
            arr.put(o)
        }
        val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        for (d in dmJobs) {
            val c = dm.query(DownloadManager.Query().setFilterById(d.id))
            c.use { cur ->
                if (!cur.moveToFirst()) {
                    dmJobs.remove(d) // বাতিল/মুছে গেছে
                    return@use
                }
                val status = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val so = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val total = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                if (status == DownloadManager.STATUS_SUCCESSFUL && !d.recorded) {
                    d.recorded = true
                    val lu = cur.getString(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI))
                    val real = lu?.let { Uri.parse(it).lastPathSegment } ?: d.name
                    History.add(History.FOLDER + real, d.url, "direct", d.name, null, so)
                }
                val o = JSONObject()
                o.put("id", "dm:" + d.id)
                o.put("name", d.name)
                o.put("label", "")
                o.put("st", when (status) {
                    DownloadManager.STATUS_RUNNING -> "run"
                    DownloadManager.STATUS_SUCCESSFUL -> "done"
                    DownloadManager.STATUS_FAILED -> "fail"
                    else -> "queue"
                })
                o.put("pct", if (total > 0) (so * 100 / total).toInt().coerceIn(0, 100) else -1)
                o.put("paused", false)
                o.put("loaded", so)
                o.put("total", if (total > 0) total else 0)
                o.put("speed", if (status == DownloadManager.STATUS_RUNNING) dmSpeed(d.id, so) else 0L)
                o.put("eta", 0)
                o.put("rc", false)
                o.put("msg", "")
                arr.put(o)
            }
        }
        return arr.toString()
    }

    /** প্যানেল খোলা থাকলে চলমান ডাউনলোডের তালিকা পাঠায় */
    private fun pushJobs() {
        if (panelMode == null || !panelReady) return
        val json = try { jobsJson() } catch (e: Exception) { return }
        val sig = Engine.jobs.count { it.status == Engine.Status.DONE } + dmJobs.count { it.recorded }
        if (sig != lastDoneSig) {
            lastDoneSig = sig
            if (panelMode == "files") pushFiles()
        }
        if (json == lastJobsJson) return
        lastJobsJson = json
        panel.evaluateJavascript(
            "window.__nativeJobs&&window.__nativeJobs(" + q(json) + ")", null
        )
    }

    // ---------- My Files: ডাউনলোড-ইতিহাস, ফাইল খোলা, আবার ডাউনলোড ----------

    private fun previewPartial(id: String) {
        val bn = L.lang != "en"
        val job = Engine.jobs.firstOrNull { it.id == id }
        val f = job?.let { Engine.partialFile(it) }
        if (f == null) {
            Toast.makeText(this, if (bn) "এখনো কিছু নামেনি" else "Nothing downloaded yet", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val real = f.name.removeSuffix(".part")
            val ext = real.substringAfterLast('.', "").lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "video/*"
            val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.files", f)
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri, mime)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, null))
        } catch (e: Exception) {
            Toast.makeText(this, if (bn) "প্লেয়ারে খোলা যায়নি" else "Could not open in a player", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- ট্যাব: প্রতিটি ওয়েব ট্যাবের নিজস্ব পেজ, ডাউনলোড ট্যাব আলাদা ----------

    /** সক্রিয় ওয়েব ট্যাবের WebView কে root-এ যোগ করে; আগেরটা সরায় */
    private fun attachWeb(v: WebView) {
        dropPendingOld()
        val old: WebView? = if (::web.isInitialized && web !== v) web else null
        old?.onPause()
        web = v
        pageHost = try { Uri.parse(v.url ?: "").host } catch (e: Exception) { null }
        // নতুন WebView পুরনোটার নিচে (index 0) বসে; পুরনোটা তখনই সরে যখন নতুন পেজের প্রথম ফ্রেম আঁকা হয়।
        // আগে সাথে সাথে সরানো হতো, ফলে নতুন ট্যাব খোলার সময় কয়েক ফ্রেম কালো/সাদা ঝলক দেখা যেত
        if (v.parent == null) root.addView(v, 0, FrameLayout.LayoutParams(-1, -1))
        v.onResume()
        if (old != null && old.parent === root) {
            if (v.url == null) {
                pendingOld = old
                handler.postDelayed({ if (pendingOld === old) dropPendingOld() }, 2000)
            } else root.removeView(old)
        }
    }

    private var pendingOld: WebView? = null
    private fun dropPendingOld() {
        pendingOld?.let { if (it.parent === root) root.removeView(it) }
        pendingOld = null
    }

    /**
     * WebView বানানো ভারী কাজ (UI থ্রেড কয়েক ফ্রেম আটকে যায়) — নতুন ট্যাব খোলার সময় সেটাই ঝাঁকুনির মতো লাগত।
     * তাই একটা WebView আগে থেকে বানিয়ে রাখি; ট্যাব খুললে সেটা নিই, আর পরের জন্য আবার অবসরে বানাই।
     */
    private var spareWv: WebView? = null
    private fun takeWebView(): WebView {
        val v = spareWv ?: newWebView()
        spareWv = null
        scheduleSpare(3000L)
        return v
    }
    /** নতুন ট্যাব খোলার সময়ই WebView বানালে ফ্রেম আটকে ঝাঁকুনি লাগে; পেজ লোড শেষ হওয়ার পর ফাঁকা সময়ে বানাই */
    private fun scheduleSpare(delayMs: Long, tries: Int = 0) {
        handler.postDelayed({
            if (isFinishing || spareWv != null) return@postDelayed
            val busy = ::web.isInitialized && web.progress < 100
            if (busy && tries < 4) { scheduleSpare(1500L, tries + 1); return@postDelayed }
            android.os.Looper.myQueue().addIdleHandler { ensureSpare(); false }
        }, delayMs)
    }
    private fun ensureSpare() {
        if (spareWv == null && !isFinishing) spareWv = try { newWebView() } catch (e: Exception) { null }
    }

    private fun newWebTab(url: String) {
        val t = TabInfo("web", takeWebView())
        tabs.add(t)
        lastWeb = t
        selectTab(t)
        t.wv?.loadUrl(url)
    }

    private fun openDownloadTab() {
        val d = tabs.firstOrNull { it.kind == "dl" } ?: TabInfo("dl", null).also { tabs.add(it) }
        selectTab(d)
    }

    /** ডাউনলোড ট্যাবে থাকলে শেষ ওয়েব ট্যাবে ফেরে (বা নতুন বানায়) */
    private fun ensureWebTab() {
        if (cur?.kind != "dl") return
        val w = lastWeb?.takeIf { tabs.contains(it) } ?: tabs.lastOrNull { it.kind == "web" }
        if (w != null) selectTab(w) else newWebTab(HOME)
    }

    private fun selectTab(t: TabInfo) {
        if (!tabs.contains(t)) return
        cur = t
        if (t.kind == "web") {
            t.wv?.let { attachWeb(it) }
            lastWeb = t
            hidePanel()
        } else {
            showPanel("files", "")
        }
        renderTabs()
        updateButtons()
    }

    private fun closeTab(t: TabInfo) {
        if (!tabs.contains(t)) return
        val idx = tabs.indexOf(t)
        val wasWeb = t.kind == "web" && t.wv != null
        val wasAttached = wasWeb && ::web.isInitialized && t.wv === web
        tabs.remove(t)
        if (lastWeb === t) lastWeb = null
        // বন্ধ হওয়া WebView আর ব্যবহার হবে না: আগে অন্য ওয়েব ট্যাবে (বা নতুন ট্যাবে) সরিয়ে নিই
        if (tabs.none { it.kind == "web" }) {
            val nt = TabInfo("web", takeWebView())
            tabs.add(nt)
            lastWeb = nt
            attachWeb(nt.wv!!)
            nt.wv!!.loadUrl(HOME)
        } else if (wasAttached) {
            val fb = tabs.last { it.kind == "web" }
            lastWeb = fb
            attachWeb(fb.wv!!)
        }
        if (wasWeb) t.wv?.let { v ->
            if (v.parent === root) root.removeView(v)
            v.stopLoading()
            v.destroy()
        }
        if (cur === t) selectTab(tabs[idx.coerceAtMost(tabs.lastIndex)]) else renderTabs()
    }

    /** হোম পেজের ট্যাবের নাম সবসময় "নতুন ট্যাব" (পেজের <title> "MediaDL Pro" লোডের পর এসে ট্যাবের মাপ বদলে ঝাঁকুনি দিত) */
    private fun tabTitle(t: TabInfo): String {
        if (t.kind == "dl") return L.t("downloading")
        val u = t.wv?.url
        if (u == null || u.startsWith(HOME)) return L.t("newTab")
        return t.wv?.title?.takeIf { it.isNotBlank() } ?: L.t("newTab")
    }

    private var lastTabSig = ""

    private fun renderTabs() {
        if (!::tabStrip.isInitialized) return
        // কিছু বদলায়নি হলে স্ট্রিপ নতুন করে বানাই না (প্রতিটি পেজ লোডে বানালে চিপগুলো কেঁপে ওঠে)
        val sig = tabs.joinToString("|") { System.identityHashCode(it).toString() + (if (it === cur) "*" else "") + tabTitle(it) }
        if (sig == lastTabSig && tabStrip.childCount > 0) return
        lastTabSig = sig
        tabStrip.removeAllViews()
        for (t in tabs) {
            val active = t === cur
            val title = tabTitle(t)
            val fg = if (active) 0xFF06211B.toInt() else 0xFFE6EEEC.toInt()
            val chip = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), 0, dp(2), 0)
                setBackgroundColor(if (active) 0xFF2BB89A.toInt() else 0xFF1F2D31.toInt())
                setOnClickListener { selectTab(t) }
            }
            chip.addView(TextView(this).apply {
                text = if (title.length > 16) title.take(16) + "…" else title
                textSize = 13f
                setTextColor(fg)
            })
            chip.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_tab_close)
                setColorFilter(fg)
                scaleType = ImageView.ScaleType.FIT_CENTER
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (active) 0x33000000 else 0x33FFFFFF)
                }
                setPadding(dp(4), dp(4), dp(4), dp(4))
                contentDescription = L.t("cancel")
                setOnClickListener { closeTab(t) }
            }, LinearLayout.LayoutParams(dp(22), dp(22)).apply { leftMargin = dp(6); rightMargin = dp(4) })
            tabStrip.addView(chip, LinearLayout.LayoutParams(-2, -1).apply { rightMargin = dp(4) })
        }
        tabStrip.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_tab_add)
            setColorFilter(0xFFE6EEEC.toInt())
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x22FFFFFF)
            }
            setPadding(dp(5), dp(5), dp(5), dp(5))
            contentDescription = L.t("newTab")
            setOnClickListener { newWebTab(HOME) }
        }, LinearLayout.LayoutParams(dp(26), dp(26)).apply { gravity = Gravity.CENTER_VERTICAL; leftMargin = dp(8); rightMargin = dp(8) })
    }

    // ---------- ড্রপডাউন মেনু (⋮ তিন-লাইন): ডাউনলোড হচ্ছে / ইতিহাস / নতুন ট্যাব ----------

    private var barMenu: android.widget.PopupWindow? = null
    private var pendingSettings = false
    /** এই সেশনে কতগুলো পপ-আপ ব্লক হয়েছে */
    private var popBlockedCount = 0
    private var lastPopToast = 0L

    private fun bnDigits(n: Int): String =
        if (L.lang == "en") n.toString() else n.toString().map { "০১২৩৪৫৬৭৮৯"[it - '0'] }.joinToString("")

    private fun popSub(): String {
        val n = popBlockedCount
        if (!L.popupBlock()) return L.t("popOffSub")
        return bnDigits(n)
    }

    // ---------- লিংকে লং-প্রেস মেনু ----------

    private var linkMenu: android.widget.PopupWindow? = null
    private var touchX = 0
    private var touchY = 0

    private fun showLinkMenu(wv: WebView, url: String, text: String) {
        linkMenu?.dismiss()
        val dark = isDark()
        val bgc = if (dark) 0xFF232629.toInt() else 0xFFF5F6F8.toInt()
        val ink = if (dark) 0xFFE8EAED.toInt() else 0xFF1C2326.toInt()
        val dim = if (dark) 0xFF9AA0A6.toInt() else 0xFF5F6368.toInt()
        val lineC = if (dark) 0x33FFFFFF else 0x1F000000
        val w = dp(260)
        val ripple = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, ripple, true)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(18).toFloat()
                setColor(bgc)
            }
            setPadding(0, dp(10), 0, dp(6))
        }

        // উপরে: "Share Link", নিচে লিংক, ডানে ⋯ বোতাম (শেয়ার শিট খোলে)
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(4), dp(12), dp(10))
        }
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ht.addView(TextView(this).apply {
            this.text = L.t("shareLink")
            textSize = 16f
            setTextColor(ink)
        })
        ht.addView(TextView(this).apply {
            this.text = url
            textSize = 11f
            setTextColor(dim)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, dp(2), 0, 0)
        })
        head.addView(ht, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) })
        head.addView(TextView(this).apply {
            this.text = "•••"
            textSize = 11f
            setTextColor(ink)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(lineC) }
            isClickable = true
            setOnClickListener {
                linkMenu?.dismiss()
                try {
                    val i = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, url)
                    }
                    startActivity(Intent.createChooser(i, L.t("shareLink")))
                } catch (_: Exception) { }
            }
        }, LinearLayout.LayoutParams(dp(40), dp(40)))
        col.addView(head)
        col.addView(View(this).apply { setBackgroundColor(lineC) }, LinearLayout.LayoutParams(-1, dp(1)))

        fun item(label: String, act: () -> Unit) {
            col.addView(TextView(this).apply {
                this.text = label
                textSize = 15f
                setTextColor(ink)
                setPadding(dp(18), dp(13), dp(18), dp(13))
                isClickable = true
                setBackgroundResource(ripple.resourceId)
                setOnClickListener { linkMenu?.dismiss(); act() }
            }, LinearLayout.LayoutParams(-1, -2))
        }

        val host = try { Uri.parse(url).host } catch (e: Exception) { null }
        item(L.t("openNew")) { newWebTab(url) }
        item(L.t("copyLink")) { copyToClipboard(url) }
        item(L.t("savePage")) {
            val base = (host ?: "page").replace(Regex("[^A-Za-z0-9._-]"), "_")
            Toast.makeText(this, L.t("pageSaving"), Toast.LENGTH_SHORT).show()
            startDownloadDm(url, base + "_" + (System.currentTimeMillis() % 100000) + ".html")
        }
        item(L.t("copyText")) {
            if (text.isEmpty()) Toast.makeText(this, L.t("noText"), Toast.LENGTH_SHORT).show()
            else copyToClipboard(text)
        }
        item(L.t("saveLink")) { startDownload(url, null) }
        item(L.t("blockAd")) {
            val added = Filters.blockHost(host, pageHost)
            // এই লিংকটি পেজ থেকে এখনই লুকিয়ে দিই
            wv.evaluateJavascript(
                "(function(u){document.querySelectorAll('a').forEach(function(a){if(a.href===u){a.style.setProperty('display','none','important')}})})(" + q(url) + ")",
                null
            )
            Toast.makeText(this, L.t(if (added) "adBlocked" else "adHidden"), Toast.LENGTH_SHORT).show()
        }

        val pw = android.widget.PopupWindow(col, w, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, true)
        pw.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        pw.isOutsideTouchable = true
        pw.elevation = dp(8).toFloat()
        linkMenu = pw
        col.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.UNSPECIFIED
        )
        val dm = resources.displayMetrics
        val margin = dp(8)
        val x = (touchX - w / 2).coerceIn(margin, (dm.widthPixels - w - margin).coerceAtLeast(margin))
        val maxY = dm.heightPixels - col.measuredHeight - dp(24)
        val y = touchY.coerceAtMost(maxY).coerceAtLeast(dp(24))
        pw.showAtLocation(root, Gravity.NO_GRAVITY, x, y)
    }

    private fun copyToClipboard(s: String) {
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("text", s))
            Toast.makeText(this, L.t("copied"), Toast.LENGTH_SHORT).show()
        } catch (_: Exception) { }
    }

    /** ড্রপডাউন: উপরে রিলোড, পপ-আপ ব্লক, সেটিংস (ডানে); নিচে ইতিহাস, ডাউনলোড, নতুন ট্যাব */
    private fun showBarMenu() {
        barMenu?.dismiss()
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(22).toFloat()
            setColor(if (isDark()) 0xFF232629.toInt() else 0xFFF5F6F8.toInt())
        }
        val ink = if (isDark()) 0xFFE8EAED.toInt() else 0xFF1C2326.toInt()
        val accent = 0xFF5BE0C0.toInt()
        val dim = if (isDark()) 0xFF9AA0A6.toInt() else 0xFF5F6368.toInt()
        val ripple = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, ripple, true)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            setPadding(dp(8), dp(12), dp(8), dp(14))
        }
        fun cell(icon: Int, label: String, tint: Int, sub: String? = null, badge: String? = null, act: () -> Unit): LinearLayout {
            val c = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(0, dp(12), 0, dp(12))
                isClickable = true
                setBackgroundResource(ripple.resourceId)
                setOnClickListener { barMenu?.dismiss(); act() }
            }
            val iconView: View = if (badge == null) {
                ImageView(this).apply { setImageResource(icon); setColorFilter(tint) }
            } else {
                FrameLayout(this).apply {
                    addView(ImageView(this@MainActivity).apply {
                        setImageResource(R.drawable.ic_m_newtab_box)
                        setColorFilter(tint)
                    }, FrameLayout.LayoutParams(-1, -1))
                    addView(TextView(this@MainActivity).apply {
                        text = badge
                        textSize = 11f
                        setTextColor(tint)
                        gravity = Gravity.CENTER
                    }, FrameLayout.LayoutParams(-1, -1))
                }
            }
            c.addView(iconView, LinearLayout.LayoutParams(dp(26), dp(26)))
            c.addView(TextView(this).apply {
                text = label
                textSize = 12f
                setTextColor(tint)
                gravity = Gravity.CENTER
                maxLines = 1
                setPadding(0, dp(6), 0, 0)
            })
            if (sub != null) c.addView(TextView(this).apply {
                text = sub
                textSize = 10f
                setTextColor(dim)
                gravity = Gravity.CENTER
                maxLines = 1
                setPadding(0, dp(2), 0, 0)
            })
            return c
        }
        fun row(vararg cells: LinearLayout): LinearLayout =
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                cells.forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
            }

        val popOn = L.popupBlock()
        col.addView(row(
            cell(R.drawable.ic_m_reload, L.t("reload"), ink) {
                ensureWebTab()
                if (web.url?.startsWith("http") == true) web.reload()
            },
            cell(R.drawable.ic_m_shield, L.t("popBlock"), if (popOn) accent else dim, popSub()) {
                L.setPopupBlock(!L.popupBlock())
                Toast.makeText(this, L.t(if (L.popupBlock()) "popOn" else "popOff"), Toast.LENGTH_SHORT).show()
            },
            cell(R.drawable.ic_m_settings, L.t("settings"), ink) { openSettings() }
        ))
        col.addView(View(this).apply { setBackgroundColor(if (isDark()) 0x88FFFFFF.toInt() else 0x66000000.toInt()) },
            LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(6); bottomMargin = dp(6) })
        col.addView(row(
            cell(R.drawable.ic_m_history, L.t("history"), ink) { ensureWebTab(); showPanel("hist", "") },
            cell(R.drawable.ic_m_download, L.t("downloading"), ink) { openDownloadTab() },
            cell(R.drawable.ic_m_newtab, L.t("newTab"), ink, badge = bnDigits(tabs.size)) { showTabSheet() }
        ))

        val pw = android.widget.PopupWindow(col, dp(300), android.view.ViewGroup.LayoutParams.WRAP_CONTENT, true)
        pw.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        pw.isOutsideTouchable = true
        pw.elevation = dp(8).toFloat()
        barMenu = pw
        // ড্রপডাউন ঠিক নেভিগেশন বারের উপরের কিনারা থেকে শুরু হয়ে উপরে ওঠে, ডান কিনারা বারের সাথে মেলে
        col.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(dp(300), android.view.View.MeasureSpec.EXACTLY),
            android.view.View.MeasureSpec.UNSPECIFIED
        )
        val loc = IntArray(2)
        bar.getLocationInWindow(loc)
        val x = loc[0] + bar.width - dp(300)
        val y = loc[1] - col.measuredHeight
        pw.showAtLocation(bar, Gravity.NO_GRAVITY, x, y)
    }

    // ---------- ট্যাব তালিকা (নিচ থেকে ওঠা শিট): ট্যাব বাছা/বন্ধ করা, নিচের + দিয়ে নতুন ট্যাব ----------

    private var tabSheet: android.widget.PopupWindow? = null

    private fun tabFavView(t: TabInfo, title: String): View {
        val oval = { c: Int -> GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) } }
        val bmp = t.icon
        if (bmp != null) {
            return ImageView(this).apply {
                setImageBitmap(bmp)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(6), dp(6), dp(6), dp(6))
                background = oval(Color.WHITE)
            }
        }
        return TextView(this).apply {
            text = if (t.kind == "dl") "⬇" else (title.firstOrNull()?.uppercaseChar()?.toString() ?: "•")
            gravity = Gravity.CENTER
            textSize = 15f
            setTextColor(Color.WHITE)
            background = oval(0xFF2BB89A.toInt())
        }
    }

    private fun showTabSheet() {
        tabSheet?.dismiss()
        val dark = isDark()
        val ink = if (dark) 0xFFE8EAED.toInt() else 0xFF1C2326.toInt()
        val accent = if (dark) 0xFF8AB4FF.toInt() else 0xFF0F9D7A.toInt()
        val rowBg = if (dark) 0xFF202325.toInt() else 0xFFE3E6EA.toInt()
        val sheetBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            val r = dp(28).toFloat()
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            setColor(if (dark) 0xFF101214.toInt() else 0xFFF5F6F8.toInt())
        }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = android.widget.ScrollView(this).apply { addView(list) }
        val rowH = dp(60)
        val maxH = (resources.displayMetrics.heightPixels * 0.55f).toInt()

        fun fill() {
            list.removeAllViews()
            for (t in tabs.toList()) {
                val active = t === cur
                val title = tabTitle(t)
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(16), 0, dp(10), 0)
                    if (active) setBackgroundColor(rowBg)
                    setOnClickListener { tabSheet?.dismiss(); selectTab(t) }
                }
                row.addView(tabFavView(t, title), LinearLayout.LayoutParams(dp(34), dp(34)))
                row.addView(TextView(this).apply {
                    text = title
                    textSize = 17f
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setTextColor(if (active) accent else ink)
                    setPadding(dp(14), 0, dp(8), 0)
                }, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(ImageView(this).apply {
                    setImageResource(R.drawable.ic_tab_close)
                    setColorFilter(ink)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    setPadding(dp(10), dp(10), dp(10), dp(10))
                    contentDescription = L.t("cancel")
                    setOnClickListener { closeTab(t); fill() }
                }, LinearLayout.LayoutParams(dp(42), dp(42)))
                list.addView(row, LinearLayout.LayoutParams(-1, rowH))
            }
            scroll.layoutParams = LinearLayout.LayoutParams(-1, minOf(rowH * tabs.size, maxH))
            scroll.requestLayout()
        }
        fill()

        val plus = FrameLayout(this).apply {
            isClickable = true
            setOnClickListener { tabSheet?.dismiss(); newWebTab(HOME) }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_tab_add)
                setColorFilter(ink)
                scaleType = ImageView.ScaleType.FIT_CENTER
                contentDescription = L.t("newTab")
            }, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
        }
        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = sheetBg
            setPadding(0, dp(10), 0, 0)
            addView(scroll)
            addView(plus, LinearLayout.LayoutParams(-1, dp(64)))
        }
        val loc = IntArray(2)
        bar.getLocationInWindow(loc)
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            // উপরের ফাঁকা অংশ ছায়া দেয়; সেখানে চাপলে শিট বন্ধ
            addView(View(this@MainActivity).apply {
                setBackgroundColor(0x99000000.toInt())
                setOnClickListener { tabSheet?.dismiss() }
            }, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(sheet, LinearLayout.LayoutParams(-1, -2))
        }
        val pw = android.widget.PopupWindow(wrap, resources.displayMetrics.widthPixels, loc[1], true)
        pw.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        pw.isOutsideTouchable = true
        tabSheet = pw
        pw.showAtLocation(bar, Gravity.NO_GRAVITY, 0, 0)
    }

    /** সেটিংস: হোম পেজের সেটিংস প্যানেল খোলে (হোমে না থাকলে হোম খুলে) */
    private fun openSettings() {
        // ইতিহাস/ডাউনলোড প্যানেল খোলা থাকলে সেটিংস তার পেছনে লুকিয়ে থাকত; আগে প্যানেল বন্ধ করে নিই
        hidePanel()
        val u = web.url
        if (cur?.kind == "web" && u != null && u.startsWith(HOME)) {
            web.evaluateJavascript("window.__openSettings&&window.__openSettings()", null)
            return
        }
        pendingSettings = true
        newWebTab(HOME)
    }

    // ---------- ইতিহাস: খোলা পেজের তালিকা (সর্বোচ্চ ২০০টি) ----------

    private val histPrefs by lazy { getSharedPreferences("mdl_hist", MODE_PRIVATE) }

    private fun recordVisit(url: String?, title: String?) {
        if (url == null || !url.startsWith("http")) return
        try {
            val old = JSONArray(histPrefs.getString("list", "[]") ?: "[]")
            val nw = JSONArray()
            nw.put(JSONObject().put("url", url).put("title", title ?: url).put("time", System.currentTimeMillis()))
            var n = 1
            for (i in 0 until old.length()) {
                if (n >= 200) break
                val o = old.getJSONObject(i)
                if (o.optString("url") == url) continue
                nw.put(o); n++
            }
            histPrefs.edit().putString("list", nw.toString()).apply()
        } catch (e: Exception) { }
    }

    private fun pushHist() {
        if (panelMode == null || !panelReady) return
        val json = histPrefs.getString("list", "[]") ?: "[]"
        runOnUiThread {
            panel.evaluateJavascript("window.__nativeHist&&window.__nativeHist(" + q(json) + ")", null)
        }
    }

    private fun pushFiles() {
        if (panelMode == null || !panelReady) return
        val ctx = applicationContext
        Thread {
            val arr = JSONArray()
            for (o in History.all()) {
                val path = o.optString("path")
                var ex = History.locate(ctx, path) != null
                // নতুন ফাইল সিস্টেমের ইনডেক্সে আসতে কয়েক সেকেন্ড লাগতে পারে
                if (!ex && System.currentTimeMillis() - o.optLong("time") < 120000L) ex = true
                val x = JSONObject()
                x.put("id", o.optString("id"))
                x.put("name", o.optString("name"))
                x.put("path", path)
                x.put("size", o.optLong("size"))
                x.put("time", o.optLong("time"))
                x.put("ex", ex)
                arr.put(x)
            }
            val json = arr.toString()
            runOnUiThread {
                panel.evaluateJavascript(
                    "window.__nativeFiles&&window.__nativeFiles(" + q(json) + ")", null
                )
            }
        }.start()
    }

    private fun openHistoryFile(id: String) {
        val o = History.find(id) ?: return
        val uri = History.locate(this, o.optString("path"))
        if (uri == null) {
            Toast.makeText(this, L.t("missing"), Toast.LENGTH_SHORT).show()
            pushFiles()
            return
        }
        val ext = o.optString("name").substringAfterLast('.', "").lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            Toast.makeText(this, L.t("noApp"), Toast.LENGTH_LONG).show()
        }
    }

    private fun playHistoryFile(id: String) {
        val o = History.find(id) ?: return
        val uri = History.locate(this, o.optString("path"))
        if (uri == null) {
            Toast.makeText(this, L.t("missing"), Toast.LENGTH_SHORT).show()
            pushFiles()
            return
        }
        val name = o.optString("name")
        val ext = name.substringAfterLast('.', "").lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
        val audio = mime.startsWith("audio/") || ext in listOf("mp3", "m4a", "aac", "opus", "ogg", "wav", "flac")
        try {
            startActivity(
                Intent(this, PlayerActivity::class.java).setData(uri)
                    .putExtra("name", name).putExtra("mime", mime).putExtra("audio", audio)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            openHistoryFile(id)
        }
    }

    private fun legacyFile(path: String): java.io.File =
        java.io.File(android.os.Environment.getExternalStorageDirectory(), path)

    private fun renameHistoryFile(id: String, newName: String) {
        val o = History.find(id) ?: return
        val oldName = o.optString("name")
        val ext = oldName.substringAfterLast('.', "")
        var clean = newName.replace(Regex("""[\\/:*?"<>|]"""), "_").trim()
        if (clean.isEmpty()) return
        if (ext.isNotEmpty() && !clean.endsWith(".$ext", ignoreCase = true)) clean = "$clean.$ext"
        val oldPath = o.optString("path")
        val parent = oldPath.substringBeforeLast('/', "")
        val newPath = if (parent.isEmpty()) clean else "$parent/$clean"
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val uri = History.locate(this, oldPath) ?: throw IllegalStateException("missing")
                contentResolver.update(uri, android.content.ContentValues().apply {
                    put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, clean)
                }, null, null)
            } else {
                val src = legacyFile(oldPath)
                if (!src.renameTo(java.io.File(src.parentFile, clean))) throw IllegalStateException("rename")
            }
            History.rename(id, clean, newPath)
            pushFiles()
        } catch (e: Exception) {
            Toast.makeText(this, if (L.lang == "en") "Could not rename the file" else "নাম বদলানো যায়নি", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteHistoryFile(id: String) {
        val o = History.find(id) ?: return
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                History.locate(this, o.optString("path"))?.let { contentResolver.delete(it, null, null) }
            } else {
                legacyFile(o.optString("path")).delete()
            }
        } catch (e: Exception) { }
        History.remove(id)
        pushFiles()
    }

    private fun openDownloadFolder() {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(
                    Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADownload%2FMediaDownloader"),
                    "resource/folder"
                )
            )
            return
        } catch (e: Exception) { }
        try {
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(
                Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADownload%2FMediaDownloader"),
                "vnd.android.document/directory"
            )
            startActivity(i)
        } catch (e: Exception) {
            try {
                startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
            } catch (e2: Exception) {
                Toast.makeText(this, L.t("folder"), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun redownloadItem(id: String) {
        val o = History.find(id) ?: return
        val url = o.optString("url")
        if (url.isEmpty()) return
        if (o.optString("kind") == "direct") {
            startDownload(url, o.optString("name"))
        } else {
            val ck = CookieManager.getInstance().getCookie(url)
            Engine.enqueue(
                this, url, o.optString("title", o.optString("name")),
                Engine.Choice("again", History.argsOf(o)), ck, web.settings.userAgentString, url
            )
            Toast.makeText(this, L.t("started"), Toast.LENGTH_SHORT).show()
        }
        lastJobsJson = ""
        pushJobs()
    }

    // ---------- archive.org: ফাইল-তালিকা থেকে বাছাই ----------

    private fun archiveId(): String? {
        val u = web.url ?: return null
        return ARCHIVE.find(u)?.groupValues?.get(3)
    }

    private fun archiveDownload(id: String) {
        Toast.makeText(this, L.t("listFetching"), Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val c = URL("https://archive.org/metadata/" + Uri.encode(id)).openConnection() as HttpURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 20000
                c.setRequestProperty("User-Agent", web.settings.userAgentString)
                val body = c.inputStream.bufferedReader().use { it.readText() }
                val files = JSONObject(body).optJSONArray("files")
                val names = ArrayList<String>()
                val labels = ArrayList<String>()
                if (files != null) {
                    val items = ArrayList<Pair<String, Long>>()
                    for (i in 0 until files.length()) {
                        val f = files.getJSONObject(i)
                        val name = f.optString("name")
                        val ext = name.substringAfterLast('.', "").lowercase()
                        if (name.isEmpty() || ext !in ARCHIVE_EXT) continue
                        items.add(Pair(name, f.optString("size", "0").toLongOrNull() ?: 0L))
                    }
                    items.sortByDescending { it.second }
                    for (t in items.take(40)) {
                        names.add(t.first)
                        val size = if (t.second > 0) String.format(" • %.1f MB", t.second / 1048576.0) else ""
                        labels.add(t.first.substringAfterLast('/') + size)
                    }
                }
                runOnUiThread {
                    if (names.isEmpty()) {
                        Toast.makeText(this, L.t("listNone"), Toast.LENGTH_LONG).show()
                    } else {
                        AlertDialog.Builder(this)
                            .setTitle(L.t("pickFile"))
                            .setItems(labels.toTypedArray()) { _, which ->
                                val n = names[which]
                                startDownload(
                                    "https://archive.org/download/" + Uri.encode(id) + "/" + Uri.encode(n, "/"),
                                    n.substringAfterLast('/')
                                )
                            }
                            .setNegativeButton(L.t("cancel"), null)
                            .show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, L.t("listFail") + e.message, Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    // ---------- সরাসরি ফাইল-লিংক: সিস্টেম DownloadManager ----------

    /** সরাসরি ফাইল-লিংক: আগে Engine (aria2c, ১৬ কানেকশন) দিয়ে নামে — DownloadManager এক কানেকশনে ধীর */
    private fun startDownload(url: String, name: String?) {
        try {
            val title = if (name.isNullOrEmpty()) URLUtil.guessFileName(url, null, null) else name
            val ref = web.url?.takeIf { it.startsWith("http") } ?: url
            val choice = Engine.Choice(title, listOf(Engine.Arg("-f", "b")), "video", "direct")
            Engine.enqueue(this, url, title, choice, CookieManager.getInstance().getCookie(url), web.settings.userAgentString, ref)
            showPanel("files", "")
        } catch (e: Exception) {
            startDownloadDm(url, name)
        }
    }

    private fun startDownloadDm(url: String, name: String?) {
        try {
            val fileName = if (name.isNullOrEmpty()) URLUtil.guessFileName(url, null, null) else name
            val r = DownloadManager.Request(Uri.parse(url))
            CookieManager.getInstance().getCookie(url)?.let { r.addRequestHeader("Cookie", it) }
            r.addRequestHeader("User-Agent", web.settings.userAgentString)
            val ref = web.url
            if (ref != null && ref.startsWith("http")) {
                r.addRequestHeader("Referer", ref)
                try {
                    val u = Uri.parse(ref)
                    if (!u.host.isNullOrEmpty()) r.addRequestHeader("Origin", "${u.scheme}://${u.host}")
                } catch (_: Exception) { }
            }
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            r.setTitle(fileName)
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "MediaDownloader/" + fileName)
            val dmId = (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
            dmJobs.add(DmItem(dmId, fileName, url))
            showPanel("files", "")
        } catch (e: Exception) {
            Toast.makeText(this, L.t("failed") + e.message, Toast.LENGTH_LONG).show()
        }
    }

    private inner class Bridge(private val isPanel: Boolean) {
        /** এই WebView এখন আমাদের নিজস্ব হোম পেজ দেখাচ্ছে কিনা (প্যানেল সবসময় বিশ্বস্ত) */
        @Volatile var onHome = false
        private fun ok() = isPanel || onHome

        // ---- হোম পেজ (index.html) ----
        @JavascriptInterface
        fun openUrl(url: String) { if (!ok()) return;
            runOnUiThread { hidePanel(); web.loadUrl(url) }
        }

        // হোম পেজের "ডাউনলোড" ঘর: সরাসরি ফাইল হলে দ্রুত পথে, m3u8/mpd → yt-dlp, নইলে বিশ্লেষণ প্যানেলে
        @JavascriptInterface
        fun download(url: String, name: String) { if (!ok()) return;
            runOnUiThread {
                when {
                    STREAM.matches(url) -> pickSniffed(url)
                    MEDIA.matches(url) -> startDownload(url, name)
                    else -> startAnalyze(url)
                }
            }
        }

        // ---- ভাষা / থিম / বারের ফাঁকা জায়গা (দুই পেজই এগুলো ব্যবহার করে) ----
        @JavascriptInterface
        fun getLang(): String = L.lang

        @JavascriptInterface
        fun getTheme(): String = L.theme()

        @JavascriptInterface
        fun setLang(l: String) { if (!ok()) return;
            L.saveLang(l)
            runOnUiThread {
                relabelBar()
                panel.evaluateJavascript("window.__lang&&window.__lang(" + q(L.lang) + ")", null)
            }
        }

        @JavascriptInterface
        fun setTheme(t: String) { if (!ok()) return;
            L.setTheme(t)
            runOnUiThread {
                bar.setBackgroundColor(if (isDark()) 0xFF0A1114.toInt() else 0xFF16232A.toInt())
                panel.evaluateJavascript("window.__theme&&window.__theme(" + q(L.theme()) + ")", null)
            }
        }

        @JavascriptInterface
        fun getMaxJobs(): Int = L.maxJobs()

        @JavascriptInterface
        fun setMaxJobs(n: Int) { if (!ok()) return;
            L.setMaxJobs(n)
            Engine.setMaxParallel(L.maxJobs())
        }

        @JavascriptInterface
        fun getPopupBlock(): Boolean = L.popupBlock()

        @JavascriptInterface
        fun setPopupBlock(on: Boolean) { if (!ok()) return; L.setPopupBlock(on) }

        @JavascriptInterface
        fun getSubLang(): String = L.subLang()

        @JavascriptInterface
        fun setSubLang(v: String) { if (!ok()) return; L.setSubLang(v) }

        @JavascriptInterface
        fun getSearchCfg(): String = L.searchCfg()

        @JavascriptInterface
        fun setSearchCfg(j: String) { if (!ok()) return; L.setSearchCfg(j) }

        // ---- প্যানেল ----
        @JavascriptInterface
        fun panelClose() { if (!ok()) return; runOnUiThread { if (cur?.kind == "dl") ensureWebTab() else hidePanel() } }

        @JavascriptInterface
        fun analyze(url: String) { if (!ok()) return; runOnUiThread { analyzeForPanel(url) } }

        @JavascriptInterface
        fun pick(kind: String, idx: Int) { if (!ok()) return; runOnUiThread { this@MainActivity.pick(kind, idx) } }

        @JavascriptInterface
        fun pickExtra(id: String, url: String) { if (!ok()) return; runOnUiThread { this@MainActivity.pickExtra(id, url) } }

        @JavascriptInterface
        fun pickSniffed(mediaUrl: String) { if (!ok()) return; runOnUiThread { this@MainActivity.pickSniffed(mediaUrl) } }

        /** কোয়ালিটি লিস্ট থেকে সরাসরি ডাউনলোড (আবার প্রোব করে না) */
        @JavascriptInterface
        fun downloadSniffed(mediaUrl: String) { if (!ok()) return;
            runOnUiThread {
                val page = sniffVarsPage.ifEmpty { web.url?.takeIf { it.startsWith("http") } ?: mediaUrl }
                downloadStream(mediaUrl, page, sniffLabel(mediaUrl))
            }
        }

        @JavascriptInterface
        fun pickSniffQuality(idx: Int) { if (!ok()) return; runOnUiThread { this@MainActivity.pickSniffQuality(idx) } }

        @JavascriptInterface
        fun updateEngine() { if (!ok()) return; runOnUiThread { this@MainActivity.updateEngine() } }

        @JavascriptInterface
        fun clipboardLink(): String {
            if (!ok()) return ""
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
            val u = Regex("https?://\\S+").find(t)?.value
            if (u == null) runOnUiThread { Toast.makeText(this@MainActivity, L.t("clipEmpty"), Toast.LENGTH_SHORT).show() }
            return u ?: ""
        }

        @JavascriptInterface
        fun refreshFiles() { if (!ok()) return; runOnUiThread { pushFiles() } }

        @JavascriptInterface
        fun openFile(id: String) { if (!ok()) return; runOnUiThread { openHistoryFile(id) } }

        @JavascriptInterface
        fun playFile(id: String) { if (!ok()) return; runOnUiThread { playHistoryFile(id) } }

        @JavascriptInterface
        fun clearHist() { if (!ok()) return; runOnUiThread { histPrefs.edit().remove("list").apply(); pushHist() } }

        @JavascriptInterface
        fun openHist(url: String) { if (!ok()) return; runOnUiThread { ensureWebTab(); hidePanel(); web.loadUrl(url) } }

        @JavascriptInterface
        fun getFilters(): String = if (ok()) Filters.json() else ""

        @JavascriptInterface
        fun setFilter(id: String, on: Boolean) { if (!ok()) return; Filters.setOn(id, on) }

        @JavascriptInterface
        fun setFiltersMaster(on: Boolean) { if (!ok()) return; Filters.setMaster(on) }

        @JavascriptInterface
        fun updateFilters() { if (!ok()) return;
            Filters.update {
                runOnUiThread {
                    if (::web.isInitialized) web.evaluateJavascript("window.__filtersDone&&window.__filtersDone()", null)
                }
            }
        }

        @JavascriptInterface
        fun openFolder() { if (!ok()) return; runOnUiThread { openDownloadFolder() } }

        @JavascriptInterface
        fun redownload(id: String) { if (!ok()) return; runOnUiThread { redownloadItem(id) } }

        @JavascriptInterface
        fun renameFile(id: String, newName: String) { if (!ok()) return; runOnUiThread { renameHistoryFile(id, newName) } }

        @JavascriptInterface
        fun deleteFile(id: String) { if (!ok()) return; runOnUiThread { deleteHistoryFile(id) } }

        @JavascriptInterface
        fun removeFile(id: String) { if (!ok()) return;
            runOnUiThread {
                History.remove(id)
                pushFiles()
            }
        }

        @JavascriptInterface
        fun cancelJob(id: String) { if (!ok()) return;
            runOnUiThread {
                if (id.startsWith("dm:")) {
                    val n = id.removePrefix("dm:").toLongOrNull()
                    if (n != null) {
                        (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(n)
                        dmJobs.removeAll { it.id == n }
                    }
                } else {
                    Engine.jobs.firstOrNull { it.id == id }?.let { Engine.cancel(it) }
                }
                lastJobsJson = ""
                pushJobs()
            }
        }

        @JavascriptInterface
        fun pauseJob(id: String) { if (!ok()) return;
            runOnUiThread {
                Engine.jobs.firstOrNull { it.id == id }?.let { Engine.pause(it) }
                lastJobsJson = ""
                pushJobs()
            }
        }

        /** তালিকা থেকে সরায় এবং আংশিক ফাইলও মোছে */
        @JavascriptInterface
        fun discardJob(id: String) { if (!ok()) return;
            if (id.startsWith("dm:")) { cancelJob(id); return }
            runOnUiThread {
                Engine.jobs.firstOrNull { it.id == id }?.let { Engine.discard(it) }
                lastJobsJson = ""
                pushJobs()
            }
        }

        /** যতটুকু নেমেছে ততটুকু প্লেয়ারে দেখা */
        @JavascriptInterface
        fun playPartial(id: String) { if (!ok()) return; runOnUiThread { previewPartial(id) } }

        /** Re-download: ব্যর্থ/বাতিল ডাউনলোড আবার শুরু; yt-dlp-এর আংশিক ফাইল থাকলে সেখান থেকেই চলে */
        @JavascriptInterface
        fun retryJob(id: String) { if (!ok()) return;
            runOnUiThread {
                if (id.startsWith("dm:")) {
                    val n = id.removePrefix("dm:").toLongOrNull()
                    val d = dmJobs.firstOrNull { it.id == n }
                    if (d != null) {
                        (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(d.id)
                        dmJobs.remove(d)
                        startDownload(d.url, d.name)
                    }
                } else {
                    Engine.jobs.firstOrNull { it.id == id }?.let { Engine.retry(this@MainActivity, it) }
                }
                lastJobsJson = ""
                pushJobs()
            }
        }

        @JavascriptInterface
        fun clearJobs() { if (!ok()) return;
            runOnUiThread {
                Engine.clearFinished()
                // শেষ হওয়া সিস্টেম-ডাউনলোড শুধু তালিকা থেকে সরে (ফাইল মোছে না)
                val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                for (d in dmJobs) {
                    dm.query(DownloadManager.Query().setFilterById(d.id)).use { c ->
                        if (!c.moveToFirst() ||
                            c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) != DownloadManager.STATUS_RUNNING &&
                            c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) != DownloadManager.STATUS_PENDING &&
                            c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) != DownloadManager.STATUS_PAUSED
                        ) dmJobs.remove(d)
                    }
                }
                lastJobsJson = ""
                pushJobs()
                updateButtons()
            }
        }

        @JavascriptInterface
        fun media(isPlaying: Boolean, url: String) {
            if (playing != isPlaying || url != playingUrl) {
                playing = isPlaying
                playingUrl = url
                updateButtons()
            }
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            customView != null -> web.webChromeClient?.onHideCustomView()
            cur?.kind == "dl" -> ensureWebTab()
            panelMode != null -> hidePanel()
            web.canGoBack() -> web.goBack()
            else -> @Suppress("DEPRECATION") super.onBackPressed()
        }
    }

    override fun onResume() {
        super.onResume()
        Engine.autoResume()
        handler.post(poll)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(poll)
        CookieManager.getInstance().flush()
    }
}
