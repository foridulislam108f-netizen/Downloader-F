package com.foridul.mediadl

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.Message
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.MimeTypeMap
import android.webkit.URLUtil
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.net.HttpURLConnection
import java.net.URL

class MainActivity : Activity() {

    companion object {
        private const val HOME = "file:///android_asset/index.html"
        private const val PANEL = "file:///android_asset/panel.html"
        private val MEDIA = Regex(
            ".*\\.(mp4|m4v|webm|mkv|mov|3gp|mp3|m4a|aac|ogg|opus|wav|flac|m3u8|mpd)(\\?.*|#.*)?$",
            RegexOption.IGNORE_CASE
        )
        /** সাবটাইটেল ও আর্কাইভ ফাইল: লিংকে ট্যাপ করলে পেজে খোলার বদলে সরাসরি ডাউনলোড হবে */
        private val FILE_EXT = setOf("srt", "vtt", "ass", "ssa", "sub", "sbv", "smi", "idx", "zip", "rar", "7z")
        private val STREAM = Regex(".*\\.(m3u8|mpd)(\\?.*|#.*)?$", RegexOption.IGNORE_CASE)

        // archive.org আইটেম পেজ: /details/ID বা /embed/ID
        private val ARCHIVE = Regex(
            "^https?://([a-z0-9.-]+\\.)?archive\\.org/(details|embed)/([^/?#]+)",
            RegexOption.IGNORE_CASE
        )
        private val ARCHIVE_EXT = setOf(
            "mp4", "m4v", "webm", "mkv", "ogv", "mov", "avi", "mpg", "mpeg",
            "mp3", "m4a", "ogg", "opus", "flac", "wav", "aac"
        )

        // পেজে (iframe ও shadow DOM সহ) ভিডিও/অডিও চলছে কিনা জানায়
        private val WATCHER = """
(function(){
  if(window.__mdl)return; window.__mdl=1;
  var n=0, cache=[], page=location.href, since=0;
  function report(u,t,p){try{if(u&&/^https?:\/\//i.test(u))Android.mediaSource(p||location.href,u,t||'')}catch(x){}}
  // Inspect responses already made by the player: no extra GET, no body consumption.
  function watchNet(w){
    try{
      if(!w||w.__mdlNet)return; w.__mdlNet=1;
      if(w.fetch){var original=w.fetch; w.fetch=function(){
        var from=location.href;
        var p=original.apply(this,arguments);
        p.then(function(r){try{report(r.url,r.headers.get('Content-Type')||'',from)}catch(x){}},function(){});
        return p;
      };}
      var proto=w.XMLHttpRequest&&w.XMLHttpRequest.prototype;
      if(proto){var send=proto.send; proto.send=function(){
        var x=this, from=location.href;
        x.addEventListener('loadend',function done(){
          x.removeEventListener('loadend',done);
          try{if(x.status>=200&&x.status<300)report(x.responseURL,x.getResponseHeader('Content-Type')||'',from)}catch(e){}
        });
        return send.apply(this,arguments);
      };}
    }catch(x){}
  }
  watchNet(window);
  function scan(root,out,depth,deep){
    try{
      watchNet(root.defaultView||(root.ownerDocument&&root.ownerDocument.defaultView));
      root.querySelectorAll('video,audio').forEach(function(e){out.push(e)});
      if(deep){
        root.querySelectorAll('*').forEach(function(x){
          if(x.shadowRoot&&depth<4)scan(x.shadowRoot,out,depth+1,deep);
        });
      }
      if(depth<4){
        root.querySelectorAll('iframe,frame').forEach(function(f){
          try{if(f.contentDocument)scan(f.contentDocument,out,depth+1,deep);}catch(x){}
        });
      }
    }catch(x){}
  }
  function tick(){
    if(page!==location.href){page=location.href; since=performance.now(); cache=[];}
    var list=[];
    var deep=(n++%4)===0;
    scan(document,list,0,deep);
    if(deep)cache=list.slice();
    else cache.forEach(function(e){if(list.indexOf(e)<0&&e.isConnected)list.push(e)});
    var best=null;
    list.forEach(function(e){
      var source=e.querySelector('source');
      report(e.currentSrc||e.src||'',(source&&source.type)||'');
      if(!e.paused&&!e.ended&&e.readyState>=1){
        if(!best||(e.videoWidth||0)>(best.videoWidth||0))best=e;
      }
    });
    if(deep){try{performance.getEntriesByType('resource').slice(-160).forEach(function(r){
      if(r.startTime>=since&&/^(video|audio|fetch|xmlhttprequest)$/.test(r.initiatorType))report(r.name,r.contentType||'');
    })}catch(x){}}
    try{
      if(best)Android.mediaPage(location.href,true,best.currentSrc||best.src||'');
      else Android.mediaPage(location.href,false,'');
    }catch(x){}
  }
  setInterval(tick,700);
  ['play','playing','pause','ended','emptied'].forEach(function(ev){
    document.addEventListener(ev,function(){setTimeout(tick,50)},true);
  });
  tick();
})();
""".trimIndent()
    }


    private lateinit var web: WebView
    private lateinit var panel: WebView
    private lateinit var root: FrameLayout
    private lateinit var bar: LinearLayout
    private lateinit var tabScroll: android.widget.HorizontalScrollView
    private lateinit var tabStrip: LinearLayout

    /** ট্যাব: kind = "web" (ওয়েবপেজ, নিজস্ব WebView) বা "dl" (ডাউনলোড তালিকা) */
    private class TabInfo(val kind: String, var wv: WebView?) { var icon: android.graphics.Bitmap? = null }
    private val tabs = ArrayList<TabInfo>()
    private var cur: TabInfo? = null
    private var lastWeb: TabInfo? = null
    private lateinit var dlBtn: ImageView
    private var customView: View? = null
    private var customCb: WebChromeClient.CustomViewCallback? = null

    // নিচের বারের বাটনগুলো
    private class BarBtn(val box: LinearLayout, val icon: ImageView, val label: TextView)
    private val btns = LinkedHashMap<String, BarBtn>()

    // প্যানেল: null = বন্ধ, "dl" = ডাউনলোড, "files" = আমার ফাইল
    @Volatile private var panelMode: String? = null
    private var panelReady = false
    private var pendingShow: Pair<String, String>? = null

    @Volatile private var lastSniffed = ""
    /** পেজ লোডের সময় ধরা সব মিডিয়া লিংক (m3u8/mpd/mp4/mp3 ইত্যাদি), ক্রম বজায় রেখে অনন্য */
    private class CapturedMedia(val url: String, val kind: String, val mime: String = "", val cookies: String? = null)
    private val sniffed = CopyOnWriteArrayList<CapturedMedia>()
    @Volatile private var observedPage = ""
    @Volatile private var captureGeneration = 0
    @Volatile private var browserUa = ""
    private val headerProbes = Executors.newFixedThreadPool(2)
    // UI-thread owned; bounded HEAD probes never consume a playback response body.
    private val probedUrls = HashSet<String>()
    @Volatile private var playingUrl = ""
    @Volatile private var playing = false
    @Volatile private var nativePlaying = false
    /** বর্তমান পেজের host (UI থ্রেডে বসে; ব্যাকগ্রাউন্ড থ্রেডের ফিল্টার এটা পড়ে — view.url সেখানে ডাকা যায় না) */
    @Volatile private var pageHost: String? = null
    /** পেজ লোডের শুরুতেই অন্য অ্যাপে গান চলছিল: তখন isMusicActive দিয়ে এই পেজে ভিডিও চলছে ধরা হবে না */
    @Volatile private var foreignMusic = false

    private class DmItem(val id: Long, val name: String, val url: String) {
        @Volatile var recorded = false
    }
    private var lastDoneSig = -1
    private val dmJobs = CopyOnWriteArrayList<DmItem>()
    private var lastJobsJson = ""

    // সর্বশেষ বিশ্লেষণের ফল (প্যানেলের তালিকার ক্রম ধরে বাছাই হয়)
    private class Cached(
        val url: String, val title: String, val cookies: String?, val ua: String?,
        val referer: String,
        val video: List<Engine.Choice>, val audio: List<Engine.Choice>, val playlist: List<Engine.Choice>
    )
    private class AnalysisContext(val url: String, val referer: String, val ua: String, val media: List<CapturedMedia>)
    private var analysisContext: AnalysisContext? = null
    private var pendingAnalysisContext: AnalysisContext? = null
    @Volatile private var cached: Cached? = null
    @Volatile private var analyzeToken = 0

    private val handler = Handler(Looper.getMainLooper())
    private val poll = object : Runnable {
        override fun run() {
            checkNative()
            updateButtons()
            pushJobs()
            handler.postDelayed(this, 1000)
        }
    }
    private val uiListener: () -> Unit = { updateButtons(); pushJobs() }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        L.init(this)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
        }
        setContentView(col)

        tabStrip = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        tabScroll = android.widget.HorizontalScrollView(this).apply {
            setBackgroundColor(0xFF0A1114.toInt())
            isHorizontalScrollBarEnabled = false
            addView(tabStrip)
        }
        col.addView(tabScroll, LinearLayout.LayoutParams(-1, dp(38)))

        root = FrameLayout(this).apply { setBackgroundColor(if (isDark()) 0xFF111A33.toInt() else 0xFFF4F5FA.toInt()) }
        col.addView(root, LinearLayout.LayoutParams(-1, 0, 1f))
        bar = buildBar()
        col.addView(bar)
        applyBarHeight()

        panel = WebView(this)
        panel.setBackgroundColor(if (isDark()) 0xFF0F1719.toInt() else 0xFFEEF2F1.toInt())
        root.addView(panel, FrameLayout.LayoutParams(-1, -1))
        panel.visibility = View.GONE

        for (w in listOf(panel)) {
            w.settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                mediaPlaybackRequiresUserGesture = false
                mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                setSupportMultipleWindows(false)
                builtInZoomControls = false
            }
        }
        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(panel, true)
        }

        panel.addJavascriptInterface(Bridge(true), "Android")

        panel.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String?) {
                panelReady = true
                pendingShow?.let { showPanelNow(it.first, it.second) }
                pendingShow = null
            }
        }
        panel.loadUrl(PANEL)

        // ডান পাশের ডাউনলোড বাটন (৪০dp): শুধু সাইটে ভিডিও/অডিও চলার সময় দেখায়
        dlBtn = ImageView(this).apply {
            setImageResource(R.drawable.ic_arrow_down)
            scaleType = ImageView.ScaleType.FIT_CENTER
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFFB76646.toInt())
            }
            elevation = dp(6).toFloat()
        }
        root.addView(dlBtn, FrameLayout.LayoutParams(dp(40), dp(40)).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            rightMargin = dp(12)
        })
        dlBtn.visibility = View.GONE
        dlBtn.setOnClickListener { startAnalyze(null) }

        // বাটনটি আঙুলে ধরে টেনে যেখানে খুশি সরানো যায়; জায়গা মনে রাখে (শুধু নাড়ালে নয়, ট্যাপ করলে আগের মতোই ডাউনলোড খোলে)
        run {
            val sp = getSharedPreferences("mdl_ui", Context.MODE_PRIVATE)
            val slop = dp(8)
            val margin = dp(12)
            var downX = 0f; var downY = 0f
            var startTx = 0f; var startTy = 0f
            var moved = false

            fun clampX(v: Float): Float {
                val baseLeft = (root.width - dlBtn.width - margin).toFloat()
                return v.coerceIn(-baseLeft, margin.toFloat())
            }
            fun clampY(v: Float): Float {
                val baseTop = ((root.height - dlBtn.height) / 2).toFloat()
                val bottomLimit = root.height - (if (bar.visibility == View.VISIBLE) bar.height else 0) - dlBtn.height
                return v.coerceIn(-baseTop, (bottomLimit - baseTop).coerceAtLeast(-baseTop))
            }

            root.post {
                if (sp.contains("dlBtnX")) {
                    dlBtn.translationX = clampX(sp.getFloat("dlBtnX", 0f))
                    dlBtn.translationY = clampY(sp.getFloat("dlBtnY", 0f))
                }
            }

            dlBtn.setOnTouchListener { v, e ->
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX; downY = e.rawY
                        startTx = v.translationX; startTy = v.translationY
                        moved = false
                        v.parent?.requestDisallowInterceptTouchEvent(true)
                        true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (!moved && (Math.abs(dx) > slop || Math.abs(dy) > slop)) moved = true
                        if (moved) {
                            v.translationX = clampX(startTx + dx)
                            v.translationY = clampY(startTy + dy)
                        }
                        true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (moved) {
                            sp.edit()
                                .putFloat("dlBtnX", v.translationX)
                                .putFloat("dlBtnY", v.translationY)
                                .apply()
                        } else {
                            v.performClick()
                        }
                        true
                    }
                    MotionEvent.ACTION_CANCEL -> true
                    else -> false
                }
            }
        }

        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)

        if (Build.VERSION.SDK_INT <= 28 &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), 2)

        Engine.listeners.add(uiListener)
        applyNight()
        Filters.onChange = {
            runOnUiThread {
                if (::web.isInitialized) web.evaluateJavascript("window.__filtersDone&&window.__filtersDone()", null)
            }
        }
        Filters.init(this)
        newWebTab(HOME)
        handleIntent(intent)
        scheduleSpare(2500L)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    /** অন্য অ্যাপ থেকে "Share → Media Downloader" করলে লিংক এখানে আসে */
    private fun handleIntent(i: Intent?) {
        if (i == null || i.action != Intent.ACTION_SEND) return
        val text = i.getStringExtra(Intent.EXTRA_TEXT) ?: return
        val url = Regex("https?://\\S+").find(text)?.value ?: return
        web.post { startAnalyze(url) }
    }

    override fun onDestroy() {
        Engine.listeners.remove(uiListener)
        Filters.onChange = null
        handler.removeCallbacksAndMessages(null)
        ++analyzeToken
        ++captureGeneration
        headerProbes.shutdownNow()
        // WebView গুলো destroy না করলে মেমরি লিক হয়
        try {
            for (t in tabs) t.wv?.let { v -> (v.parent as? android.view.ViewGroup)?.removeView(v); v.stopLoading(); v.destroy() }
            tabs.clear()
            spareWv?.destroy(); spareWv = null
            closeSettingsOverlay()
            (panel.parent as? android.view.ViewGroup)?.removeView(panel)
            panel.destroy()
        } catch (e: Exception) { }
        super.onDestroy()
    }

    /** সিস্টেম ডার্ক/লাইট বদলালে Activity নতুন হয় না (ট্যাব থাকে); শুধু রঙ বদলে নিই */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        bar.setBackgroundColor(if (isDark()) 0xFF0A1114.toInt() else 0xFF16232A.toInt())
        if (panelReady) panel.evaluateJavascript("window.__theme&&window.__theme(" + q(L.theme()) + ")", null)
    }

    private fun dp(v: Int) = Math.round(v * resources.displayMetrics.density)

    private fun q(s: String) = JSONObject.quote(s)

    // ---------------------------------------------------------------------
    //  নিচের বার (সব সময় দেখা যায়)
    // ---------------------------------------------------------------------

    private fun isDark(): Boolean = when (L.theme()) {
        "dark" -> true
        "light" -> false
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    /** এক ওয়েব ট্যাবের জন্য নতুন WebView (সেটিং, ক্লায়েন্ট, ডাউনলোড লিসেনার সহ) */
    private fun newWebView(): WebView {
        val v = WebView(this)
        // পেজ আঁকার আগে WebView-এর ডিফল্ট সাদা ব্যাকগ্রাউন্ড ঝলক দিত; থিম অনুযায়ী রঙ দিয়ে রাখি
        v.setBackgroundColor(if (isDark()) 0xFF111A33.toInt() else 0xFFF4F5FA.toInt())
        v.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            setSupportMultipleWindows(true)
            // এটা বন্ধ থাকলে WebView ইউজার-ট্যাপ ছাড়া খোলা পপ-আপ চুপচাপ ফেলে দেয় এবং onCreateWindow ডাকেই না,
            // ফলে ব্লক হলেও গণনা হতো না। চালু রাখলে সব পপ-আপের চেষ্টা আমাদের কাছে আসে, আমরা ব্লক করে গুনি
            javaScriptCanOpenWindowsAutomatically = true
            builtInZoomControls = false
        }
        applyDesktop(v)
        // ওয়েবসাইট থেকে শুধু আমাদের নিজের হোম পেজ (file:///android_asset/index.html) Bridge-এর ফাংশন চালাতে পারবে;
        // অন্য যেকোনো সাইটের জন্য শুধু media() খোলা (ভিডিও চলছে কিনা জানাতে)
        val br = Bridge(false, v)
        v.addJavascriptInterface(br, "Android")
        CookieManager.getInstance().setAcceptThirdPartyCookies(v, true)
        v.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(
                view: WebView, request: WebResourceRequest
            ): WebResourceResponse? {
                if (view !== web) return null
                // ফিল্টার লিস্টে থাকা বিজ্ঞাপন/ট্র্যাকার ডোমেইনের সাব-রিকোয়েস্ট খালি উত্তর দিয়ে বন্ধ
                // ফিল্টারের কোনো ত্রুটি যেন পুরো অ্যাপ বন্ধ না করে: ত্রুটি হলে অনুরোধ আটকানো হয় না
                val blockIt = try {
                    Filters.shouldBlock(request, pageHost)
                } catch (e: Throwable) { false }
                if (blockIt) return Filters.emptyResponse()
                val u = request.url.toString()
                val generation = captureGeneration
                val page = observedPage
                if (request.method.equals("GET", true) && !isSegment(u)) {
                    val kind = mediaKind(u, "")
                    if (kind != null) {
                        runOnUiThread { if (view === web && generation == captureGeneration) recordMedia(u, kind) }
                    } else if (isMediaCandidate(u, request.requestHeaders)) {
                        runOnUiThread { if (view === web && generation == captureGeneration) probeMediaHeaders(u, page) }
                    }
                }
                return null
            }

            /** পপ-আপ ব্লক: ব্যবহারকারীর ট্যাপ ছাড়া অ্যাপ-খোলার লিংক (intent:, market: ইত্যাদি) এবং বিজ্ঞাপন-ডোমেইনে জোর করে সরিয়ে নেওয়া আটকায় */
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (view !== web || !request.isForMainFrame) return false
                // সাবটাইটেল/zip ইত্যাদি ফাইলের লিংক পেজে না খুলে সরাসরি ডাউনলোড (পপ-আপ ব্লক চালু/বন্ধ যাই হোক)
                try {
                    if (isFileLink(request.url)) {
                        startDownloadDm(request.url.toString(), URLUtil.guessFileName(request.url.toString(), null, null))
                        return true
                    }
                } catch (e: Throwable) { }
                if (!L.popupBlock()) return false
                return try {
                    val u = request.url
                    val scheme = (u.scheme ?: "").lowercase()
                    if (scheme == "http" || scheme == "https") {
                        if (Filters.isAdHost(u.host, pageHost)) { noteBlocked(); true } else false
                    } else if (scheme == "file" || scheme == "about" || scheme == "data" ||
                        scheme == "blob" || scheme == "javascript" || scheme.isEmpty()) {
                        false
                    } else if (!request.hasGesture()) {
                        noteBlocked(); true
                    } else false
                } catch (e: Throwable) { false }
            }

            override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                br.onHome = url?.startsWith(HOME) == true
                if (view !== web) return
                pageHost = try { Uri.parse(url ?: "").host } catch (e: Exception) { null }
                foreignMusic = try { (getSystemService(Context.AUDIO_SERVICE) as AudioManager).isMusicActive } catch (e: Exception) { false }
                resetCapture(url ?: "")
                updateButtons()
            }

            override fun onPageCommitVisible(view: WebView, url: String?) {
                br.onHome = url?.startsWith(HOME) == true
                if (view === web) dropPendingOld()
                inject(view, url)
            }

            override fun onPageFinished(view: WebView, url: String?) {
                if (view === web) dropPendingOld()
                try {
                inject(view, url)
                recordVisit(url, view.title)
                if (pendingSettings && view === web && url?.startsWith(HOME) == true) {
                    pendingSettings = false
                    view.evaluateJavascript("window.__openSettings&&window.__openSettings()", null)
                }
                renderTabs()
                updateButtons()
                } catch (e: Throwable) { }
            }
        }

        v.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView, newProgress: Int) {
                if (newProgress >= 20) inject(view, view.url)
            }

            /**
             * পপ-আপ/নতুন ট্যাব: ব্লক চালু থাকলে বন্ধ (false), না থাকলে একই পেজে খোলে।
             * ব্লক বন্ধ থাকলে ছোট ডামি WebView দিয়ে URL টা মূল পেজেই লোড হয়।
             */
            override fun onCreateWindow(
                view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message
            ): Boolean {
                // ব্লক চালু থাকলে: ট্যাপ ছাড়া সব পপ-আপ বন্ধ। ট্যাপ করা সত্যিকারের লিংক (a-ট্যাগ) খোলে।
                // লিংক নয় এমন জায়গার ট্যাপে (যেমন "Download" বোতামের window.open) শুধু ফাইল-ডাউনলোড চলে,
                // বাকি সব পপ-আন্ডার বিজ্ঞাপন বন্ধ
                var onlyFiles = false
                if (L.popupBlock()) {
                    if (!isUserGesture) {
                        noteBlocked()
                        return false
                    }
                    val t = try { view.hitTestResult.type } catch (e: Throwable) { WebView.HitTestResult.UNKNOWN_TYPE }
                    onlyFiles = !(t == WebView.HitTestResult.SRC_ANCHOR_TYPE || t == WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE)
                }
                val tmp = WebView(this@MainActivity)
                tmp.setDownloadListener { dUrl, _, cd, dMime, _ ->
                    val dName = URLUtil.guessFileName(dUrl, cd, dMime)
                    when {
                        dUrl.startsWith("blob:") -> saveBlob(tmp, dUrl, dName, dMime)
                        dUrl.startsWith("data:") -> saveDataUrl(dUrl, dName)
                        else -> startDownloadDm(dUrl, dName)
                    }
                }
                tmp.webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                        val sc = (r.url.scheme ?: "").lowercase()
                        // about:blank দিয়ে শুরু হওয়া পপ-আন্ডার: আসল লিংক আসা পর্যন্ত অপেক্ষা, মূল পেজ ফাঁকা করা হয় না
                        if (sc != "http" && sc != "https") return true
                        if (isFileLink(r.url)) {
                            startDownloadDm(r.url.toString(), URLUtil.guessFileName(r.url.toString(), null, null))
                            return true
                        }
                        if (onlyFiles && !looksLikeDownload(r.url)) {
                            noteBlocked()
                            return true
                        }
                        if (L.popupBlock() && Filters.isAdHost(r.url.host, pageHost)) {
                            noteBlocked()
                            return true
                        }
                        if (looksLikeDownload(r.url)) {
                            // নাম/টাইপ না জানা ডাউনলোড-লিংক: এই ছোট WebView-তেই লোড হোক, ফাইল হলে ডাউনলোড-লিসেনার ধরবে
                            return false
                        }
                        web.loadUrl(r.url.toString())
                        return true
                    }
                }
                (resultMsg.obj as WebView.WebViewTransport).webView = tmp
                resultMsg.sendToTarget()
                return true
            }

            override fun onReceivedIcon(view: WebView, icon: android.graphics.Bitmap?) {
                tabs.firstOrNull { it.wv === view }?.icon = icon
            }

            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                if (customView != null) { cb.onCustomViewHidden(); return }
                customView = view
                customCb = cb
                root.addView(view, root.indexOfChild(web) + 1, FrameLayout.LayoutParams(-1, -1))
                web.visibility = View.GONE
                bar.visibility = View.GONE
                tabScroll.visibility = View.GONE
                updateButtons()
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility =
                    View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            }

            override fun onHideCustomView() {
                val v = customView ?: return
                root.removeView(v)
                customView = null
                web.visibility = View.VISIBLE
                bar.visibility = View.VISIBLE
                tabScroll.visibility = View.VISIBLE
                @Suppress("DEPRECATION")
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
                customCb?.onCustomViewHidden()
                updateButtons()
            }
        }

        // লিংকে লং-প্রেস করলে ছোট মেনু (থিম অনুযায়ী রঙ)
        v.setOnTouchListener { view, e ->
            touchX = e.rawX.toInt()
            touchY = e.rawY.toInt()
            pullRefresh(view as WebView, e)
            false
        }
        v.setOnLongClickListener { view ->
            val wv = view as WebView
            if (wv.url?.startsWith(HOME) == true) return@setOnLongClickListener false
            val hit = wv.hitTestResult
            val t = hit.type
            if (t != WebView.HitTestResult.SRC_ANCHOR_TYPE && t != WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE)
                return@setOnLongClickListener false
            val extra = hit.extra
            val h = Handler(Looper.getMainLooper()) { m ->
                val url = (if (t == WebView.HitTestResult.SRC_ANCHOR_TYPE) extra else null)
                    ?: m.data?.getString("url") ?: ""
                val text = (m.data?.getString("title") ?: "").trim()
                if (url.startsWith("http")) showLinkMenu(wv, url, text)
                true
            }
            wv.requestFocusNodeHref(h.obtainMessage())
            true
        }

        // সাধারণ ফাইল-ডাউনলোড লিংকও একই পথে যাবে
        v.setDownloadListener { url, _, cd, mime, _ ->
            val name = URLUtil.guessFileName(url, cd, mime)
            when {
                url.startsWith("blob:") -> saveBlob(v, url, name, mime)
                url.startsWith("data:") -> saveDataUrl(url, name)
                // ভিডিও/অডিও হলে yt-dlp ইঞ্জিনে; zip/apk/pdf ইত্যাদি সাধারণ ফাইল হলে সিস্টেম DownloadManager-এ
                mime?.startsWith("video/") == true || mime?.startsWith("audio/") == true || MEDIA.matches(url) ->
                    startDownload(url, name)
                else -> startDownloadDm(url, name)
            }
        }

        return v
    }

    // ---------- নাইট মোড (পর্দায় উষ্ণ অন্ধকার আবরণ; ট্যাচ আটকায় না) ----------
    private var nightView: View? = null
    private fun applyNight() {
        val on = L.nightMode()
        var v = nightView
        if (v == null) {
            if (!on) return
            v = View(this).apply {
                setBackgroundColor(0x55301800.toInt())
                isClickable = false
                isFocusable = false
            }
            root.addView(v, FrameLayout.LayoutParams(-1, -1))
            nightView = v
        }
        v.visibility = if (on) View.VISIBLE else View.GONE
        if (on) v.bringToFront()
    }

    // ---------- কিউআর কোড স্ক্যানার (ZXing; ক্যামেরা অনুমতি নিজেই চায়) ----------
    private fun startQrScan() {
        try {
            com.google.zxing.integration.android.IntentIntegrator(this)
                .setDesiredBarcodeFormats(com.google.zxing.integration.android.IntentIntegrator.ALL_CODE_TYPES)
                .setPrompt(L.t("qrPrompt"))
                .setBeepEnabled(false)
                .setOrientationLocked(false)
                .initiateScan()
        } catch (e: Exception) {
            Toast.makeText(this, e.message ?: "QR error", Toast.LENGTH_LONG).show()
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        val r = com.google.zxing.integration.android.IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (r != null) {
            val text = r.contents?.trim()
            if (!text.isNullOrEmpty()) showQrResult(text)
            return
        }
        super.onActivityResult(requestCode, resultCode, data)
    }

    private fun showQrResult(text: String) {
        val lower = text.lowercase()
        if (lower.startsWith("http://") || lower.startsWith("https://")) { newWebTab(text); return }
        if (lower.startsWith("www.") && !text.contains(" ")) { newWebTab("https://" + text); return }
        val tv = TextView(this).apply {
            this.text = text
            textSize = 16f
            setTextIsSelectable(true)
            setPadding(dp(22), dp(10), dp(22), dp(6))
        }
        AlertDialog.Builder(this)
            .setTitle(L.t("qrResult"))
            .setView(tv)
            .setPositiveButton(L.t("qrCopy")) { _, _ -> copyToClipboard(text) }
            .setNeutralButton(L.t("qrSearch")) { _, _ ->
                newWebTab("https://www.google.com/search?q=" + java.net.URLEncoder.encode(text, "UTF-8"))
            }
            .setNegativeButton(L.t("qrClose"), null)
            .show()
    }

    // ---------- নিচের দিকে টেনে (সোয়াইপ ডাউন) রিফ্রেশ ----------
    private var pullStartY = 0f
    private var pullStartX = 0f
    private var pullArmed = false
    private var pullIndicator: ImageView? = null

    private fun pullView(): ImageView {
        pullIndicator?.let { return it }
        val iv = ImageView(this).apply {
            setImageResource(R.drawable.ic_m_reload)
            setColorFilter(0xFF2BB89A.toInt())
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xFFFFFFFF.toInt()) }
            elevation = dp(6).toFloat()
            visibility = View.GONE
        }
        root.addView(iv, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        pullIndicator = iv
        return iv
    }

    private fun pullRefresh(wv: WebView, e: MotionEvent) {
        if (wv !== web) return
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                pullStartY = e.y
                pullStartX = e.x
                pullArmed = wv.scrollY == 0 && customView == null
            }
            MotionEvent.ACTION_MOVE -> {
                if (!pullArmed) return
                if (e.pointerCount > 1 || wv.scrollY > 0) { pullArmed = false; pullView().visibility = View.GONE; return }
                val dy = e.y - pullStartY
                val dx = Math.abs(e.x - pullStartX)
                if (dy < 0 || dx > dy) { if (dy < -dp(10)) pullArmed = false; pullView().visibility = View.GONE; return }
                if (dy > dp(12)) {
                    val iv = pullView()
                    iv.visibility = View.VISIBLE
                    iv.bringToFront()
                    iv.translationY = (Math.min(dy * 0.5f, dp(90).toFloat()) - dp(30))
                    iv.rotation = dy
                }
            }
            MotionEvent.ACTION_UP -> {
                val iv = pullIndicator
                if (pullArmed && wv.scrollY == 0) {
                    val dy = e.y - pullStartY
                    val dx = Math.abs(e.x - pullStartX)
                    if (dy > dp(110) && dx < dy / 2) {
                        iv?.animate()?.rotationBy(360f)?.setDuration(600)?.start()
                        try { wv.reload() } catch (_: Exception) { }
                        handler.postDelayed({ pullIndicator?.visibility = View.GONE }, 700)
                        pullArmed = false
                        return
                    }
                }
                pullArmed = false
                iv?.visibility = View.GONE
            }
            MotionEvent.ACTION_CANCEL -> {
                pullArmed = false
                pullIndicator?.visibility = View.GONE
            }
        }
    }

    private fun buildBar(): LinearLayout {
        val b = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(if (isDark()) 0xFF0A1114.toInt() else 0xFF16232A.toInt())
        }
        val defs = listOf(
            "back" to R.drawable.ic_bar_back,
            "fwd" to R.drawable.ic_bar_fwd,
            "home" to R.drawable.ic_bar_home,
            "dl" to R.drawable.ic_bar_dl,
            "menu" to R.drawable.ic_bar_menu
        )
        val tv = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, tv, true)
        for ((key, res) in defs) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isClickable = true
                setBackgroundResource(tv.resourceId)
            }
            val icon = ImageView(this).apply {
                setImageResource(res)
                scaleType = ImageView.ScaleType.FIT_CENTER
            }
            val label = TextView(this).apply {
                textSize = 11f
                maxLines = 1
                gravity = Gravity.CENTER
            }
            box.addView(icon, LinearLayout.LayoutParams(dp(24), dp(24)))
            label.visibility = View.GONE
            b.addView(box, LinearLayout.LayoutParams(0, -1, 1f))
            btns[key] = BarBtn(box, icon, label)
            box.setOnClickListener { onBar(key) }
        }
        relabelBar()
        return b
    }

    /** নিচের বারের উচ্চতা স্থির (৪০ dp), কোনো ফাঁকা জায়গা নেই */
    private fun applyBarHeight() {
        bar.layoutParams = LinearLayout.LayoutParams(-1, dp(40))
    }

    private fun relabelBar() {
        for ((k, b) in btns) { b.label.text = L.t(k); b.box.contentDescription = L.t(k) }
    }

    private fun onBar(key: String) {
        if (key != "menu") { closeSettingsOverlay(); ensureWebTab() }
        when (key) {
            "back" -> if (panelMode != null) hidePanel() else if (web.canGoBack()) web.goBack()
            "fwd" -> if (panelMode == null && web.canGoForward()) web.goForward()
            "home" -> {
                hidePanel()
                if (web.url?.startsWith(HOME) != true) web.loadUrl(HOME)
            }
            "dl" -> if (panelMode == "dl") hidePanel() else {
                val u = web.url
                showPanel("dl", if (u != null && u.startsWith("http")) u else "")
            }
            "menu" -> showBarMenu()
        }
        updateButtons()
    }

    private fun updateBar() {
        val u = web.url
        val onHome = u != null && u.startsWith(HOME)
        val pm = panelMode
        fun paint(k: String, enabled: Boolean, active: Boolean) {
            val b = btns[k] ?: return
            val c = if (!enabled) 0x598FA09D else if (active) 0xFF5BE0C0.toInt() else 0xFF8FA09D.toInt()
            b.icon.setColorFilter(c)
            b.label.setTextColor(c)
            b.box.isEnabled = enabled
        }
        paint("back", pm != null || web.canGoBack(), false)
        paint("fwd", pm == null && web.canGoForward(), false)
        paint("home", true, pm == null && onHome)
        paint("dl", true, pm == "dl")
        paint("menu", true, false)
    }

    // ---------------------------------------------------------------------
    //  প্যানেল (পুরো পেজ): ডাউনলোড ও আমার ফাইল
    // ---------------------------------------------------------------------

    private fun showPanel(mode: String, url: String) {
        closeSettingsOverlay()
        if (!panelReady) { pendingShow = Pair(mode, url); panelMode = mode; panel.visibility = View.VISIBLE; updateButtons(); return }
        showPanelNow(mode, url)
    }

    private fun showPanelNow(mode: String, url: String) {
        panelMode = mode
        lastJobsJson = ""
        // আগে প্যানেল দেখিয়ে পরে ভেতরের পেজ বদলানো হতো (পুরনো দৃশ্য ঝলকে উঠত); এখন ভেতরটা বদলে তারপর দেখাই
        panel.evaluateJavascript(
            "window.__show&&window.__show(" + q(mode) + "," + q(url) + "," + q(L.lang) + "," + q(L.theme()) + ")"
        ) { if (panelMode != null) panel.visibility = View.VISIBLE }
        pushJobs()
        if (mode == "files") pushFiles()
        if (mode == "hist") pushHist()
        updateButtons()
    }

    private fun hidePanel() {
        panelMode = null
        panel.visibility = View.GONE
        updateButtons()
    }

    // ---------- ডেস্কটপ মোড ও পেজে ডার্ক মোড ----------

    private fun desktopUa(): String {
        val d = try { WebSettings.getDefaultUserAgent(this) } catch (e: Exception) { "" }
        val chrome = Regex("Chrome/[\\d.]+").find(d)?.value ?: "Chrome/120.0.0.0"
        return "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " + chrome + " Safari/537.36"
    }

    private fun applyDesktop(v: WebView) {
        val on = L.desktopMode()
        v.settings.apply {
            userAgentString = if (on) desktopUa() else null
            useWideViewPort = on
            loadWithOverviewMode = on
            setSupportZoom(true)
            builtInZoomControls = on
            displayZoomControls = false
        }
    }

    private fun applyDesktopAll() {
        tabs.forEach { t -> t.wv?.let { applyDesktop(it) } }
        spareWv?.let { applyDesktop(it) }
        if (::web.isInitialized) browserUa = web.settings.userAgentString
        tabs.forEach { t ->
            val v = t.wv ?: return@forEach
            val u = v.url ?: return@forEach
            if (u.startsWith("http")) try { v.reload() } catch (_: Exception) { }
        }
    }

    private val DARK_ON = """
        (function(){try{
          if(window.__mdlDarkSheet||document.getElementById('__mdlDark'))return;
          var css='html{filter:invert(1) hue-rotate(180deg)!important;background:#fff!important}'
            +'img,video,picture,canvas,iframe,embed,object{filter:invert(1) hue-rotate(180deg)!important}';
          if(window.CSSStyleSheet&&document.adoptedStyleSheets!==undefined){
            var sh=new CSSStyleSheet();sh.replaceSync(css);
            document.adoptedStyleSheets=Array.prototype.slice.call(document.adoptedStyleSheets).concat([sh]);
            window.__mdlDarkSheet=sh;
          }else{
            var s=document.createElement('style');s.id='__mdlDark';s.textContent=css;
            (document.head||document.documentElement).appendChild(s);
          }
        }catch(e){}})();
    """.trimIndent()

    private val DARK_OFF = """
        (function(){try{
          var sh=window.__mdlDarkSheet;
          if(sh){document.adoptedStyleSheets=Array.prototype.slice.call(document.adoptedStyleSheets).filter(function(x){return x!==sh});window.__mdlDarkSheet=null;}
          var e=document.getElementById('__mdlDark');if(e)e.remove();
        }catch(e){}})();
    """.trimIndent()

    private fun applyPageDarkAll() {
        val js = if (L.pageDark()) DARK_ON else DARK_OFF
        tabs.forEach { t ->
            val v = t.wv ?: return@forEach
            if (v.url?.startsWith("http") == true) v.evaluateJavascript(js, null)
        }
    }

    private fun inject(view: WebView, url: String?) {
        if (url != null && url.startsWith("http")) {
            if (L.pageDark()) view.evaluateJavascript(DARK_ON, null)
            view.evaluateJavascript(WATCHER, null)
            if (url.contains("youtube.com")) view.evaluateJavascript(AD_SKIP, null)
            if (view.url?.startsWith(HOME) != true) {
                view.evaluateJavascript(
                    if (L.popupBlock()) POP_GUARD.replace("__ON__", "true") else "window.__mdlPopOn=false;", null)
            }
        }
    }

    // পপ-আপ গার্ড (পেজের ভেতরে): ট্যাপ-জ্যাকিং ওভারলে সরায়, ট্যাপ ছাড়া/ভুয়া লিংক ক্লিকে window.open ও নতুন-উইন্ডো লিংক আটকায়
    private val POP_GUARD = """
(function(){
  window.__mdlPopOn=__ON__;
  if(window.__mdlPG)return; window.__mdlPG=1;
  var lastA=null, lastT=0;
  function big(r){ return r.width>=innerWidth*0.8 && r.height>=innerHeight*0.8; }
  function ghost(el){
    try{
      if(!el||el.nodeType!==1)return false;
      var tg=el.tagName;
      if(tg==='VIDEO'||tg==='IFRAME'||tg==='CANVAS'||tg==='OBJECT'||tg==='EMBED'||tg==='BODY'||tg==='HTML')return false;
      var cs=getComputedStyle(el);
      if(cs.position!=='fixed'&&cs.position!=='absolute')return false;
      var r=el.getBoundingClientRect();
      if(r.width<innerWidth*0.9||r.height<innerHeight*0.9)return false;
      if(el.children.length||(el.textContent||'').trim())return false;
      var bg=cs.backgroundColor;
      var clear=(bg==='rgba(0, 0, 0, 0)'||bg==='transparent'||parseFloat(cs.opacity)<0.05)&&cs.backgroundImage==='none';
      return clear&&(parseInt(cs.zIndex,10)||0)>=100;
    }catch(e){return false}
  }
  function sweep(n){
    if(!window.__mdlPopOn||!n||n.nodeType!==1)return;
    if(ghost(n)){ try{n.remove()}catch(e){} return; }
    try{
      var l=n.querySelectorAll?n.querySelectorAll('a,div,span'):[];
      for(var i=0;i<l.length&&i<40;i++){ if(ghost(l[i])){ try{l[i].remove()}catch(e){} } }
    }catch(e){}
  }
  try{
    new MutationObserver(function(ms){
      if(!window.__mdlPopOn)return;
      for(var i=0;i<ms.length;i++){ var a=ms[i].addedNodes; for(var j=0;j<a.length;j++) sweep(a[j]); }
    }).observe(document.documentElement,{childList:true,subtree:true});
  }catch(e){}
  document.addEventListener('click',function(e){
    if(!window.__mdlPopOn)return;
    var t=e.target, a=(t&&t.closest)?t.closest('a[href]'):null;
    lastA=a; lastT=Date.now();
    if(a){
      try{
        var r=a.getBoundingClientRect();
        if(big(r)&&!(a.textContent||'').trim()&&!a.querySelector('img,video,svg,picture')){
          e.preventDefault(); e.stopImmediatePropagation(); a.remove();
        }
      }catch(x){}
    }
  },true);
  var stub=function(){ return {closed:true,focus:function(){},blur:function(){},close:function(){},postMessage:function(){},location:{href:'',replace:function(){},assign:function(){}},document:{write:function(){},close:function(){}}}; };
  function fileish(u){
    try{ var p=new URL(u,location.href).pathname.toLowerCase();
      return /\.(srt|vtt|ass|ssa|sub|sbv|smi|zip|rar|7z)$/.test(p)||p.indexOf('download')>=0; }catch(e){ return false; }
  }
  var ow=window.open;
  window.open=function(u){
    if(window.__mdlPopOn){
      // ট্যাপ করা সত্যিকারের লিংক বা ফাইল-ডাউনলোডের লিংক ছাড়া window.open বন্ধ
      if(!(lastA&&Date.now()-lastT<1500)&&!fileish(u)) return stub();
    }
    return ow.apply(this,arguments);
  };
  var oc=HTMLAnchorElement.prototype.click;
  HTMLAnchorElement.prototype.click=function(){
    if(window.__mdlPopOn){
      var tg=(this.getAttribute('target')||'').toLowerCase();
      if(tg&&tg!=='_self'&&this!==lastA&&!this.hasAttribute('download')&&!fileish(this.href))return;
    }
    return oc.apply(this,arguments);
  };
})();
"""

    // ইউটিউব বিজ্ঞাপন: বিজ্ঞাপন চললে ভিডিওর শেষে সরিয়ে দেয় এবং Skip বাটন চাপে; মূল ভিডিও চলতে থাকে
    private val AD_SKIP = """
(function(){
  if(window.__mdlAd)return; window.__mdlAd=1;
  function tick(){
    try{
      var p=document.querySelector('.html5-video-player');
      var v=document.querySelector('video');
      if(p&&v&&p.classList.contains('ad-showing')&&isFinite(v.duration)&&v.duration>0){ v.currentTime=v.duration; }
      var sk=document.querySelector('.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button');
      if(sk) sk.click();
      var ov=document.querySelector('.ytp-ad-overlay-close-button');
      if(ov) ov.click();
    }catch(e){}
  }
  setInterval(tick,400);
})();
"""

    // JS ওয়াচার যে ভিডিও ধরতে পারে না (cross-origin iframe), তার জন্য ফোনের অডিও-অবস্থা দেখে নেওয়া
    private fun checkNative() {
        val u = web.url
        val onSite = u != null && u.startsWith("http")
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val music = am.isMusicActive
        if (!music) foreignMusic = false   // অন্য অ্যাপের গান থেমেছে; এরপর শুরু হওয়া শব্দ এই পেজের হতে পারে
        val now = onSite && lastSniffed.isNotEmpty() && music && !foreignMusic
        if (now != nativePlaying) nativePlaying = now
    }

    private fun updateButtons() = runOnUiThread {
        val u = web.url
        val onSite = u != null && u.startsWith("http")
        // ⬇ বাটন: শুধু যখন সাইটে ভিডিও/অডিও চলছে তখন দেখায়
        dlBtn.visibility =
            if (onSite && (playing || nativePlaying) && panelMode == null) View.VISIBLE else View.GONE
        // ডাউনলোড-পেজ ফুল স্ক্রিনে চলে, তাই তখন নিচের বার লুকানো থাকে
        bar.visibility = if (customView != null) View.GONE else View.VISIBLE
        updateBar()
    }

    // ---------------------------------------------------------------------
    //  পেজ বিশ্লেষণ → ফরম্যাট বাছাই (প্যানেলে) → ডাউনলোড (yt-dlp ইঞ্জিন)
    // ---------------------------------------------------------------------

    /** HTTP(S) only: blob/MSE URLs and playlist fragments are not complete downloads. */
    private fun isHttpUrl(url: String): Boolean = try {
        val u = Uri.parse(url)
        (u.scheme.equals("http", true) || u.scheme.equals("https", true)) && !u.host.isNullOrEmpty()
    } catch (_: Exception) { false }

    private fun sameDocument(a: String, b: String): Boolean =
        a.isNotEmpty() && b.isNotEmpty() && a.substringBefore('#') == b.substringBefore('#')

    private fun isSegment(url: String): Boolean {
        val u = try { Uri.parse(url) } catch (_: Exception) { return true }
        val path = (u.path ?: "").lowercase()
        // A named manifest may live in /chunks/; do not reject it by directory alone.
        if (STREAM.matches(url) || path.endsWith("/manifest") || path.endsWith("/playlist")) return false
        val name = path.substringAfterLast('/')
        if (Regex("\\.(ts|m2ts|m4s|cmfv|cmfa|key)$", RegexOption.IGNORE_CASE).containsMatchIn(name)) return true
        if (Regex("^(init([._-].*)?|(?:seg(?:ment)?|frag(?:ment)?|chunk)[._-]?\\d.*)\\.(mp4|m4a|aac|webm)$").matches(name)) return true
        if (Regex("/(segments?|fragments?|chunks?)/[^/]+$").containsMatchIn(path)) return true
        val query = (u.encodedQuery ?: "").lowercase()
        return Regex("(^|&)(byterange|range|sq|segment|fragment|chunk)=[^&]+").containsMatchIn(query)
    }

    private fun mediaKind(url: String, contentType: String): String? {
        if (!isHttpUrl(url) || isSegment(url)) return null
        val mime = contentType.substringBefore(';').trim().lowercase()
        val path = try { Uri.parse(url).path ?: "" } catch (_: Exception) { "" }
        return when {
            mime == "application/vnd.apple.mpegurl" || mime == "application/x-mpegurl" ||
                mime == "audio/mpegurl" || mime == "audio/x-mpegurl" || path.endsWith(".m3u8", true) -> "hls"
            mime == "application/dash+xml" || path.endsWith(".mpd", true) -> "dash"
            mime == "video/mp2t" || mime == "audio/mp2t" -> null
            mime.startsWith("video/") -> "video"
            mime.startsWith("audio/") -> "audio"
            // Some endpoints put a filename in the query string, so use MIME if available.
            MEDIA.matches(url) -> if (Regex("\\.(mp3|m4a|aac|ogg|opus|wav|flac)$", RegexOption.IGNORE_CASE).containsMatchIn(path)) "audio" else "video"
            else -> null
        }
    }

    private fun isMediaCandidate(url: String, headers: Map<String, String> = emptyMap()): Boolean {
        if (!isHttpUrl(url) || isSegment(url)) return false
        val u = Uri.parse(url)
        val path = (u.path ?: "").lowercase()
        // Never probe every page resource or analytics URL; HEAD is best-effort and bounded.
        val ext = path.substringAfterLast('/').substringAfterLast('.', "")
        if (ext in setOf("js", "css", "html", "htm", "json", "jpg", "jpeg", "png", "gif", "svg", "woff", "woff2", "ico")) return false
        val accept = headers.entries.firstOrNull { it.key.equals("Accept", true) }?.value ?: ""
        return accept.contains("video/", true) || accept.contains("audio/", true) ||
            accept.contains("mpegurl", true) || accept.contains("dash+xml", true) ||
            Regex("/(videoplayback|video|audio|media|stream|playback|manifest|playlist|hls|dash)([/._-]|$)").containsMatchIn(path)
    }

    private fun resetCapture(page: String) {
        ++captureGeneration
        observedPage = page
        probedUrls.clear()
        sniffed.clear()
        lastSniffed = ""
        playingUrl = ""
        playing = false
        nativePlaying = false
    }

    private fun recordMedia(url: String, kind: String, mime: String = "") {
        if (!isHttpUrl(url) || isSegment(url)) return
        val old = sniffed.firstOrNull { it.url == url }
        if (old != null && (old.kind == kind || mime.isEmpty())) return
        if (old != null) sniffed.remove(old)
        sniffed.add(0, CapturedMedia(url, kind, mime))
        while (sniffed.size > 40) sniffed.removeAt(sniffed.lastIndex)
        lastSniffed = url
    }

    /** CookieManager returns only URL-applicable cookies, not a domain/path-aware export. */
    private fun cookiesFor(url: String): String? = try {
        CookieManager.getInstance().getCookie(url)?.takeIf { it.isNotBlank() }
    } catch (_: Exception) { null }

    private fun probeMediaHeaders(url: String, page: String) {
        if (!isHttpUrl(url) || isSegment(url) || probedUrls.size >= 16 || !probedUrls.add(url)) return
        val generation = captureGeneration
        val ua = browserUa
        val cookies = cookiesFor(url)
        if (headerProbes.isShutdown) return
        headerProbes.execute {
            if (generation != captureGeneration) return@execute
            try {
                withMediaConnection(url, page, ua, cookies, "HEAD") { c, _ ->
                    if (c.responseCode in 200..299) {
                        val mime = c.contentType ?: ""
                        val kind = mediaKind(url, mime)
                        if (kind != null) runOnUiThread {
                            if (!isFinishing && generation == captureGeneration) recordMedia(url, kind, mime)
                        }
                    }
                }
            } catch (_: Exception) { /* HEAD is optional: never interrupt playback. */ }
        }
    }

    private fun snapshotContext(url: String): AnalysisContext {
        val page = web.url?.takeIf { isHttpUrl(it) } ?: url
        val media = if (sameDocument(url, page)) {
            val found = sniffed.toMutableList()
            val src = playingUrl
            if (isHttpUrl(src) && !isSegment(src) && found.none { it.url == src }) {
                found.add(0, CapturedMedia(src, mediaKind(src, "") ?: "video"))
            }
            found.map { CapturedMedia(it.url, it.kind, it.mime, cookiesFor(it.url)) }
                .sortedByDescending { scoreSniffed(it) }
        } else emptyList()
        // A pasted/shared webpage should reference itself, not whichever unrelated tab is open.
        val ref = if (sameDocument(url, page) || mediaKind(url, "") != null) page else url
        return AnalysisContext(url, ref, web.settings.userAgentString, media)
    }

    /** target == null হলে বর্তমান পেজ। প্যানেল খুলে সেখানেই বিশ্লেষণ চলে। */
    private fun startAnalyze(target: String?) {
        ensureWebTab()
        val url = target ?: web.url ?: ""
        if (!isHttpUrl(url)) {
            Toast.makeText(this, L.t("openSite"), Toast.LENGTH_SHORT).show()
            return
        }
        pendingAnalysisContext = snapshotContext(url)
        showPanel("dl", url)
    }

    private fun arr(l: List<Engine.Choice>): JSONArray {
        val a = JSONArray()
        for ((i, c) in l.withIndex()) a.put(JSONObject().put("i", i).put("label", c.label).put("sub", c.sub))
        return a
    }

    private fun extrasFor(ctx: AnalysisContext): List<Pair<String, String>> {
        val list = ArrayList<Pair<String, String>>()
        if (ARCHIVE.find(ctx.url) != null) list.add("archive" to L.t("exArchive"))
        if (ctx.media.isNotEmpty()) list.add("direct" to L.t("exDirect"))
        if (MEDIA.matches(ctx.url) && !STREAM.matches(ctx.url) && !isSegment(ctx.url)) list.add("self" to L.t("exSelf"))
        return list
    }

    private fun analysisJson(ctx: AnalysisContext, c: Cached?, err: String?): String {
        val o = JSONObject()
        o.put("url", ctx.url)
        o.put("title", c?.title ?: "")
        o.put("video", arr(c?.video ?: emptyList()))
        o.put("audio", arr(c?.audio ?: emptyList()))
        o.put("playlist", arr(c?.playlist ?: emptyList()))
        if (err != null) o.put("err", err)
        val ex = JSONArray()
        for (e in extrasFor(ctx)) ex.put(JSONObject().put("id", e.first).put("label", e.second))
        o.put("extras", ex)
        val sn = JSONArray()
        for (m in ctx.media) {
            val kind = if (m.kind == "hls" || m.kind == "dash") "stream" else m.kind
            sn.put(JSONObject().put("url", m.url).put("kind", kind).put("label", sniffLabel(m.url, m.kind)))
        }
        o.put("sniffed", sn)
        return o.toString()
    }

    private fun scoreSniffed(m: CapturedMedia): Int {
        val l = m.url.lowercase()
        var score = if (m.kind == "hls" || m.kind == "dash") 50 else 0
        if (l.contains("master")) score += 120
        if (l.contains("index") && score > 0) score += 100
        if (l.contains("playlist") || l.contains("manifest")) score += 80
        if (l.contains("1080") || l.contains("1920")) score += 25
        else if (l.contains("720") || l.contains("1280")) score += 20
        if (m.url == playingUrl) score += 40
        return score
    }

    private fun sniffLabel(u: String, kind: String = mediaKind(u, "") ?: "video"): String {
        val l = u.lowercase()
        return when {
            l.contains("master") -> if (L.lang == "en") "Master playlist" else "মাস্টার প্লেলিস্ট"
            l.contains("1080") || l.contains("1920") -> "≈1080p"
            l.contains("720") || l.contains("1280") -> "≈720p"
            kind == "hls" || kind == "dash" -> if (L.lang == "en") "HLS/DASH stream" else "HLS/DASH স্ট্রিম"
            kind == "audio" -> if (L.lang == "en") "Audio file" else "অডিও ফাইল"
            else -> if (L.lang == "en") "Media file" else "মিডিয়া ফাইল"
        }
    }

    private fun pushAnalysis(json: String) {
        panel.evaluateJavascript("window.__analysis&&window.__analysis(" + q(json) + ")", null)
    }

    private fun clearChoices() {
        cached = null
        sniffVars = emptyList()
        sniffSession = null
    }

    private fun analyzeForPanel(url: String) {
        if (!isHttpUrl(url)) return
        val token = ++analyzeToken
        clearChoices()
        val ctx = pendingAnalysisContext?.takeIf { it.url == url } ?: snapshotContext(url)
        pendingAnalysisContext = null
        analysisContext = ctx
        val cookies = cookiesFor(url)
        if (Engine.isPlaylistUrl(url)) {
            val c = Cached(url, "", cookies, ctx.ua, ctx.referer, emptyList(), emptyList(), Engine.playlistChoices())
            cached = c
            pushAnalysis(analysisJson(ctx, c, null))
            return
        }
        Thread {
            try {
                val a = Engine.analyze(url, cookies, ctx.ua, ctx.referer)
                runOnUiThread {
                    if (token == analyzeToken && !isFinishing) {
                        val c = Cached(url, a.title, cookies, ctx.ua, ctx.referer, a.video, a.audio, emptyList())
                        cached = c
                        pushAnalysis(analysisJson(ctx, c, null))
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (token == analyzeToken && !isFinishing) {
                        cached = null
                        pushAnalysis(analysisJson(ctx, null, Engine.shortError(e)))
                    }
                }
            }
        }.start()
    }

    private fun pick(kind: String, idx: Int) {
        val c = cached ?: return
        val list = when (kind) {
            "video" -> c.video
            "audio" -> c.audio
            "playlist" -> c.playlist
            else -> return
        }
        val choice = list.getOrNull(idx) ?: return
        Engine.enqueue(this, c.url, c.title.ifEmpty { c.url }, choice, c.cookies, c.ua, c.referer)
        showPanel("files", "")
    }

    private fun pickExtra(id: String, url: String) {
        val ctx = analysisContext?.takeIf { it.url == url } ?: return
        when (id) {
            "archive" -> ARCHIVE.find(ctx.url)?.groupValues?.get(3)?.let { archiveDownload(it) }
            "direct" -> ctx.media.firstOrNull()?.let { pickSniffed(it.url) }
            "self" -> if (MEDIA.matches(url) && !STREAM.matches(url) && !isSegment(url))
                startDownload(url, null, ctx.referer, ctx.ua, cookiesFor(url))
        }
    }

    private class SniffVar(val url: String, val label: String, val sub: String = "", val cookies: String? = null)
    private class SniffSession(val ctx: AnalysisContext, val master: String, val cookies: String?, val token: Int)
    private var sniffSession: SniffSession? = null
    @Volatile private var sniffVars: List<SniffVar> = emptyList()

    private fun pickSniffed(mediaUrl: String) {
        if (!isHttpUrl(mediaUrl) || isSegment(mediaUrl)) return
        val ctx = analysisContext
        val media = ctx?.media?.firstOrNull { it.url == mediaUrl }
        // Panel URLs must come from the analysis snapshot, not a newer browser page.
        if (ctx == null || media == null) return
        selectCapturedMedia(media, ctx)
    }

    private fun selectCapturedMedia(media: CapturedMedia, ctx: AnalysisContext) {
        when (media.kind) {
            "hls" -> probeM3u8(media.url, ctx, media.cookies)
            "dash" -> analyzeStreamForPanel(media.url, ctx, media.cookies)
            else -> startDownload(media.url, null, ctx.referer, ctx.ua, media.cookies)
        }
    }

    private fun downloadStream(mediaUrl: String, ctx: AnalysisContext, label: String, cookies: String?) {
        if (!isHttpUrl(mediaUrl) || isSegment(mediaUrl)) return
        val choice = Engine.Choice(label, listOf(Engine.Arg("-f", "bv*+ba/b"), Engine.Arg("--merge-output-format", "mp4")), "video", "stream")
        Engine.enqueue(this, mediaUrl, ctx.url, choice, cookies, ctx.ua, ctx.referer)
        showPanel("files", "")
        Toast.makeText(this, L.t("added"), Toast.LENGTH_SHORT).show()
    }

    private fun pushSniff(json: String) {
        panel.evaluateJavascript("window.__sniffQualities&&window.__sniffQualities(" + q(json) + ")", null)
    }

    private fun probeM3u8(url: String, ctx: AnalysisContext, cookies: String?) {
        // Analyze the master, not just a leaf variant: AUDIO groups can be separate streams.
        // This also preserves Engine's metadata cache and avoids re-extraction on Download.
        analyzeStreamForPanel(url, ctx, cookies)
    }

    /** Analysis failure offers an explicit best-stream button; it never starts a download. */
    private fun analyzeStreamForPanel(mediaUrl: String, ctx: AnalysisContext, cookies: String?) {
        val token = ++analyzeToken
        clearChoices()
        sniffSession = SniffSession(ctx, mediaUrl, cookies, token)
        pushSniff(JSONObject().put("url", ctx.url).put("probing", true).put("probeUrl", mediaUrl).toString())
        Thread {
            try {
                val a = Engine.analyze(mediaUrl, cookies, ctx.ua, ctx.referer)
                runOnUiThread {
                    if (token == analyzeToken && !isFinishing) {
                        val c = Cached(mediaUrl, a.title, cookies, ctx.ua, ctx.referer, a.video, a.audio, emptyList())
                        cached = c
                        pushAnalysis(analysisJson(ctx, c, null))
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    if (token == analyzeToken && !isFinishing) {
                        cached = null
                        pushSniff(JSONObject().put("url", ctx.url).put("probeUrl", mediaUrl)
                            .put("err", Engine.shortError(e)).put("qualities", JSONArray()).toString())
                    }
                }
            }
        }.start()
    }

    private fun pickSniffQuality(idx: Int) {
        val session = sniffSession?.takeIf { it.token == analyzeToken } ?: return
        val v = sniffVars.getOrNull(idx) ?: return
        downloadStream(v.url, session.ctx, v.label, v.cookies)
    }

    private class TextResponse(val text: String, val url: String)

    /** Redirects use cookies for each actual host; never forward the page's Cookie header. */
    private fun <T> withMediaConnection(url: String, referer: String, ua: String, cookies: String?, method: String,
                                        read: (HttpURLConnection, String) -> T): T {
        var target = url
        repeat(6) { hop ->
            if (!isHttpUrl(target)) throw Exception("Invalid media URL")
            val c = URL(target).openConnection() as HttpURLConnection
            try {
                c.connectTimeout = 5000
                c.readTimeout = if (method == "HEAD") 5000 else 12000
                c.instanceFollowRedirects = false
                c.requestMethod = method
                c.setRequestProperty("User-Agent", ua)
                c.setRequestProperty("Accept", "*/*")
                if (isHttpUrl(referer)) c.setRequestProperty("Referer", referer)
                (if (hop == 0) cookies else cookiesFor(target))?.let { c.setRequestProperty("Cookie", it) }
                val code = c.responseCode
                if (code in listOf(301, 302, 303, 307, 308)) {
                    val next = c.getHeaderField("Location") ?: throw Exception("HTTP $code")
                    target = URL(URL(target), next).toString()
                } else return read(c, target)
            } finally { c.disconnect() }
        }
        throw Exception(if (L.lang == "en") "Too many redirects" else "অতিরিক্ত রিডাইরেক্ট")
    }

    private fun fetchText(url: String, referer: String, ua: String, cookies: String?): TextResponse =
        withMediaConnection(url, referer, ua, cookies, "GET") { c, finalUrl ->
            if (c.responseCode !in 200..299) throw Exception("HTTP ${c.responseCode}")
            if (c.contentLengthLong > 1048576L) throw Exception(L.t("noFmt"))
            val text = c.inputStream.bufferedReader().use { reader ->
                val out = StringBuilder()
                val buf = CharArray(4096)
                while (true) {
                    val n = reader.read(buf)
                    if (n < 0) break
                    out.append(buf, 0, n)
                    if (out.length > 1048576) throw Exception(L.t("noFmt"))
                }
                out.toString()
            }
            if (!text.trimStart('\uFEFF', ' ', '\r', '\n', '\t').startsWith("#EXTM3U")) throw Exception(L.t("noFmt"))
            TextResponse(text, finalUrl)
        }

    /**
     * HLS মাস্টার প্লেলিস্ট পার্স। `#EXT-X-STREAM-INF` থেকে রেজোলিউশন/ব্যান্ডউইথ বের করে।
     * মিডিয়া প্লেলিস্ট হলে খালি লিস্ট (কলিং সাইড সরাসরি ডাউনলোড করবে)।
     */
    private fun parseM3u8Master(text: String, baseUrl: String): List<SniffVar> {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        if (lines.none { it.startsWith("#EXT-X-STREAM-INF", ignoreCase = true) }) {
            // অডিও-only মাস্টার?
            if (lines.any { it.startsWith("#EXT-X-MEDIA", ignoreCase = true) && it.contains("TYPE=AUDIO", ignoreCase = true) }) {
                // সিম্পল: পুরো মাস্টারই একটা অপশন হিসেবে দাও
                return listOf(SniffVar(baseUrl, "Audio playlist", "master"))
            }
            return emptyList()
        }
        val out = ArrayList<SniffVar>()
        var i = 0
        while (i < lines.size) {
            val line = lines[i]
            if (line.startsWith("#EXT-X-STREAM-INF", ignoreCase = true)) {
                val info = line.substringAfter(':')
                val bw = Regex("BANDWIDTH=(\\d+)", RegexOption.IGNORE_CASE).find(info)?.groupValues?.get(1)?.toLongOrNull()
                val res = Regex("RESOLUTION=(\\d+)x(\\d+)", RegexOption.IGNORE_CASE).find(info)
                val name = Regex("NAME=\"([^\"]+)\"", RegexOption.IGNORE_CASE).find(info)?.groupValues?.get(1)
                val codecs = Regex("CODECS=\"([^\"]+)\"", RegexOption.IGNORE_CASE).find(info)?.groupValues?.get(1) ?: ""
                val isAudioOnly = codecs.isNotEmpty() && !codecs.contains("avc", true) &&
                    !codecs.contains("hvc", true) && !codecs.contains("vp9", true) &&
                    !codecs.contains("av01", true) && codecs.contains("mp4a", true)
                i++
                while (i < lines.size && lines[i].startsWith("#")) i++
                if (i >= lines.size) break
                val raw = lines[i]
                if (raw.startsWith("#")) continue
                val abs = resolveUrl(baseUrl, raw)
                val height = res?.groupValues?.get(2)?.toIntOrNull()
                val label = when {
                    !name.isNullOrBlank() -> name
                    height != null -> "${height}p"
                    isAudioOnly -> "Audio only"
                    else -> "Stream"
                }
                val mbps = if (bw != null && bw > 0) String.format("%.1f Mbps", bw / 1_000_000.0) else ""
                val sub = listOfNotNull(
                    if (height != null && name != null) "${height}p" else null,
                    mbps.ifEmpty { null },
                    if (isAudioOnly) "audio" else null
                ).joinToString(" • ")
                out.add(SniffVar(abs, label, sub))
            }
            i++
        }
        // উচ্চ রেজোলিউশন আগে
        return out.sortedByDescending { v ->
            Regex("(\\d{3,4})p").find(v.label)?.groupValues?.get(1)?.toIntOrNull()
                ?: Regex("(\\d{3,4})p").find(v.sub)?.groupValues?.get(1)?.toIntOrNull()
                ?: 0
        }
    }

    private fun resolveUrl(base: String, ref: String): String {
        if (ref.startsWith("http://") || ref.startsWith("https://")) return ref
        return try {
            URL(URL(base), ref).toString()
        } catch (_: Exception) {
            ref
        }
    }

    private fun updateEngine() {
        Toast.makeText(this, L.t("engUpdating"), Toast.LENGTH_SHORT).show()
        Thread {
            val msg = try {
                Engine.updateNow()
            } catch (e: Exception) {
                L.t("engUpdFail") + Engine.shortError(e)
            }
            runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() }
        }.start()
    }

    // ---------- ডাউনলোড প্যানেলে চলমান ডাউনলোড দেখানো ----------

    private val dmSample = HashMap<Long, Pair<Long, Long>>()   // id -> (বাইট, সময়)
    private val dmSpeedMap = HashMap<Long, Long>()

    private fun dmSpeed(id: Long, bytes: Long): Long {
        val now = System.currentTimeMillis()
        val last = dmSample[id]
        if (last == null) { dmSample[id] = Pair(bytes, now); return 0L }
        val dt = now - last.second
        if (dt >= 700) {
            val v = ((bytes - last.first).coerceAtLeast(0L) * 1000L) / dt
            dmSpeedMap[id] = v
            dmSample[id] = Pair(bytes, now)
        }
        return dmSpeedMap[id] ?: 0L
    }

    private fun jobsJson(): String {
        val arr = JSONArray()
        for (j in Engine.jobs) {
            val o = JSONObject()
            o.put("id", j.id)
            o.put("name", j.title)
            o.put("label", j.label)
            o.put("st", when (j.status) {
                Engine.Status.QUEUED -> "queue"
                Engine.Status.RUNNING -> "run"
                Engine.Status.DONE -> "done"
                Engine.Status.FAILED -> "fail"
                Engine.Status.CANCELED -> "cancel"
            })
            o.put("paused", j.paused)
            o.put("pct", if ((j.status == Engine.Status.RUNNING || j.paused) && j.progress > 0f) j.progress.toInt().coerceIn(0, 100) else -1)
            o.put("eta", j.eta)
            o.put("speed", if (j.status == Engine.Status.RUNNING) j.speed else 0L)
            o.put("total", j.totalBytes)
            o.put("loaded", if (j.totalBytes > 0 && j.progress > 0f) (j.totalBytes * (j.progress / 100.0)).toLong() else 0L)
            o.put("rc", j.message == "reconnecting" && j.status == Engine.Status.RUNNING)
            o.put("phase", if (j.status == Engine.Status.RUNNING && j.message in setOf("preparing", "refreshing")) j.message else "")
            o.put("msg", if (j.status == Engine.Status.FAILED) j.message.take(120) else "")
            arr.put(o)
        }
        val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
        for (d in dmJobs) {
            val c = dm.query(DownloadManager.Query().setFilterById(d.id))
            c.use { cur ->
                if (!cur.moveToFirst()) {
                    dmJobs.remove(d) // বাতিল/মুছে গেছে
                    return@use
                }
                val status = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                val so = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_BYTES_DOWNLOADED_SO_FAR))
                val total = cur.getLong(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_TOTAL_SIZE_BYTES))
                if (status == DownloadManager.STATUS_SUCCESSFUL && !d.recorded) {
                    d.recorded = true
                    val lu = cur.getString(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_LOCAL_URI))
                    val real = lu?.let { Uri.parse(it).lastPathSegment } ?: d.name
                    History.add(History.FOLDER + real, d.url, "direct", d.name, null, so)
                }
                val o = JSONObject()
                o.put("id", "dm:" + d.id)
                o.put("name", d.name)
                o.put("label", "")
                o.put("st", when (status) {
                    DownloadManager.STATUS_RUNNING -> "run"
                    DownloadManager.STATUS_SUCCESSFUL -> "done"
                    DownloadManager.STATUS_FAILED -> "fail"
                    else -> "queue"
                })
                o.put("pct", if (total > 0) (so * 100 / total).toInt().coerceIn(0, 100) else -1)
                o.put("paused", false)
                o.put("loaded", so)
                o.put("total", if (total > 0) total else 0)
                o.put("speed", if (status == DownloadManager.STATUS_RUNNING) dmSpeed(d.id, so) else 0L)
                o.put("eta", 0)
                o.put("rc", false)
                o.put("msg", "")
                arr.put(o)
            }
        }
        return arr.toString()
    }

    /** প্যানেল খোলা থাকলে চলমান ডাউনলোডের তালিকা পাঠায় */
    private fun pushJobs() {
        if (panelMode == null || !panelReady) return
        val json = try { jobsJson() } catch (e: Exception) { return }
        val sig = Engine.jobs.count { it.status == Engine.Status.DONE } + dmJobs.count { it.recorded }
        if (sig != lastDoneSig) {
            lastDoneSig = sig
            if (panelMode == "files") pushFiles()
        }
        if (json == lastJobsJson) return
        lastJobsJson = json
        panel.evaluateJavascript(
            "window.__nativeJobs&&window.__nativeJobs(" + q(json) + ")", null
        )
    }

    // ---------- My Files: ডাউনলোড-ইতিহাস, ফাইল খোলা, আবার ডাউনলোড ----------

    private fun previewPartial(id: String) {
        val bn = L.lang != "en"
        val job = Engine.jobs.firstOrNull { it.id == id }
        val f = job?.let { Engine.partialFile(it) }
        if (f == null) {
            Toast.makeText(this, if (bn) "এখনো কিছু নামেনি" else "Nothing downloaded yet", Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val real = f.name.removeSuffix(".part")
            val ext = real.substringAfterLast('.', "").lowercase()
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "video/*"
            val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.files", f)
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(uri, mime)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, null))
        } catch (e: Exception) {
            Toast.makeText(this, if (bn) "প্লেয়ারে খোলা যায়নি" else "Could not open in a player", Toast.LENGTH_SHORT).show()
        }
    }

    // ---------- ট্যাব: প্রতিটি ওয়েব ট্যাবের নিজস্ব পেজ, ডাউনলোড ট্যাব আলাদা ----------

    /** সক্রিয় ওয়েব ট্যাবের WebView কে root-এ যোগ করে; আগেরটা সরায় */
    private fun attachWeb(v: WebView) {
        dropPendingOld()
        val old: WebView? = if (::web.isInitialized && web !== v) web else null
        old?.onPause()
        web = v
        browserUa = v.settings.userAgentString
        if (old != null || observedPage != (v.url ?: "")) resetCapture(v.url ?: "")
        pageHost = try { Uri.parse(v.url ?: "").host } catch (e: Exception) { null }
        // নতুন WebView পুরনোটার নিচে (index 0) বসে; পুরনোটা তখনই সরে যখন নতুন পেজের প্রথম ফ্রেম আঁকা হয়।
        // আগে সাথে সাথে সরানো হতো, ফলে নতুন ট্যাব খোলার সময় কয়েক ফ্রেম কালো/সাদা ঝলক দেখা যেত
        if (v.parent == null) root.addView(v, 0, FrameLayout.LayoutParams(-1, -1))
        v.onResume()
        if (old != null && old.parent === root) {
            if (v.url == null) {
                pendingOld = old
                handler.postDelayed({ if (pendingOld === old) dropPendingOld() }, 2000)
            } else root.removeView(old)
        }
    }

    private var pendingOld: WebView? = null
    private fun dropPendingOld() {
        pendingOld?.let { if (it.parent === root) root.removeView(it) }
        pendingOld = null
    }

    /**
     * WebView বানানো ভারী কাজ (UI থ্রেড কয়েক ফ্রেম আটকে যায়) — নতুন ট্যাব খোলার সময় সেটাই ঝাঁকুনির মতো লাগত।
     * তাই একটা WebView আগে থেকে বানিয়ে রাখি; ট্যাব খুললে সেটা নিই, আর পরের জন্য আবার অবসরে বানাই।
     */
    private var spareWv: WebView? = null
    private fun takeWebView(): WebView {
        val v = spareWv ?: newWebView()
        spareWv = null
        scheduleSpare(3000L)
        return v
    }
    /** নতুন ট্যাব খোলার সময়ই WebView বানালে ফ্রেম আটকে ঝাঁকুনি লাগে; পেজ লোড শেষ হওয়ার পর ফাঁকা সময়ে বানাই */
    private fun scheduleSpare(delayMs: Long, tries: Int = 0) {
        handler.postDelayed({
            if (isFinishing || spareWv != null) return@postDelayed
            val busy = ::web.isInitialized && web.progress < 100
            if (busy && tries < 4) { scheduleSpare(1500L, tries + 1); return@postDelayed }
            android.os.Looper.myQueue().addIdleHandler { ensureSpare(); false }
        }, delayMs)
    }
    private fun ensureSpare() {
        if (spareWv == null && !isFinishing) spareWv = try { newWebView() } catch (e: Exception) { null }
    }

    private fun newWebTab(url: String) {
        closeSettingsOverlay()
        val t = TabInfo("web", takeWebView())
        tabs.add(t)
        lastWeb = t
        selectTab(t)
        t.wv?.loadUrl(url)
    }

    /** বর্তমান পেজ না ছেড়ে নতুন ট্যাবে লিংক খোলে (ব্যাকগ্রাউন্ডে লোড হয়); ট্যাব স্ট্রিপে নতুন ট্যাব যোগ হয় */
    private fun newBackgroundTab(url: String) {
        val t = TabInfo("web", takeWebView())
        tabs.add(t)
        renderTabs()
        t.wv?.loadUrl(url)
        Toast.makeText(this, L.t("openedBg"), Toast.LENGTH_SHORT).show()
    }

    private fun openDownloadTab() {
        val d = tabs.firstOrNull { it.kind == "dl" } ?: TabInfo("dl", null).also { tabs.add(it) }
        selectTab(d)
    }

    /** ডাউনলোড ট্যাবে থাকলে শেষ ওয়েব ট্যাবে ফেরে (বা নতুন বানায়) */
    private fun ensureWebTab() {
        if (cur?.kind != "dl") return
        val w = lastWeb?.takeIf { tabs.contains(it) } ?: tabs.lastOrNull { it.kind == "web" }
        if (w != null) selectTab(w) else newWebTab(HOME)
    }

    private fun selectTab(t: TabInfo) {
        closeSettingsOverlay()
        if (!tabs.contains(t)) return
        // "dl" ধরনের ট্যাব নতুন পেজ হিসেবে খোলে না; শুধু ওয়েব ট্যাবেই সরাসরি যাই
        if (t.kind != "web") return
        cur = t
        t.wv?.let { attachWeb(it) }
        lastWeb = t
        hidePanel()
        renderTabs()
        updateButtons()
    }

    private fun closeTab(t: TabInfo) {
        if (!tabs.contains(t)) return
        val idx = tabs.indexOf(t)
        val wasWeb = t.kind == "web" && t.wv != null
        val wasAttached = wasWeb && ::web.isInitialized && t.wv === web
        tabs.remove(t)
        if (lastWeb === t) lastWeb = null
        // বন্ধ হওয়া WebView আর ব্যবহার হবে না: আগে অন্য ওয়েব ট্যাবে (বা নতুন ট্যাবে) সরিয়ে নিই
        if (tabs.none { it.kind == "web" }) {
            val nt = TabInfo("web", takeWebView())
            tabs.add(nt)
            lastWeb = nt
            attachWeb(nt.wv!!)
            nt.wv!!.loadUrl(HOME)
        } else if (wasAttached) {
            val fb = tabs.last { it.kind == "web" }
            lastWeb = fb
            attachWeb(fb.wv!!)
        }
        if (wasWeb) t.wv?.let { v ->
            if (v.parent === root) root.removeView(v)
            v.stopLoading()
            v.destroy()
        }
        if (cur === t) selectTab(tabs[idx.coerceAtMost(tabs.lastIndex)]) else renderTabs()
    }

    /** হোম পেজের ট্যাবের নাম সবসময় "নতুন ট্যাব" (পেজের <title> "MediaDL Pro" লোডের পর এসে ট্যাবের মাপ বদলে ঝাঁকুনি দিত) */
    private fun tabTitle(t: TabInfo): String {
        if (t.kind == "dl") return L.t("downloading")
        val u = t.wv?.url
        if (u == null || u.startsWith(HOME)) return L.t("newTab")
        return t.wv?.title?.takeIf { it.isNotBlank() } ?: L.t("newTab")
    }

    private var lastTabSig = ""

    private fun renderTabs() {
        if (!::tabStrip.isInitialized) return
        // কিছু বদলায়নি হলে স্ট্রিপ নতুন করে বানাই না (প্রতিটি পেজ লোডে বানালে চিপগুলো কেঁপে ওঠে)
        val sig = tabs.joinToString("|") { System.identityHashCode(it).toString() + (if (it === cur) "*" else "") + tabTitle(it) }
        if (sig == lastTabSig && tabStrip.childCount > 0) return
        lastTabSig = sig
        tabStrip.removeAllViews()
        for (t in tabs) {
            val active = t === cur
            val title = tabTitle(t)
            val fg = if (active) 0xFF06211B.toInt() else 0xFFE6EEEC.toInt()
            val chip = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(10), 0, dp(2), 0)
                setBackgroundColor(if (active) 0xFF2BB89A.toInt() else 0xFF1F2D31.toInt())
                setOnClickListener { selectTab(t) }
            }
            chip.addView(TextView(this).apply {
                text = if (title.length > 16) title.take(16) + "…" else title
                textSize = 13f
                setTextColor(fg)
            })
            chip.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_tab_close)
                setColorFilter(fg)
                scaleType = ImageView.ScaleType.FIT_CENTER
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(if (active) 0x33000000 else 0x33FFFFFF)
                }
                setPadding(dp(4), dp(4), dp(4), dp(4))
                contentDescription = L.t("cancel")
                setOnClickListener { closeTab(t) }
            }, LinearLayout.LayoutParams(dp(22), dp(22)).apply { leftMargin = dp(6); rightMargin = dp(4) })
            tabStrip.addView(chip, LinearLayout.LayoutParams(-2, -1).apply { rightMargin = dp(4) })
        }
        tabStrip.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_tab_add)
            setColorFilter(0xFFE6EEEC.toInt())
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x22FFFFFF)
            }
            setPadding(dp(5), dp(5), dp(5), dp(5))
            contentDescription = L.t("newTab")
            setOnClickListener { newWebTab(HOME) }
        }, LinearLayout.LayoutParams(dp(26), dp(26)).apply { gravity = Gravity.CENTER_VERTICAL; leftMargin = dp(8); rightMargin = dp(8) })
    }

    // ---------- ড্রপডাউন মেনু (⋮ তিন-লাইন): ডাউনলোড হচ্ছে / ইতিহাস / নতুন ট্যাব ----------

    private var barMenu: android.widget.PopupWindow? = null
    private var pendingSettings = false
    /** এই সেশনে কতগুলো পপ-আপ ব্লক হয়েছে */
    private var popBlockedCount = 0

    /** সাবটাইটেল/আর্কাইভ ফাইলের সরাসরি লিংক কিনা */
    private fun isFileLink(u: Uri): Boolean {
        val sc = (u.scheme ?: "").lowercase()
        if (sc != "http" && sc != "https") return false
        val ext = (u.lastPathSegment ?: "").substringAfterLast('.', "").lowercase()
        return ext in FILE_EXT
    }

    /** ডাউনলোড-লিংকের মতো দেখতে (ফাইল এক্সটেনশন বা পাথে "download") */
    private fun looksLikeDownload(u: Uri): Boolean =
        isFileLink(u) || (u.path ?: "").lowercase().contains("download")

    private fun saveBytes(name: String, mime: String?, bytes: ByteArray) {
        val fn = name.ifEmpty { "download" }
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val cv = android.content.ContentValues()
                cv.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, fn)
                cv.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, mime ?: "application/octet-stream")
                cv.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MediaDownloader")
                val uri = contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
                    ?: throw Exception("create failed")
                contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
            } else {
                val dir = java.io.File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "MediaDownloader")
                dir.mkdirs()
                java.io.File(dir, fn).writeBytes(bytes)
            }
            runOnUiThread {
                Toast.makeText(this, (if (L.lang == "en") "Saved: " else "সেভ হয়েছে: ") + fn, Toast.LENGTH_LONG).show()
            }
        } catch (e: Throwable) {
            runOnUiThread { Toast.makeText(this, L.t("failed") + (e.message ?: ""), Toast.LENGTH_LONG).show() }
        }
    }

    /** blob: লিংক (সাইটের জাভাস্ক্রিপ্টে বানানো ফাইল, যেমন .srt): পেজ থেকেই বাইট পড়ে Downloads/MediaDownloader-এ সেভ */
    private fun saveBlob(v: WebView, blobUrl: String, name: String, mime: String?) {
        val js = "(function(){try{var x=new XMLHttpRequest();x.open('GET'," + q(blobUrl) + ",false);" +
            "x.overrideMimeType('text/plain; charset=x-user-defined');x.send();var t=x.responseText,b='';" +
            "for(var i=0;i<t.length;i++){b+=String.fromCharCode(t.charCodeAt(i)&255);}return btoa(b);}catch(e){return '';}})()"
        v.evaluateJavascript(js) { r ->
            val s = (r ?: "").trim('"')
            if (s.isEmpty() || s == "null") {
                Toast.makeText(this, L.t("failed") + "blob", Toast.LENGTH_SHORT).show()
            } else {
                Thread {
                    try { saveBytes(name, mime, android.util.Base64.decode(s, android.util.Base64.DEFAULT)) }
                    catch (e: Throwable) { runOnUiThread { Toast.makeText(this, L.t("failed") + (e.message ?: ""), Toast.LENGTH_LONG).show() } }
                }.start()
            }
        }
    }

    /** data: লিংক থেকে ফাইল সেভ */
    private fun saveDataUrl(url: String, name: String) {
        Thread {
            try {
                val comma = url.indexOf(',')
                val meta = url.substring(5, comma)
                val body = url.substring(comma + 1)
                val bytes = if (meta.endsWith(";base64")) android.util.Base64.decode(body, android.util.Base64.DEFAULT)
                    else Uri.decode(body).toByteArray()
                saveBytes(name, meta.substringBefore(';').ifEmpty { null }, bytes)
            } catch (e: Throwable) {
                runOnUiThread { Toast.makeText(this, L.t("failed") + (e.message ?: ""), Toast.LENGTH_LONG).show() }
            }
        }.start()
    }

    /** ব্লক হওয়া পপ-আপ/রিডাইরেক্ট গুনে ছোট বার্তা দেখায় (২.৫ সেকেন্ডে একবার) */
    private fun noteBlocked() {
        runOnUiThread {
            popBlockedCount++
            val now = System.currentTimeMillis()
            if (now - lastPopToast > 2500L) {
                lastPopToast = now
                val msg = L.t("popBlocked") + " (" + bnDigits(popBlockedCount) + ")"
                Toast.makeText(this@MainActivity, msg, Toast.LENGTH_SHORT).show()
            }
        }
    }
    private var lastPopToast = 0L

    private fun bnDigits(n: Int): String =
        if (L.lang == "en") n.toString() else n.toString().map { "০১২৩৪৫৬৭৮৯"[it - '0'] }.joinToString("")

    private fun popSub(): String {
        val n = popBlockedCount
        if (!L.popupBlock()) return L.t("popOffSub")
        return bnDigits(n)
    }

    // ---------- লিংকে লং-প্রেস মেনু ----------

    private var linkMenu: android.widget.PopupWindow? = null
    private var touchX = 0
    private var touchY = 0

    private fun showLinkMenu(wv: WebView, url: String, text: String) {
        linkMenu?.dismiss()
        val dark = isDark()
        val bgc = if (dark) 0xFF232629.toInt() else 0xFFF5F6F8.toInt()
        val ink = if (dark) 0xFFE8EAED.toInt() else 0xFF1C2326.toInt()
        val dim = if (dark) 0xFF9AA0A6.toInt() else 0xFF5F6368.toInt()
        val lineC = if (dark) 0x33FFFFFF else 0x1F000000
        val w = dp(260)
        val ripple = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, ripple, true)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(18).toFloat()
                setColor(bgc)
            }
            setPadding(0, dp(10), 0, dp(6))
        }

        // উপরে: "Share Link", নিচে লিংক, ডানে ⋯ বোতাম (শেয়ার শিট খোলে)
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(4), dp(12), dp(10))
        }
        val ht = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        ht.addView(TextView(this).apply {
            this.text = L.t("shareLink")
            textSize = 16f
            setTextColor(ink)
        })
        ht.addView(TextView(this).apply {
            this.text = url
            textSize = 11f
            setTextColor(dim)
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setPadding(0, dp(2), 0, 0)
        })
        head.addView(ht, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(8) })
        head.addView(TextView(this).apply {
            this.text = "•••"
            textSize = 11f
            setTextColor(ink)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(lineC) }
            isClickable = true
            setOnClickListener {
                linkMenu?.dismiss()
                try {
                    val i = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, url)
                    }
                    startActivity(Intent.createChooser(i, L.t("shareLink")))
                } catch (_: Exception) { }
            }
        }, LinearLayout.LayoutParams(dp(40), dp(40)))
        col.addView(head)
        col.addView(View(this).apply { setBackgroundColor(lineC) }, LinearLayout.LayoutParams(-1, dp(1)))

        fun item(label: String, act: () -> Unit) {
            col.addView(TextView(this).apply {
                this.text = label
                textSize = 15f
                setTextColor(ink)
                setPadding(dp(18), dp(13), dp(18), dp(13))
                isClickable = true
                setBackgroundResource(ripple.resourceId)
                setOnClickListener { linkMenu?.dismiss(); act() }
            }, LinearLayout.LayoutParams(-1, -2))
        }

        val host = try { Uri.parse(url).host } catch (e: Exception) { null }
        item(L.t("openNew")) { newWebTab(url) }
        item(L.t("openBg")) { newBackgroundTab(url) }
        item(L.t("copyLink")) { copyToClipboard(url) }
        item(L.t("savePage")) {
            val base = (host ?: "page").replace(Regex("[^A-Za-z0-9._-]"), "_")
            Toast.makeText(this, L.t("pageSaving"), Toast.LENGTH_SHORT).show()
            startDownloadDm(url, base + "_" + (System.currentTimeMillis() % 100000) + ".html")
        }
        item(L.t("copyText")) {
            if (text.isEmpty()) Toast.makeText(this, L.t("noText"), Toast.LENGTH_SHORT).show()
            else copyToClipboard(text)
        }
        item(L.t("saveLink")) { startDownload(url, null) }
        item(L.t("blockAd")) {
            val added = Filters.blockHost(host, pageHost)
            // এই লিংকটি পেজ থেকে এখনই লুকিয়ে দিই
            wv.evaluateJavascript(
                "(function(u){document.querySelectorAll('a').forEach(function(a){if(a.href===u){a.style.setProperty('display','none','important')}})})(" + q(url) + ")",
                null
            )
            Toast.makeText(this, L.t(if (added) "adBlocked" else "adHidden"), Toast.LENGTH_SHORT).show()
        }

        val pw = android.widget.PopupWindow(col, w, android.view.ViewGroup.LayoutParams.WRAP_CONTENT, true)
        pw.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        pw.isOutsideTouchable = true
        pw.elevation = dp(8).toFloat()
        linkMenu = pw
        col.measure(
            View.MeasureSpec.makeMeasureSpec(w, View.MeasureSpec.EXACTLY),
            View.MeasureSpec.UNSPECIFIED
        )
        val dm = resources.displayMetrics
        val margin = dp(8)
        val x = (touchX - w / 2).coerceIn(margin, (dm.widthPixels - w - margin).coerceAtLeast(margin))
        val maxY = dm.heightPixels - col.measuredHeight - dp(24)
        val y = touchY.coerceAtMost(maxY).coerceAtLeast(dp(24))
        pw.showAtLocation(root, Gravity.NO_GRAVITY, x, y)
    }

    private fun copyToClipboard(s: String) {
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("text", s))
            Toast.makeText(this, L.t("copied"), Toast.LENGTH_SHORT).show()
        } catch (_: Exception) { }
    }

    /** ড্রপডাউন: উপরে রিলোড, পপ-আপ ব্লক, সেটিংস (ডানে); নিচে ইতিহাস, ডাউনলোড, নতুন ট্যাব */
    private fun showBarMenu() {
        barMenu?.dismiss()
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(22).toFloat()
            setColor(if (isDark()) 0xFF232629.toInt() else 0xFFF5F6F8.toInt())
        }
        val ink = if (isDark()) 0xFFE8EAED.toInt() else 0xFF1C2326.toInt()
        val accent = 0xFF5BE0C0.toInt()
        val dim = if (isDark()) 0xFF9AA0A6.toInt() else 0xFF5F6368.toInt()
        val ripple = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackgroundBorderless, ripple, true)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = bg
            setPadding(dp(8), dp(12), dp(8), dp(14))
        }
        fun cell(icon: Int, label: String, tint: Int, sub: String? = null, badge: String? = null, act: () -> Unit): LinearLayout {
            val c = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(0, dp(12), 0, dp(12))
                isClickable = true
                setBackgroundResource(ripple.resourceId)
                setOnClickListener { barMenu?.dismiss(); act() }
            }
            val iconView: View = if (badge == null) {
                ImageView(this).apply { setImageResource(icon); setColorFilter(tint) }
            } else {
                FrameLayout(this).apply {
                    addView(ImageView(this@MainActivity).apply {
                        setImageResource(R.drawable.ic_m_newtab_box)
                        setColorFilter(tint)
                    }, FrameLayout.LayoutParams(-1, -1))
                    addView(TextView(this@MainActivity).apply {
                        text = badge
                        textSize = 11f
                        setTextColor(tint)
                        gravity = Gravity.CENTER
                    }, FrameLayout.LayoutParams(-1, -1))
                }
            }
            c.addView(iconView, LinearLayout.LayoutParams(dp(26), dp(26)))
            c.addView(TextView(this).apply {
                text = label
                textSize = 12f
                setTextColor(tint)
                gravity = Gravity.CENTER
                maxLines = 1
                setPadding(0, dp(6), 0, 0)
            })
            if (sub != null) c.addView(TextView(this).apply {
                text = sub
                textSize = 10f
                setTextColor(dim)
                gravity = Gravity.CENTER
                maxLines = 1
                setPadding(0, dp(2), 0, 0)
            })
            return c
        }
        fun row(vararg cells: LinearLayout): LinearLayout =
            LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                cells.forEach { addView(it, LinearLayout.LayoutParams(0, -2, 1f)) }
            }

        // পুরো ড্রপডাউন জুড়ে উপর থেকে নিচ পর্যন্ত দুটো সোজা লাইন (তিন কলামের মাঝে)
        val padH = dp(8)
        val vLine = android.graphics.Paint().apply {
            color = if (isDark()) 0x88FFFFFF.toInt() else 0x66000000.toInt()
            strokeWidth = dp(1).toFloat()
        }
        col.foreground = object : android.graphics.drawable.Drawable() {
            override fun draw(c: android.graphics.Canvas) {
                val b = bounds
                val cw = (b.width() - 2 * padH) / 3f
                for (i in 1..2) {
                    val x = b.left + padH + cw * i
                    c.drawLine(x, b.top.toFloat(), x, b.bottom.toFloat(), vLine)
                }
            }
            override fun setAlpha(a: Int) {}
            override fun setColorFilter(cf: android.graphics.ColorFilter?) {}
            @Suppress("OVERRIDE_DEPRECATION")
            override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
        }

        val popOn = L.popupBlock()
        col.addView(row(
            cell(R.drawable.ic_m_reload, L.t("reload"), ink) {
                ensureWebTab()
                if (web.url?.startsWith("http") == true) web.reload()
            },
            cell(R.drawable.ic_m_shield, L.t("popBlock"), if (popOn) accent else dim, popSub()) {
                L.setPopupBlock(!L.popupBlock())
                Toast.makeText(this, L.t(if (L.popupBlock()) "popOn" else "popOff"), Toast.LENGTH_SHORT).show()
            },
            cell(R.drawable.ic_m_settings, L.t("settings"), ink) { openSettings() }
        ))
        col.addView(View(this).apply { setBackgroundColor(if (isDark()) 0x88FFFFFF.toInt() else 0x66000000.toInt()) },
            LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(6); bottomMargin = dp(6) })
        col.addView(row(
            cell(R.drawable.ic_m_history, L.t("history"), ink) { ensureWebTab(); showPanel("hist", "") },
            cell(R.drawable.ic_m_download, L.t("downloading"), ink) { ensureWebTab(); showPanel("files", "") },
            cell(R.drawable.ic_m_newtab, L.t("newTab"), ink, badge = bnDigits(tabs.size)) { showTabSheet() }
        ))
        col.addView(View(this).apply { setBackgroundColor(if (isDark()) 0x88FFFFFF.toInt() else 0x66000000.toInt()) },
            LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(6); bottomMargin = dp(6) })
        col.addView(row(
            cell(R.drawable.ic_m_qr, L.t("qrScan"), ink) { startQrScan() },
            cell(R.drawable.ic_m_night, L.t("nightMode"), if (L.nightMode()) accent else ink) {
                L.setNightMode(!L.nightMode())
                applyNight()
                Toast.makeText(this, L.t(if (L.nightMode()) "nightOn" else "nightOff"), Toast.LENGTH_SHORT).show()
            },
            LinearLayout(this)
        ))

        val pw = android.widget.PopupWindow(col, dp(300), android.view.ViewGroup.LayoutParams.WRAP_CONTENT, true)
        pw.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        pw.isOutsideTouchable = true
        pw.elevation = dp(8).toFloat()
        barMenu = pw
        // ড্রপডাউন ঠিক নেভিগেশন বারের উপরের কিনারা থেকে শুরু হয়ে উপরে ওঠে, ডান কিনারা বারের সাথে মেলে
        col.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(dp(300), android.view.View.MeasureSpec.EXACTLY),
            android.view.View.MeasureSpec.UNSPECIFIED
        )
        val loc = IntArray(2)
        bar.getLocationInWindow(loc)
        val x = loc[0] + bar.width - dp(300)
        val y = loc[1] - col.measuredHeight
        pw.showAtLocation(bar, Gravity.NO_GRAVITY, x, y)
    }

    // ---------- ট্যাব তালিকা (নিচ থেকে ওঠা শিট): ট্যাব বাছা/বন্ধ করা, নিচের + দিয়ে নতুন ট্যাব ----------

    private var tabSheet: android.widget.PopupWindow? = null

    private fun tabFavView(t: TabInfo, title: String): View {
        val oval = { c: Int -> GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) } }
        val bmp = t.icon
        if (bmp != null) {
            return ImageView(this).apply {
                setImageBitmap(bmp)
                scaleType = ImageView.ScaleType.FIT_CENTER
                setPadding(dp(6), dp(6), dp(6), dp(6))
                background = oval(Color.WHITE)
            }
        }
        return TextView(this).apply {
            text = if (t.kind == "dl") "⬇" else (title.firstOrNull()?.uppercaseChar()?.toString() ?: "•")
            gravity = Gravity.CENTER
            textSize = 15f
            setTextColor(Color.WHITE)
            background = oval(0xFF2BB89A.toInt())
        }
    }

    private fun showTabSheet() {
        tabSheet?.dismiss()
        val dark = isDark()
        val ink = if (dark) 0xFFE8EAED.toInt() else 0xFF1C2326.toInt()
        val accent = if (dark) 0xFF8AB4FF.toInt() else 0xFF0F9D7A.toInt()
        val rowBg = if (dark) 0xFF202325.toInt() else 0xFFE3E6EA.toInt()
        val sheetBg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            val r = dp(28).toFloat()
            cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            setColor(if (dark) 0xFF101214.toInt() else 0xFFF5F6F8.toInt())
        }
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = android.widget.ScrollView(this).apply { addView(list) }
        val rowH = dp(60)
        val maxH = (resources.displayMetrics.heightPixels * 0.55f).toInt()

        fun fill() {
            list.removeAllViews()
            for (t in tabs.toList()) {
                val active = t === cur
                val title = tabTitle(t)
                val row = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(16), 0, dp(10), 0)
                    if (active) setBackgroundColor(rowBg)
                    setOnClickListener { tabSheet?.dismiss(); selectTab(t) }
                }
                row.addView(tabFavView(t, title), LinearLayout.LayoutParams(dp(34), dp(34)))
                row.addView(TextView(this).apply {
                    text = title
                    textSize = 17f
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                    setTextColor(if (active) accent else ink)
                    setPadding(dp(14), 0, dp(8), 0)
                }, LinearLayout.LayoutParams(0, -2, 1f))
                row.addView(ImageView(this).apply {
                    setImageResource(R.drawable.ic_tab_close)
                    setColorFilter(ink)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    setPadding(dp(10), dp(10), dp(10), dp(10))
                    contentDescription = L.t("cancel")
                    setOnClickListener { closeTab(t); fill() }
                }, LinearLayout.LayoutParams(dp(42), dp(42)))
                list.addView(row, LinearLayout.LayoutParams(-1, rowH))
            }
            scroll.layoutParams = LinearLayout.LayoutParams(-1, minOf(rowH * tabs.size, maxH))
            scroll.requestLayout()
        }
        fill()

        val plus = FrameLayout(this).apply {
            isClickable = true
            setOnClickListener { tabSheet?.dismiss(); newWebTab(HOME) }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_tab_add)
                setColorFilter(ink)
                scaleType = ImageView.ScaleType.FIT_CENTER
                contentDescription = L.t("newTab")
            }, FrameLayout.LayoutParams(dp(30), dp(30), Gravity.CENTER))
        }
        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = sheetBg
            setPadding(0, dp(10), 0, 0)
            addView(scroll)
            addView(plus, LinearLayout.LayoutParams(-1, dp(64)))
        }
        val loc = IntArray(2)
        bar.getLocationInWindow(loc)
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            // উপরের ফাঁকা অংশ ছায়া দেয়; সেখানে চাপলে শিট বন্ধ
            addView(View(this@MainActivity).apply {
                setBackgroundColor(0x99000000.toInt())
                setOnClickListener { tabSheet?.dismiss() }
            }, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(sheet, LinearLayout.LayoutParams(-1, -2))
        }
        val pw = android.widget.PopupWindow(wrap, resources.displayMetrics.widthPixels, loc[1], true)
        pw.setBackgroundDrawable(android.graphics.drawable.ColorDrawable(Color.TRANSPARENT))
        pw.isOutsideTouchable = true
        tabSheet = pw
        pw.showAtLocation(bar, Gravity.NO_GRAVITY, 0, 0)
    }

    /** সেটিংস: হোম পেজের সেটিংস প্যানেল খোলে (হোমে না থাকলে হোম খুলে) */
    private fun openSettings() {
        // ইতিহাস/ডাউনলোড প্যানেল খোলা থাকলে সেটিংস তার পেছনে লুকিয়ে থাকত; আগে প্যানেল বন্ধ করে নিই
        hidePanel()
        val u = web.url
        if (cur?.kind == "web" && u != null && u.startsWith(HOME)) {
            web.evaluateJavascript("window.__openSettings&&window.__openSettings()", null)
            return
        }
        // কোনো সাইট (যেমন ইউটিউব) খোলা থাকলে নতুন পেজ/ট্যাব না খুলে সেটিংস ওই পেজের উপরেই দেখাই, ভিডিও চলতে থাকে
        if (cur?.kind == "web" && u != null && u.startsWith("http")) {
            showSettingsOverlay()
            return
        }
        pendingSettings = true
        newWebTab(HOME)
    }

    private var settingsOv: WebView? = null

    /** সেটিংস প্যানেল বর্তমান পেজের উপরে (নতুন ট্যাব নয়); নিচে পেজ ও ভিডিও যেমন ছিল তেমনই চলে */
    private fun showSettingsOverlay() {
        if (settingsOv != null) return
        val v = newWebView()
        v.setBackgroundColor(Color.TRANSPARENT)
        settingsOv = v
        root.addView(v, FrameLayout.LayoutParams(-1, -1))
        v.loadUrl(HOME + "?ov=1")
        v.postDelayed({
            if (settingsOv === v) v.evaluateJavascript("window.__openSettings&&window.__openSettings()", null)
        }, 350)
    }

    private fun closeSettingsOverlay() {
        val v = settingsOv ?: return
        settingsOv = null
        try {
            root.removeView(v)
            v.stopLoading()
            v.destroy()
        } catch (e: Throwable) { }
    }

    // ---------- ইতিহাস: খোলা পেজের তালিকা (সর্বোচ্চ ২০০টি) ----------

    private val histPrefs by lazy { getSharedPreferences("mdl_hist", MODE_PRIVATE) }

    private fun recordVisit(url: String?, title: String?) {
        if (url == null || !url.startsWith("http")) return
        try {
            val old = JSONArray(histPrefs.getString("list", "[]") ?: "[]")
            val nw = JSONArray()
            nw.put(JSONObject().put("url", url).put("title", title ?: url).put("time", System.currentTimeMillis()))
            var n = 1
            for (i in 0 until old.length()) {
                if (n >= 200) break
                val o = old.getJSONObject(i)
                if (o.optString("url") == url) continue
                nw.put(o); n++
            }
            histPrefs.edit().putString("list", nw.toString()).apply()
        } catch (e: Exception) { }
    }

    private fun pushHist() {
        if (panelMode == null || !panelReady) return
        val json = histPrefs.getString("list", "[]") ?: "[]"
        runOnUiThread {
            panel.evaluateJavascript("window.__nativeHist&&window.__nativeHist(" + q(json) + ")", null)
        }
    }

    private fun pushFiles() {
        if (panelMode == null || !panelReady) return
        val ctx = applicationContext
        Thread {
            val arr = JSONArray()
            for (o in History.all()) {
                val path = o.optString("path")
                var ex = History.locate(ctx, path) != null
                // নতুন ফাইল সিস্টেমের ইনডেক্সে আসতে কয়েক সেকেন্ড লাগতে পারে
                if (!ex && System.currentTimeMillis() - o.optLong("time") < 120000L) ex = true
                val x = JSONObject()
                x.put("id", o.optString("id"))
                x.put("name", o.optString("name"))
                x.put("path", path)
                x.put("size", o.optLong("size"))
                x.put("time", o.optLong("time"))
                x.put("ex", ex)
                arr.put(x)
            }
            val json = arr.toString()
            runOnUiThread {
                panel.evaluateJavascript(
                    "window.__nativeFiles&&window.__nativeFiles(" + q(json) + ")", null
                )
            }
        }.start()
    }

    private fun openHistoryFile(id: String) {
        val o = History.find(id) ?: return
        val uri = History.locate(this, o.optString("path"))
        if (uri == null) {
            Toast.makeText(this, L.t("missing"), Toast.LENGTH_SHORT).show()
            pushFiles()
            return
        }
        val ext = o.optString("name").substringAfterLast('.', "").lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            Toast.makeText(this, L.t("noApp"), Toast.LENGTH_LONG).show()
        }
    }

    private fun playHistoryFile(id: String) {
        val o = History.find(id) ?: return
        val uri = History.locate(this, o.optString("path"))
        if (uri == null) {
            Toast.makeText(this, L.t("missing"), Toast.LENGTH_SHORT).show()
            pushFiles()
            return
        }
        val name = o.optString("name")
        val ext = name.substringAfterLast('.', "").lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
        val audio = mime.startsWith("audio/") || ext in listOf("mp3", "m4a", "aac", "opus", "ogg", "wav", "flac")
        try {
            startActivity(
                Intent(this, PlayerActivity::class.java).setData(uri)
                    .putExtra("name", name).putExtra("mime", mime).putExtra("audio", audio)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            )
        } catch (e: Exception) {
            openHistoryFile(id)
        }
    }

    private fun legacyFile(path: String): java.io.File =
        java.io.File(android.os.Environment.getExternalStorageDirectory(), path)

    private fun renameHistoryFile(id: String, newName: String) {
        val o = History.find(id) ?: return
        val oldName = o.optString("name")
        val ext = oldName.substringAfterLast('.', "")
        var clean = newName.replace(Regex("""[\\/:*?"<>|]"""), "_").trim()
        if (clean.isEmpty()) return
        if (ext.isNotEmpty() && !clean.endsWith(".$ext", ignoreCase = true)) clean = "$clean.$ext"
        val oldPath = o.optString("path")
        val parent = oldPath.substringBeforeLast('/', "")
        val newPath = if (parent.isEmpty()) clean else "$parent/$clean"
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val uri = History.locate(this, oldPath) ?: throw IllegalStateException("missing")
                contentResolver.update(uri, android.content.ContentValues().apply {
                    put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, clean)
                }, null, null)
            } else {
                val src = legacyFile(oldPath)
                if (!src.renameTo(java.io.File(src.parentFile, clean))) throw IllegalStateException("rename")
            }
            History.rename(id, clean, newPath)
            pushFiles()
        } catch (e: Exception) {
            Toast.makeText(this, if (L.lang == "en") "Could not rename the file" else "নাম বদলানো যায়নি", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteHistoryFile(id: String) {
        val o = History.find(id) ?: return
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                History.locate(this, o.optString("path"))?.let { contentResolver.delete(it, null, null) }
            } else {
                legacyFile(o.optString("path")).delete()
            }
        } catch (e: Exception) { }
        History.remove(id)
        pushFiles()
    }

    private fun openDownloadFolder() {
        try {
            startActivity(
                Intent(Intent.ACTION_VIEW).setDataAndType(
                    Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADownload%2FMediaDownloader"),
                    "resource/folder"
                )
            )
            return
        } catch (e: Exception) { }
        try {
            val i = Intent(Intent.ACTION_VIEW)
            i.setDataAndType(
                Uri.parse("content://com.android.externalstorage.documents/document/primary%3ADownload%2FMediaDownloader"),
                "vnd.android.document/directory"
            )
            startActivity(i)
        } catch (e: Exception) {
            try {
                startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
            } catch (e2: Exception) {
                Toast.makeText(this, L.t("folder"), Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun redownloadItem(id: String) {
        val o = History.find(id) ?: return
        val url = o.optString("url")
        if (url.isEmpty()) return
        if (o.optString("kind") == "direct") {
            startDownload(url, o.optString("name"))
        } else {
            val ck = CookieManager.getInstance().getCookie(url)
            Engine.enqueue(
                this, url, o.optString("title", o.optString("name")),
                Engine.Choice("again", History.argsOf(o)), ck, web.settings.userAgentString, url
            )
            Toast.makeText(this, L.t("started"), Toast.LENGTH_SHORT).show()
        }
        lastJobsJson = ""
        pushJobs()
    }

    // ---------- archive.org: ফাইল-তালিকা থেকে বাছাই ----------

    private fun archiveId(): String? {
        val u = web.url ?: return null
        return ARCHIVE.find(u)?.groupValues?.get(3)
    }

    private fun archiveDownload(id: String) {
        Toast.makeText(this, L.t("listFetching"), Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val c = URL("https://archive.org/metadata/" + Uri.encode(id)).openConnection() as HttpURLConnection
                c.connectTimeout = 15000
                c.readTimeout = 20000
                c.setRequestProperty("User-Agent", web.settings.userAgentString)
                val body = c.inputStream.bufferedReader().use { it.readText() }
                val files = JSONObject(body).optJSONArray("files")
                val names = ArrayList<String>()
                val labels = ArrayList<String>()
                if (files != null) {
                    val items = ArrayList<Pair<String, Long>>()
                    for (i in 0 until files.length()) {
                        val f = files.getJSONObject(i)
                        val name = f.optString("name")
                        val ext = name.substringAfterLast('.', "").lowercase()
                        if (name.isEmpty() || ext !in ARCHIVE_EXT) continue
                        items.add(Pair(name, f.optString("size", "0").toLongOrNull() ?: 0L))
                    }
                    items.sortByDescending { it.second }
                    for (t in items.take(40)) {
                        names.add(t.first)
                        val size = if (t.second > 0) String.format(" • %.1f MB", t.second / 1048576.0) else ""
                        labels.add(t.first.substringAfterLast('/') + size)
                    }
                }
                runOnUiThread {
                    if (names.isEmpty()) {
                        Toast.makeText(this, L.t("listNone"), Toast.LENGTH_LONG).show()
                    } else {
                        AlertDialog.Builder(this)
                            .setTitle(L.t("pickFile"))
                            .setItems(labels.toTypedArray()) { _, which ->
                                val n = names[which]
                                startDownload(
                                    "https://archive.org/download/" + Uri.encode(id) + "/" + Uri.encode(n, "/"),
                                    n.substringAfterLast('/')
                                )
                            }
                            .setNegativeButton(L.t("cancel"), null)
                            .show()
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, L.t("listFail") + e.message, Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    // ---------- সরাসরি ফাইল-লিংক: সিস্টেম DownloadManager ----------

    /** সরাসরি ফাইল-লিংক: আগে Engine (aria2c, ১৬ কানেকশন) দিয়ে নামে — DownloadManager এক কানেকশনে ধীর */
    private fun startDownload(url: String, name: String?, referer: String? = null,
                              ua: String? = null, cookies: String? = cookiesFor(url)) {
        try {
            val title = if (name.isNullOrEmpty()) URLUtil.guessFileName(url, null, null) else name
            val ref = referer ?: web.url?.takeIf { isHttpUrl(it) } ?: url
            val agent = ua ?: web.settings.userAgentString
            val choice = Engine.Choice(title, listOf(Engine.Arg("-f", "b")), "video", "direct")
            Engine.enqueue(this, url, title, choice, cookies, agent, ref)
            showPanel("files", "")
        } catch (e: Exception) {
            startDownloadDm(url, name, referer, ua, cookies)
        }
    }

    private fun startDownloadDm(url: String, name: String?, referer: String? = null,
                                ua: String? = null, cookies: String? = cookiesFor(url)) {
        try {
            val fileName = if (name.isNullOrEmpty()) URLUtil.guessFileName(url, null, null) else name
            val r = DownloadManager.Request(Uri.parse(url))
            cookies?.let { r.addRequestHeader("Cookie", it) }
            r.addRequestHeader("User-Agent", ua ?: web.settings.userAgentString)
            val ref = referer ?: web.url
            if (ref != null && ref.startsWith("http")) {
                r.addRequestHeader("Referer", ref)
            }
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            r.setTitle(fileName)
            r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, "MediaDownloader/" + fileName)
            val dmId = (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
            dmJobs.add(DmItem(dmId, fileName, url))
            showPanel("files", "")
        } catch (e: Exception) {
            Toast.makeText(this, L.t("failed") + e.message, Toast.LENGTH_LONG).show()
        }
    }

    private inner class Bridge(private val isPanel: Boolean, private val owner: WebView? = null) {
        /** এই WebView এখন আমাদের নিজস্ব হোম পেজ দেখাচ্ছে কিনা (প্যানেল সবসময় বিশ্বস্ত) */
        @Volatile var onHome = false
        private fun ok() = isPanel || onHome

        // ---- হোম পেজ (index.html) ----
        @JavascriptInterface
        fun openUrl(url: String) { if (!ok()) return;
            runOnUiThread { hidePanel(); web.loadUrl(url) }
        }

        // হোম পেজের "ডাউনলোড" ঘর: সরাসরি ফাইল হলে দ্রুত পথে, m3u8/mpd → yt-dlp, নইলে বিশ্লেষণ প্যানেলে
        @JavascriptInterface
        fun download(url: String, name: String) { if (!ok()) return;
            runOnUiThread {
                when {
                    STREAM.matches(url) -> {
                        val ctx = snapshotContext(url)
                        analysisContext = ctx
                        showPanel("dl", "")
                        selectCapturedMedia(CapturedMedia(url, mediaKind(url, "") ?: "hls", cookies = cookiesFor(url)), ctx)
                    }
                    MEDIA.matches(url) -> startDownload(url, name)
                    else -> startAnalyze(url)
                }
            }
        }

        // ---- ভাষা / থিম / বারের ফাঁকা জায়গা (দুই পেজই এগুলো ব্যবহার করে) ----
        @JavascriptInterface
        fun getLang(): String = L.lang

        @JavascriptInterface
        fun getTheme(): String = L.theme()

        @JavascriptInterface
        fun setLang(l: String) { if (!ok()) return;
            L.saveLang(l)
            runOnUiThread {
                relabelBar()
                panel.evaluateJavascript("window.__lang&&window.__lang(" + q(L.lang) + ")", null)
            }
        }

        @JavascriptInterface
        fun setTheme(t: String) { if (!ok()) return;
            L.setTheme(t)
            runOnUiThread {
                bar.setBackgroundColor(if (isDark()) 0xFF0A1114.toInt() else 0xFF16232A.toInt())
                panel.evaluateJavascript("window.__theme&&window.__theme(" + q(L.theme()) + ")", null)
            }
        }

        @JavascriptInterface
        fun getMaxJobs(): Int = L.maxJobs()

        @JavascriptInterface
        fun setMaxJobs(n: Int) { if (!ok()) return;
            L.setMaxJobs(n)
            Engine.setMaxParallel(L.maxJobs())
        }

        @JavascriptInterface
        fun getPopupBlock(): Boolean = L.popupBlock()

        @JavascriptInterface
        fun setPopupBlock(on: Boolean) { if (!ok()) return; L.setPopupBlock(on) }

        @JavascriptInterface
        fun getDesktopMode(): Boolean = L.desktopMode()

        @JavascriptInterface
        fun setDesktopMode(on: Boolean) { if (!ok()) return
            L.setDesktopMode(on)
            runOnUiThread { applyDesktopAll() }
        }

        @JavascriptInterface
        fun getPageDark(): Boolean = L.pageDark()

        @JavascriptInterface
        fun setPageDark(on: Boolean) { if (!ok()) return
            L.setPageDark(on)
            runOnUiThread { applyPageDarkAll() }
        }

        @JavascriptInterface
        fun getSubLang(): String = L.subLang()

        @JavascriptInterface
        fun setSubLang(v: String) { if (!ok()) return; L.setSubLang(v) }

        @JavascriptInterface
        fun getSearchCfg(): String = L.searchCfg()

        @JavascriptInterface
        fun setSearchCfg(j: String) { if (!ok()) return; L.setSearchCfg(j) }

        // ---- প্যানেল ----
        // সেটিংস ওভারলে বন্ধ (হোম পেজের সেটিংস প্যানেল বন্ধ হলে ডাকে)
        @JavascriptInterface
        fun closeSettings() { if (!ok()) return; runOnUiThread { closeSettingsOverlay() } }

        @JavascriptInterface
        fun panelClose() { if (!ok()) return; runOnUiThread { if (cur?.kind == "dl") ensureWebTab() else hidePanel() } }

        @JavascriptInterface
        fun analyze(url: String) { if (!ok()) return; runOnUiThread { analyzeForPanel(url) } }

        @JavascriptInterface
        fun pick(kind: String, idx: Int) { if (!ok()) return; runOnUiThread { this@MainActivity.pick(kind, idx) } }

        @JavascriptInterface
        fun pickExtra(id: String, url: String) { if (!ok()) return; runOnUiThread { this@MainActivity.pickExtra(id, url) } }

        @JavascriptInterface
        fun pickSniffed(mediaUrl: String) { if (!ok()) return; runOnUiThread { this@MainActivity.pickSniffed(mediaUrl) } }

        /** কোয়ালিটি লিস্ট থেকে সরাসরি ডাউনলোড (আবার প্রোব করে না) */
        @JavascriptInterface
        fun downloadSniffed(mediaUrl: String) { if (!ok()) return;
            runOnUiThread {
                val session = sniffSession?.takeIf { it.token == analyzeToken } ?: return@runOnUiThread
                if (mediaUrl != session.master) return@runOnUiThread
                downloadStream(mediaUrl, session.ctx, sniffLabel(mediaUrl), session.cookies)
            }
        }

        @JavascriptInterface
        fun pickSniffQuality(idx: Int) { if (!ok()) return; runOnUiThread { this@MainActivity.pickSniffQuality(idx) } }

        @JavascriptInterface
        fun updateEngine() { if (!ok()) return; runOnUiThread { this@MainActivity.updateEngine() } }

        @JavascriptInterface
        fun clipboardLink(): String {
            if (!ok()) return ""
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val t = cm.primaryClip?.getItemAt(0)?.text?.toString() ?: ""
            val u = Regex("https?://\\S+").find(t)?.value
            if (u == null) runOnUiThread { Toast.makeText(this@MainActivity, L.t("clipEmpty"), Toast.LENGTH_SHORT).show() }
            return u ?: ""
        }

        @JavascriptInterface
        fun refreshFiles() { if (!ok()) return; runOnUiThread { pushFiles() } }

        @JavascriptInterface
        fun openFile(id: String) { if (!ok()) return; runOnUiThread { openHistoryFile(id) } }

        @JavascriptInterface
        fun playFile(id: String) { if (!ok()) return; runOnUiThread { playHistoryFile(id) } }

        @JavascriptInterface
        fun clearHist() { if (!ok()) return; runOnUiThread { histPrefs.edit().remove("list").apply(); pushHist() } }

        @JavascriptInterface
        fun openHist(url: String) { if (!ok()) return; runOnUiThread { ensureWebTab(); hidePanel(); web.loadUrl(url) } }

        @JavascriptInterface
        fun getFilters(): String = if (ok()) Filters.json() else ""

        @JavascriptInterface
        fun setFilter(id: String, on: Boolean) { if (!ok()) return; Filters.setOn(id, on) }

        @JavascriptInterface
        fun setFiltersMaster(on: Boolean) { if (!ok()) return; Filters.setMaster(on) }

        @JavascriptInterface
        fun updateFilters() { if (!ok()) return;
            Filters.update {
                runOnUiThread {
                    if (::web.isInitialized) web.evaluateJavascript("window.__filtersDone&&window.__filtersDone()", null)
                }
            }
        }

        @JavascriptInterface
        fun openFolder() { if (!ok()) return; runOnUiThread { openDownloadFolder() } }

        @JavascriptInterface
        fun redownload(id: String) { if (!ok()) return; runOnUiThread { redownloadItem(id) } }

        @JavascriptInterface
        fun renameFile(id: String, newName: String) { if (!ok()) return; runOnUiThread { renameHistoryFile(id, newName) } }

        @JavascriptInterface
        fun deleteFile(id: String) { if (!ok()) return; runOnUiThread { deleteHistoryFile(id) } }

        @JavascriptInterface
        fun removeFile(id: String) { if (!ok()) return;
            runOnUiThread {
                History.remove(id)
                pushFiles()
            }
        }

        @JavascriptInterface
        fun cancelJob(id: String) { if (!ok()) return;
            runOnUiThread {
                if (id.startsWith("dm:")) {
                    val n = id.removePrefix("dm:").toLongOrNull()
                    if (n != null) {
                        (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(n)
                        dmJobs.removeAll { it.id == n }
                    }
                } else {
                    Engine.jobs.firstOrNull { it.id == id }?.let { Engine.cancel(it) }
                }
                lastJobsJson = ""
                pushJobs()
            }
        }

        @JavascriptInterface
        fun pauseJob(id: String) { if (!ok()) return;
            runOnUiThread {
                Engine.jobs.firstOrNull { it.id == id }?.let { Engine.pause(it) }
                lastJobsJson = ""
                pushJobs()
            }
        }

        /** তালিকা থেকে সরায় এবং আংশিক ফাইলও মোছে */
        @JavascriptInterface
        fun discardJob(id: String) { if (!ok()) return;
            if (id.startsWith("dm:")) { cancelJob(id); return }
            runOnUiThread {
                Engine.jobs.firstOrNull { it.id == id }?.let { Engine.discard(it) }
                lastJobsJson = ""
                pushJobs()
            }
        }

        /** যতটুকু নেমেছে ততটুকু প্লেয়ারে দেখা */
        @JavascriptInterface
        fun playPartial(id: String) { if (!ok()) return; runOnUiThread { previewPartial(id) } }

        /** Re-download: ব্যর্থ/বাতিল ডাউনলোড আবার শুরু; yt-dlp-এর আংশিক ফাইল থাকলে সেখান থেকেই চলে */
        @JavascriptInterface
        fun retryJob(id: String) { if (!ok()) return;
            runOnUiThread {
                if (id.startsWith("dm:")) {
                    val n = id.removePrefix("dm:").toLongOrNull()
                    val d = dmJobs.firstOrNull { it.id == n }
                    if (d != null) {
                        (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).remove(d.id)
                        dmJobs.remove(d)
                        startDownload(d.url, d.name)
                    }
                } else {
                    Engine.jobs.firstOrNull { it.id == id }?.let { Engine.retry(this@MainActivity, it) }
                }
                lastJobsJson = ""
                pushJobs()
            }
        }

        @JavascriptInterface
        fun clearJobs() { if (!ok()) return;
            runOnUiThread {
                Engine.clearFinished()
                // শেষ হওয়া সিস্টেম-ডাউনলোড শুধু তালিকা থেকে সরে (ফাইল মোছে না)
                val dm = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
                for (d in dmJobs) {
                    dm.query(DownloadManager.Query().setFilterById(d.id)).use { c ->
                        if (!c.moveToFirst() ||
                            c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) != DownloadManager.STATUS_RUNNING &&
                            c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) != DownloadManager.STATUS_PENDING &&
                            c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) != DownloadManager.STATUS_PAUSED
                        ) dmJobs.remove(d)
                    }
                }
                lastJobsJson = ""
                pushJobs()
                updateButtons()
            }
        }

        @JavascriptInterface
        fun media(isPlaying: Boolean, url: String) {
            runOnUiThread {
                if (owner !== web) return@runOnUiThread
                updateMedia(isPlaying, url)
            }
        }

        @JavascriptInterface
        fun mediaPage(page: String, isPlaying: Boolean, url: String) {
            runOnUiThread {
                if (owner !== web || !sameDocument(page, web.url ?: "")) return@runOnUiThread
                if (!sameDocument(page, observedPage)) resetCapture(page)
                updateMedia(isPlaying, url)
            }
        }

        @JavascriptInterface
        fun mediaSource(page: String, url: String, mime: String) {
            runOnUiThread {
                if (owner !== web || !sameDocument(page, web.url ?: "") || !isHttpUrl(url) || isSegment(url)) return@runOnUiThread
                if (!sameDocument(page, observedPage)) resetCapture(page)
                val kind = mediaKind(url, mime)
                if (kind != null) recordMedia(url, kind, mime)
                else if (isMediaCandidate(url)) probeMediaHeaders(url, page)
            }
        }
    }

    private fun updateMedia(isPlaying: Boolean, url: String) {
        if (playing != isPlaying || url != playingUrl) {
            playing = isPlaying
            playingUrl = url
            updateButtons()
        }
        if (isHttpUrl(url) && !isSegment(url)) {
            val kind = mediaKind(url, "")
            if (kind != null) recordMedia(url, kind)
            else probeMediaHeaders(url, observedPage)
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        when {
            settingsOv != null -> closeSettingsOverlay()
            customView != null -> web.webChromeClient?.onHideCustomView()
            cur?.kind == "dl" -> ensureWebTab()
            panelMode != null -> hidePanel()
            web.canGoBack() -> web.goBack()
            else -> @Suppress("DEPRECATION") super.onBackPressed()
        }
    }

    override fun onResume() {
        super.onResume()
        Engine.autoResume()
        handler.post(poll)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(poll)
        CookieManager.getInstance().flush()
    }
}
