package com.foridul.mediadl

import java.util.UUID

/** Session-only metadata: signed media URLs and headers never enter saved jobs/backups. */
internal class AnalysisCache(
    private val ttlNanos: Long = 5L * 60 * 1_000_000_000,
    private val maxEntries: Int = 8,
    private val maxChars: Int = 4 * 1024 * 1024,
    private val clock: () -> Long = System::nanoTime
) {
    private data class Entry(val url: String, val json: String, val created: Long)
    private val entries = LinkedHashMap<String, Entry>()

    @Synchronized
    fun put(url: String, json: String): String? {
        prune()
        if (json.length > maxChars || maxEntries < 1) return null
        while (entries.isNotEmpty() &&
            (entries.size >= maxEntries || entries.values.sumOf { it.json.length.toLong() } + json.length > maxChars)) {
            entries.remove(entries.keys.first())
        }
        val id = UUID.randomUUID().toString()
        entries[id] = Entry(url, json, clock())
        return id
    }

    @Synchronized
    fun get(id: String?, url: String): String? {
        prune()
        val entry = entries[id] ?: return null
        return entry.json.takeIf { entry.url == url }
    }

    @Synchronized
    fun remove(id: String?) { entries.remove(id) }

    private fun prune() {
        val now = clock()
        entries.entries.removeAll { now - it.value.created >= ttlNanos }
    }
}
