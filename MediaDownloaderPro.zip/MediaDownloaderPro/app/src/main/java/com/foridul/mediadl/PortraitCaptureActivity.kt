package com.foridul.mediadl

import com.journeyapps.barcodescanner.CaptureActivity

/** কিউআর স্ক্যানারকে পোর্ট্রেটে লক রাখে, যাতে ক্যামেরা ঘোরানো অবস্থায় না খোলে */
class PortraitCaptureActivity : CaptureActivity()
