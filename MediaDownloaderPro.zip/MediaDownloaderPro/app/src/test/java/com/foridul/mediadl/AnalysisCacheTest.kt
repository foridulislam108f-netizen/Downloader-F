package com.foridul.mediadl

import org.junit.Assert.*
import org.junit.Test

class AnalysisCacheTest {
    @Test fun metadataIsBoundToExactUrl() {
        val cache = AnalysisCache()
        val id = cache.put("https://a.test/video?token=1", "{formats:[]}")
        assertEquals("{formats:[]}", cache.get(id, "https://a.test/video?token=1"))
        assertNull(cache.get(id, "https://a.test/video?token=2"))
        assertNull(cache.get(null, "https://a.test/video?token=1"))
    }

    @Test fun expiresAtTtlWithoutWallClockDependency() {
        var now = 0L
        val cache = AnalysisCache(ttlNanos = 100, clock = { now })
        val id = cache.put("url", "json")
        now = 99
        assertEquals("json", cache.get(id, "url"))
        now = 100
        assertNull(cache.get(id, "url"))
    }

    @Test fun evictsOldestEntryAtCountLimit() {
        val cache = AnalysisCache(maxEntries = 2)
        val first = cache.put("a", "a")
        val second = cache.put("b", "b")
        val third = cache.put("c", "c")
        assertNull(cache.get(first, "a"))
        assertEquals("b", cache.get(second, "b"))
        assertEquals("c", cache.get(third, "c"))
    }

    @Test fun oversizedMetadataFallsBackToNormalExtraction() {
        val cache = AnalysisCache(maxChars = 4)
        assertNull(cache.put("url", "12345"))
        val id = cache.put("url", "1234")
        assertEquals("1234", cache.get(id, "url"))
    }

    @Test fun totalSizeLimitEvictsOldMetadata() {
        val cache = AnalysisCache(maxChars = 5)
        val first = cache.put("a", "123")
        val second = cache.put("b", "456")
        assertNull(cache.get(first, "a"))
        assertEquals("456", cache.get(second, "b"))
    }

    @Test fun invalidateExpiredSignedLinkAndReuseForMultipleChoices() {
        val cache = AnalysisCache()
        val id = cache.put("a", "json")
        assertEquals("json", cache.get(id, "a"))
        assertEquals("json", cache.get(id, "a"))
        cache.remove(id)
        assertNull(cache.get(id, "a"))
    }
}
