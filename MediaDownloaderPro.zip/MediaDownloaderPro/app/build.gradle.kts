plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.foridul.mediadl"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.foridul.mediadl"
        minSdk = 24
        targetSdk = 34
        versionCode = 3
        versionName = "2.1"

        // yt-dlp + python + ffmpeg প্রতি ABI-তে আলাদা; আধুনিক ফোনের জন্য এই দুটোই যথেষ্ট
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }

    packaging {
        jniLibs {
            // yt-dlp লাইব্রেরির জন্য বাধ্যতামূলক (python/ffmpeg নেটিভ ফাইল বের করতে হয়)
            useLegacyPackaging = true
        }
    }
}

dependencies {
    // yt-dlp ইঞ্জিন (১০০০+ সাইট) ও ffmpeg (ভিডিও+অডিও জোড়া লাগানো, MP3 রূপান্তর)
    implementation("io.github.junkfood02.youtubedl-android:library:0.17.2")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.17.2")
}
