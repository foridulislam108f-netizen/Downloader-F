plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.foridul.mediadl"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.foridul.mediadl"
        minSdk = 24
        targetSdk = 34
        versionCode = 4
        versionName = "2.2"

        // yt-dlp + python + ffmpeg প্রতি ABI-তে আলাদা; আধুনিক ফোনের জন্য এই দুটোই যথেষ্ট
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    // GitHub Actions প্রতিবার নতুন র‍্যান্ডম ডিবাগ কী বানায়, তাই এক বিল্ডের উপর আরেক বিল্ড ইনস্টল হতো না ("App not installed")।
    // প্রজেক্টের ভেতরের এই স্থির কী দিয়ে সাইন করলে সব বিল্ড একই সাইনে হবে এবং আগের অ্যাপের উপরেই আপডেট হবে
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
    kotlinOptions {
        jvmTarget = "1.8"
    }

    packaging {
        jniLibs {
            // yt-dlp লাইব্রেরির জন্য বাধ্যতামূলক (python/ffmpeg নেটিভ ফাইল বের করতে হয়)
            useLegacyPackaging = true
        }
    }
}

dependencies {
    // yt-dlp ইঞ্জিন (১০০০+ সাইট) ও ffmpeg (ভিডিও+অডিও জোড়া লাগানো, MP3 রূপান্তর)
    // 0.18.1 includes the QuickJS runtime needed by current YouTube extractors.
    implementation("io.github.junkfood02.youtubedl-android:library:0.18.1")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1")
    // The wrapper exposes ObjectMapper but declares Jackson runtime-only.
    implementation("com.fasterxml.jackson.core:jackson-databind:2.11.1")
    // Native yt-dlp downloading avoids aria2 process startup and restrictive-host failures.
    // আংশিক ডাউনলোড ফাইল প্লেয়ারে দেখানোর জন্য (FileProvider)
    implementation("androidx.core:core-ktx:1.12.0")
    // কিউআর কোড স্ক্যানার (ক্যামেরা + ZXing)
    implementation("com.journeyapps:zxing-android-embedded:4.3.0")
    testImplementation("junit:junit:4.13.2")
}
